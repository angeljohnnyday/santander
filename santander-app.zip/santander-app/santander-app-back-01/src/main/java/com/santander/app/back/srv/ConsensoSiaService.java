package com.santander.app.back.srv;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


import com.santander.app.back.util.Response;

@Path("/ConsensoSiaService")
public interface ConsensoSiaService {
	@GET
	@Path("/lstArmadoConsenso")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstArmadoConsenso(
		@QueryParam("cdSesion") String cdSesion,
		@QueryParam("nuCasos") String nuCasos,
		@QueryParam("limit") Integer limit,
		@QueryParam("offset") Integer offset,
		@QueryParam("search") String search,
		@QueryParam("name") String name, 
		@QueryParam("order") String order
	);
}
