package com.santander.app.back.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class UsuarioDTO {
	private String cdUsuario;
	private BigDecimal cdPerfil1;
	private String nbPerfil1;
	private BigDecimal cdPerfil2;
	private String nbPerfil2;
	private String nbMaterno;
	private String nbPaterno;
	private String nbCveRed;
	private String nbPersona;
	private String nbEmail;
	private BigDecimal cdEstatus;
	private String nbEstatus;
	private String nbSupervisor;
	private String cdStSistema;
	private String cdSupervisor;
	private String nbCveRedSupervisor;
	private BigDecimal cdGerencia;
	private BigDecimal cdGerenciaSupervisor;
	private String nbCliente;
	private String nbStSistema;
	private String cdUsrAlta;
	private List<ModuloDTO> lstModulos1;
	private List<ModuloDTO> lstModulos2;
}
