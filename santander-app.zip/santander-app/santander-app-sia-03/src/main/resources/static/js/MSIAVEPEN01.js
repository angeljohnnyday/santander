var events = {
	'click .detailAlerta': function(e, value, row, index){
		Session.set('casoDTO', row);
		
		Screen.open({
			path: `${Session.get('baseUrlFront')}/Gestion-Alertas/Casos-Pendientes/Vista-Rapida`,
			name: `Vista_Rapida: ${row.cdCaso}`
		});
	},
	'click .detailCaso': function(e, value, row, index){
		Session.set('casoDTO', row);
		
		Screen.open({
			path: `${Session.get('baseUrlFront')}/Gestion-Alertas/Casos-Pendientes/Analisis`,
			name: `Analisis_Caso: ${row.cdCaso}`
		});
	}
};

var cdUsuario = Session.getUser().cdUsuario;

var paramBusq = new Form({
	el: 'formParam',
	data:{
		cdCaso: '',
		cdPrioridad: '-1',
		cdAppOrigen: '-1',
		nuCuenta: '',
		cdCliente: '',
		nuActa: '-1',
		nbCliente: '',
		fhReporteDel: '',
		fhReporteAl: '',
		fhAsignacionDel: '',
		fhAsignacionAl: '',
		cdCasoDel: '',
		cdCasoAl: '',
		cdCasoSicaDel: '',
		cdCasoSicaAl: '',
		imMontoDel: '',
		imMontoAl: ''
	},
	datepicker:[
		'fhReporteDel',
		'fhReporteAl',
		'fhAsignacionDel',
		'fhAsignacionAl',
		{
			name: 'fhActa',
			year: true,
			change($this, ev) {
				if(ev.date != undefined && ev.date != null){
					$this.methods.lstActaByAnio(ev.date.getFullYear());
				}
			}
		}
	],
	money:[
		'imMontoDel',
		'imMontoAl',
	],
	select:{
		cdPrioridad:{
			value: 'cdValor',
			text: 'nbValor',
		},
		cdAppOrigen:{
			value: 'cdValor',
			text: 'nbValor'
		},
		nuActa:{
			value: 'cdValor',
			text: 'nbValor'
		},
	},
	methods:{
		lstPrioridad($this){
			Ajax.get('CatalogoSiaService/lstCatalogo/cdCatalogo/14', data => {
				$this.select.cdPrioridad.setCombo(data.body);
			})
		},
		lstOrigen($this){
			Ajax.get('CatalogoSiaService/lstCatalogoSistema', data => {
				$this.select.cdAppOrigen.setCombo(data.body);
			});
		},
		lstActaByAnio($this, nuAnio){
			Ajax.get(`CatalogoSiaService/lstSessionActa/cdUsuario/${cdUsuario}/fhAnio/${nuAnio}`, data => {
				$this.select.nuActa.setCombo(data.body);
			});
		},
		btnLimpiar($this){
			$this.cdCaso = '';
			$this.cdPrioridad = '-1';
			$this.cdAppOrigen = '-1';
			$this.nuCuenta = '';
			$this.cdCliente = '';
			$this.nuActa = '-1';
			$this.nbCliente = '';
			$this.datepicker.fhReporteDel = null;
			$this.datepicker.fhReporteAl = null;
			$this.datepicker.fhAsignacionDel = null;
			$this.datepicker.fhAsignacionAl = null;
			$this.cdCasoDel = '';
			$this.cdCasoAl = '';
			$this.cdCasoSicaDel = '';
			$this.cdCasoSicaAl = '';
			$this.imMontoDel = '';
			$this.imMontoAl = '';
			
			$this.select.nuActa.remove();
			
			table.casosPendientes.refresh();
		},
		btnBuscar($this){
			var q = serialize({
				cdCaso:  $this.cdCaso == '' ? null : $this.cdCaso,
				cdPrioridad: $this.cdPrioridad,
				cdAppOrigen: $this.cdAppOrigen,
				nuCuenta: $this.nuCuenta == '' ? null : $this.nuCuenta,
				cdCliente: $this.cdCliente == '' ? null : $this.cdCliente,
				nuActa: $this.nuActa,
				nbCliente: $this.nbCliente == '' ? null : $this.nbCliente,
				fhReporteDel: $this.datepicker.fhReporteDel,
				fhReporteAl: $this.datepicker.fhReporteAl,
				fhAsignacionDel: $this.datepicker.fhAsignacionDel,
				fhAsignacionAl: $this.datepicker.fhAsignacionAl,
				cdCasoDel: $this.cdCasoDel == '' ? null : $this.cdCasoDel,
				cdCasoAl: $this.cdCasoAl == '' ? null : $this.cdCasoAl,
				cdCasoSicaDel: $this.cdCasoSicaDel == '' ? null : $this.cdCaso ,
				cdCasoSicaAl: $this.cdCasoSicaAl == '' ? null : $this.cdCasoSicaAl,
				imMontoDel: $this.money.imMontoDel,
				imMontoAl: $this.money.imMontoAl,
			});
			
			table.casosPendientes.refresh(`${Session.get('baseUrl')}/CasosPendientesSiaService/lstCasos/${cdUsuario}${q}`);
		}
	},
	ready($this){
		$this.methods.lstPrioridad();
		$this.methods.lstOrigen();
	}
});

var table = new Table({
	server: {
		casosPendientes:{
			option: {
				url: `${Session.get('baseUrl')}/CasosPendientesSiaService/lstCasos/${cdUsuario}`,
				pagination: false
			}
		}
	},
	formatter:{
		detailConsultadeCasos(value, row, index){
			var nbSistema = row.nbSistema==null ? "" : row.nbSistema;
			var nuCuenta = row.nuCuenta == null ? "": row.nuCuenta;
			var nbConsultor = row.nbConsultor == null ? "" : row.nbConsultor;
			var nbActa = row.nbActa == null ? "" : row.nbActa;
			var fhAsignacion = row.fhAsignacion == null ? "" : formatterDate(row.fhAsignacion);
			var tpCaso = row.tpCaso == null ? "" : row.tpCaso;
			
			return [
				'<i class="fas fa-angle-right text-red"></i><b>Sesi&oacute;n-Acta: </b>'+nbActa+'<br />',
				'<i class="fas fa-angle-right text-red"></i><b>Sistema: </b>'+nbSistema+'<br />',
				'<i class="fas fa-angle-right text-red"></i><b>No.Cuenta: </b>'+nuCuenta+'<br />',
				'<i class="fas fa-angle-right text-red"></i><b>Consultor: </b>'+nbConsultor+'<br />',
				'<i class="fas fa-angle-right text-red"></i><b>Fecha Asignaci&oacute;n: </b>'+fhAsignacion+'<br />',
				'<i class="fas fa-angle-right text-red"></i><b>Tipo de caso: </b>'+tpCaso + '<br />'
			].join('');		
		},
		formtatterIcons(value, row, index){
			return [
				'<a class="detailAlerta" href="javascript:void(0)" title="Vista Rapida"><i class="far fa-list-alt text-red"></i></a>',
				'<a class="detailCaso" href="javascript:void(0)" title="Análisis del Caso"><i class="far fa-clipboard text-red"></i></a>',
				'<a class="detailCedula" href="javascript:void(0)" title="Cedula del Caso"><i class="fas fa-clipboard-list text-red"></i></a>',
				'<a class="detailIX-X" href="javascript:void(0)" title="Automatico IX-X"><i class="far fa-file-alt text-red"></i></a>',
			].join('');
		},
		formatterNuDiasReportar(value, row, index){
			var code = null
			if(value != null){
				var fhHoy = new Date().getTime();
				
				var diff = fhHoy - row.fhAlerta;
				var dias = 60 - (Math.floor(diff / (1000*60*60*24)));
				
				var fhAlerta = formatterDate(row.fhAlerta);
				var color = '';
				
				if(dias <= 60 & dias >= 21){
					color = 'badge-info'; 
				}else if(dias <= 20 & dias >= 6){
					color = 'badge-secondary';
				}else if(dias <= 5 & dias >= 1){
					color = 'badge-danger';
				}else{
					color = 'badge-danger';
				}
				
				code = `${fhAlerta} <span class="badge badge-pill ${color}">${dias}</span>`;
			}
			
			return [code].join('');
		},
		formatterEstatus(value, row, index){
			if(value == "AS"){
				return ['ASIGNADO'].join('');
			}else if(value == "RE"){
				return ['REANALISIS'].join('');
			}else{
				return [''].join('');
			}
		}
	},
});