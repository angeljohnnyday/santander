package com.santander.app.back.dto;

import java.util.List;

import lombok.Data;

@Data
public class CuentasClienteReportadoDTO {
	private String fhAperturaCCR;
	private String nuCuentaCCR;
	private String nbProductoCCR;
	private String nbSubproductoCCR;
	private String nbEstatusCCR;
    private String fhCancelacionCCR;
    private String nbTitularCCR;
    private String nuCtePartCCR;
    private String nbParticipesCCR;
    private String imSaldoCCR;
    private String imSaldoPromCCR;
    private String tpCargaCCR;
    private String tpCargaCCR22;
    private String nbComentariosCCR;
    private String nbBancaCCR;
	private List<?> listOtrasCuentasDet;
	private String cdSec;
	private String nbDetParticipesCCR;
}
