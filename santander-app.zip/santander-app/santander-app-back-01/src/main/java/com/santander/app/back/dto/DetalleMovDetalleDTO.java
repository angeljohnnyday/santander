package com.santander.app.back.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class DetalleMovDetalleDTO {
	private BigDecimal nuDetMov;
	private BigDecimal nuMovto;
	private String nuCuenta;
	private BigDecimal cdCaso;
	private BigDecimal cdCasoSia;
	private String cdDivisa;
	private Integer nuOperacion;
	private String nbConcepto;
	private BigDecimal imOperacion;
	private String nbDetalle;
	private String cdCuentaOD;
	private String tpPersona;
	private String nbCliente;
	private String nbApPaterno;
	private String nbApMaterno;
	private String stCliente;
	private String cdCliente;
	private Date fhRepAutoridad;
	private String nbReportePre;
	private String nbCondicionRep;
	private String nbRfc;
	private String nbActividad;
	private String nbParticipe;
	private String nbActInternet;
	private String cdBanco;
	private String stEndosado;
	private String nbClienteEnd;
	private String stClienteEnd;
	private String cdClienteEnd;
	private Date fhRepAutoridadEnd;
	private String nbReportePreEnd;
	private String nbCondicionRepEnd;
	private String nbActividadEnd;
	private String cdTransmisor;
	private String cdCliente1;
	private String cdCliente2;
	private String cdCliente3;
	private String stVinculado;
	private String tpMovimiento;
	private String stCuenta;
	private BigDecimal cdForm;
}
