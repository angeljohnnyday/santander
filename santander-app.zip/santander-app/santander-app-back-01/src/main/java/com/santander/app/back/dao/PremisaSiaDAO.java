package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dominio.Tsca281Premisa;
import com.santander.app.back.dto.CatalogoSiaDTO;
import com.santander.app.back.dto.PremisaSiaDTO;
import com.santander.app.back.repo.Tsca281Repo;

@Component
public class PremisaSiaDAO {
	@Autowired private EntityManager em;
	@Autowired private Tsca281Repo t281Repo;
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public List<PremisaSiaDTO> lstPremisasByStCompartido(String stCompartido) throws Exception {
		List<PremisaSiaDTO> lstPremisasByStCompartido = new ArrayList<PremisaSiaDTO>();
		
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstPremisasByStCompartido"));
		query.setParameter("stCompartido", stCompartido);
		query.unwrap(NativeQuery.class)
		.addScalar("cdPremisa", BigDecimalType.INSTANCE)
		.addScalar("nbNombre", StringType.INSTANCE)
		.addScalar("nbDescripcion", StringType.INSTANCE)
		.addScalar("fhAlta", TimestampType.INSTANCE)
		.addScalar("fhModif", TimestampType.INSTANCE)
		.addScalar("stActivo", StringType.INSTANCE)
		.addScalar("stVerse", StringType.INSTANCE)
		.addScalar("cdSegmento", StringType.INSTANCE)
		.addScalar("nuDiasCte", BigDecimalType.INSTANCE)
		.addScalar("nuDiasCta", BigDecimalType.INSTANCE)
		.addScalar("nbContexto", StringType.INSTANCE)
		.addScalar("nbOficialPld", StringType.INSTANCE)
		.addScalar("nbBanca", StringType.INSTANCE)
		.addScalar("nbJuridico", StringType.INSTANCE)
		.addScalar("stOpinion", StringType.INSTANCE)
		.addScalar("cdDecisionFinal", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(PremisaSiaDTO.class));
		lstPremisasByStCompartido = (List<PremisaSiaDTO>) query.getResultList();
		
		return lstPremisasByStCompartido;
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstDecisionPremisa() throws Exception {
		List<CatalogoSiaDTO> lstDecisiones = new ArrayList<CatalogoSiaDTO>();
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstDecisionPremisa"));
		query.unwrap(org.hibernate.SQLQuery.class)
		.addScalar("cdDetCatalogo", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.addScalar("cdCatalogo", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));
		lstDecisiones = (List<CatalogoSiaDTO>) query.getResultList();
		
		return lstDecisiones.size() > 0 ? lstDecisiones : null;
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstAccionPremisa() throws Exception{
		List<CatalogoSiaDTO> lstCatalogo = new ArrayList<CatalogoSiaDTO>();
		String consulta = Consultas.getConsultaSia("lstAccionPremisa");
		Query query = em.createNativeQuery(consulta);
		query.unwrap(org.hibernate.SQLQuery.class)
		.addScalar("cdDetCatalogo")
		.addScalar("nbValor")
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));
		lstCatalogo = (List<CatalogoSiaDTO>) query.getResultList();
		
		return lstCatalogo;
	}
	
	public void guardarPremisa(PremisaSiaDTO premisaSiaDTO) throws Exception {
		Tsca281Premisa t281 = new Tsca281Premisa();
		 
		t281 = new Tsca281Premisa();
		t281.setNbNombre(premisaSiaDTO.getNbNombre());
		t281.setNbDescripcion(premisaSiaDTO.getNbDescripcion());
		t281.setTxQuery(premisaSiaDTO.getTxQuery());
		t281.setTxQueryExt(premisaSiaDTO.getTxQueryExt());
		t281.setStActivo(premisaSiaDTO.getStActivo());
		t281.setFhAlta(new Date());
		
		t281.setCdSegmento(premisaSiaDTO.getCdSegmento());
		t281.setNuDiasCte(premisaSiaDTO.getNuDiasCte());
		t281.setNuDiasCta(premisaSiaDTO.getNuDiasCta());
		
		t281.setNbOficialPld(premisaSiaDTO.getNbOficialPld());
		t281.setNbBanca(premisaSiaDTO.getNbBanca());
		t281.setNbJuridico(premisaSiaDTO.getNbJuridico());
		t281.setStOpinion(premisaSiaDTO.getStOpinion());
		t281.setCdDecisionFinal(premisaSiaDTO.getCdDecisionFinal());
		t281.setStVerse(premisaSiaDTO.getStVerse());
		t281.setStCompartido(premisaSiaDTO.getStCompartido());
		
		t281Repo.saveAndFlush(t281);
	}
	
	public void guardarPremisa(BigDecimal cdPremisa, PremisaSiaDTO premisaSiaDTO) throws Exception {
		Tsca281Premisa t281 = null;
		
		 if(cdPremisa != null) t281 = t281Repo.findById(cdPremisa).get();
		 
		 if(t281 != null) {
			 t281.setNbNombre(premisaSiaDTO.getNbNombre());
			 t281.setNbDescripcion(premisaSiaDTO.getNbDescripcion());
			 t281.setTxQuery(premisaSiaDTO.getTxQuery());
			 t281.setTxQueryExt(premisaSiaDTO.getTxQueryExt());
			 t281.setStActivo(premisaSiaDTO.getStActivo());
			 t281.setFhModif(new Date());
			 
			 t281.setCdSegmento(premisaSiaDTO.getCdSegmento());
			 t281.setNuDiasCte(premisaSiaDTO.getNuDiasCte());
			 t281.setNuDiasCta(premisaSiaDTO.getNuDiasCta());
			 
			 t281.setNbOficialPld(premisaSiaDTO.getNbOficialPld());
			 t281.setNbBanca(premisaSiaDTO.getNbBanca());
			 t281.setNbJuridico(premisaSiaDTO.getNbJuridico());
			 t281.setStOpinion(premisaSiaDTO.getStOpinion());
			 t281.setCdDecisionFinal(premisaSiaDTO.getCdDecisionFinal());
			 t281.setStVerse(premisaSiaDTO.getStVerse());
			 t281.setStCompartido(premisaSiaDTO.getStCompartido());
			 
			 t281Repo.saveAndFlush(t281);
		 }
	}
	
	public void eliminarPremisa(BigDecimal cdPremisa) throws Exception {
		Tsca281Premisa t281 = null;
		
		 if(cdPremisa != null) t281 = t281Repo.findById(cdPremisa).get();
		 
		 if(t281 != null) {
			 t281Repo.delete(t281);
			 t281Repo.flush();
		 }
	}
}
