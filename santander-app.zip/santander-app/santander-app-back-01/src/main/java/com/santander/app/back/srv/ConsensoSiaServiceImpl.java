package com.santander.app.back.srv;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.ConsensoSiaDAO;
import com.santander.app.back.util.Response;
import com.santander.app.back.util.Pagination;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ConsensoSiaServiceImpl implements ConsensoSiaService {
	@Autowired private ConsensoSiaDAO consensoSiaDAO;
	
	@Override
	public Response<Object> lstArmadoConsenso(String cdSesion, String nuCasos, Integer limit, Integer offset, String search, String name, String order) {
		try {
			Pagination pagination = new Pagination();
			pagination.setRows(consensoSiaDAO.lstArmadoConsenso(cdSesion, nuCasos, limit, offset, search, name, order));
			pagination.setTotal(consensoSiaDAO.lstArmadoConsensoCount(cdSesion, nuCasos));
			
			return new Response<>(pagination, Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new Response<>(Mensaje.getText("ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
