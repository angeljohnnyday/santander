$(function(){
	fhAnio.changeYear(lstSesionByAnio);
	lstConsultor();
	lstCalificador();
	lstReportes();
});

//=================== CHANGE BTN CALENDAR YEAR ===================
function lstSesionByAnio(fhAnio) {
	CatalogoSia.buscar(`lstSesion/${fhAnio}`, formParam.cdSesion, {value: 'cdValor',text: 'nbValor'});
}

function lstConsultor(){
	CatalogoSia.buscar('lstUsuarios/cdPerfilA/8/stSistema/11', formParam.cdConsultor, {value: 'cdValor',text: 'nbValor'});
}

function lstCalificador(){
	CatalogoSia.buscar('lstUsuarios/cdPerfilA/7/stSistema/11', formParam.cdCalificador, {value: 'cdValor',text: 'nbValor'});
}

function lstReportes(){
	formParam.cdReporte.setComboServer('ReportesService/lstReportes', {value: 'cdReporte',text: 'nbReporte'});
}