package com.santander.app.back.dto;

import lombok.Data;

@Data
public class InformacionPldDTO {
	private String nbNacionalidad;
	private String nbActividadNegocio;
	private String tpOperacion;
	private String nbTipoligia;
	private String tpPersona;
	private String nbInstrumentoMonetario;
	private String nbOrdenPago;
	private String nbOrigen;
	private String cdDelito;
	private String nbDelito;
}
