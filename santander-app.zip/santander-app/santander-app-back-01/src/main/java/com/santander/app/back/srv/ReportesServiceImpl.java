package com.santander.app.back.srv;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.ReportesDAO;
import com.santander.app.back.util.Response;
import com.santander.app.back.util.Pagination;

public class ReportesServiceImpl implements ReportesService {
	@Autowired private ReportesDAO reportesDAO;

	@Override
	public Response<Object> lstReportes() {
		try {
			return new Response<Object>(reportesDAO.lstReportes(), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstReportes(Integer limit, Integer offset, String search, String name, String order) {
		try {
			Pagination pagination = new Pagination();
			pagination.setRows(reportesDAO.lstReportes(limit, offset, name, order));
			pagination.setTotal(reportesDAO.totalLstReportes());
			
			
			return new Response<Object>(pagination, Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstTpReporte() {
		try {
			return new Response<Object>(reportesDAO.lstTpReporte(), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstDetalleTpReporte(String tpReporte) {
		try {
			return new Response<Object>(reportesDAO.lstDetalleTpReporte(tpReporte), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getDetalleReporte(String tpReporte) {
		try {
			return new Response<Object>(reportesDAO.getDetalleReporte(tpReporte), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getDetalleReporteAsignado(String cdReporte, String tpReporte) {
		try {
			return new Response<Object>(reportesDAO.getDetalleReporteAsignado(cdReporte, tpReporte), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getDetalleReporteNoAsignado(String cdReporte, String tpReporte) {
		try {
			return new Response<Object>(reportesDAO.getDetalleReporteNoAsignado(cdReporte, tpReporte), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
