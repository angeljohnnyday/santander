// =================== SESSION STORAGE ===================
class Session extends Map {
	static set(id, value) {
		if (typeof value === 'object') value = JSON.stringify(value);
		sessionStorage.setItem(id, value);
	}

	static get(id) {
		const value = sessionStorage.getItem(id);
		try {
			return JSON.parse(value);
		} catch (e) {
			return value;
		}
	}
	
	static remove(id){
		sessionStorage.removeItem(id);
	}
	
	static clean(){
		sessionStorage.clear();
	}
	
	static getUser(){
		var usuarioDTO = this.get("usuario");
		return usuarioDTO;
	}
	
	static lstModulos(){
		var usuarioDTO = this.getUser();
		if(usuarioDTO != null){
			return usuarioDTO.lstModulos1;
		} else {
			return [];
		}
	}
	
	static perfil(){
		var usuarioDTO = this.getUser();
		return usuarioDTO.cdPerfil1;
	}
	
	static changePerfil(cdPerfil){
		var usuarioDTO = this.getUser();

		this.clean();
		this.set('cdUserTemp', usuarioDTO.nbCveRed);
		this.set('cdPerfilTemp', usuarioDTO.cdPerfil2);
		Screen.perfilado();
	}
	
	static logout(){
		this.clean();
		Screen.login();
	}
}

//=================== AJAX ===================
class Ajax {
	static get(url, host){
		if(host == null) host = `${Session.get('baseUrl')}/`;
		url = host + url;
		
		if(url != undefined && url != null){
			return $.ajax({
				url : url,
				type : 'GET',
				async: true
			})
		}
	}
	
	static getSync(url, host){
		if(host == null) host = `${Session.get('baseUrl')}/`;
		url = host + url;
		
		if(url != undefined && url != null){
			return $.ajax({
				url : url,
				type : 'GET',
				async: false
			})
		}
	}
	
	static post(url, object, host){
		if(host == null) host = `${Session.get('baseUrl')}/`;
		url = host + url;
		
		if(url != undefined && url != null){
			return $.ajax({
				url : url,
				type : 'POST',
				contentType: 'application/json',
				dataType: 'JSON',
				data: JSON.stringify(object),
				async: true
			})
		}
	}
	
	static put(url, object, host){
		if(host == null) host = `${Session.get('baseUrl')}/`;
		url = host + url;
		
		if(url != undefined && url != null){
			return $.ajax({
				url : url,
				type : 'PUT',
				contentType: 'application/json',
				dataType: 'JSON',
				data: JSON.stringify(object),
				async: true
			})
		}
	}
	
	static delet(url, host){
		if(host == null) host = `${Session.get('baseUrl')}/`;
		url = host + url;
		
		if(url != undefined && url != null){
			return $.ajax({
				url : url,
				type : 'DELETE',
				async: true
			})
		}
	}
	
	static postFile(url, fileData){
		if(url != undefined && url != null){
			return $.ajax({
				url: url,
				type: "POST",
				data: fileData,
				enctype: 'multipart/form-data',
				contentType: false,
				processData: false,
				cache: false,
				async: true
			})
		}
	}
	
	static statusOK(data, show){
		var bool = (data.statusCodeValue == '200');
		
		if(!bool || show){
			var color = null;
			
			switch (data.statusCodeValue) {
			case 200:
				color = 'blue';
				break;

			case 500:
				color = 'red';
				break;
			default:
				color = 'yellow'
				break;
			}
			
			ohSnap(data.message, {color: color, duration: '8000'});
		}
		
		if(!bool) console.error( data.errorException );
		
		return bool;
	}
}

// =================== CONFIG PANTALLA  ===================
class Screen {
	static open(pageDTO) {
		window.open(
			pageDTO.path,
			pageDTO.name,
			'fullscreen=yes,toolbar=yes,location=yes,directories=yes,status=yes,menubar=yes,scrollbars=yes,copyhistory=yes,resizable=yes',
			function(response, status, xhr) {
				if(status != 'success'){
					Ajax.statusOK({
						message: 'Pagina no encontrada',
						status: 500
					});
				}
			}
		);
	}
	
	static openWindow(pageDTO) {
		window.open(
			pageDTO.path, 
			pageDTO.name, 
			`width=${pageDTO != null && pageDTO.width != null ? pageDTO.width : 4000}, height=${pageDTO != null && pageDTO.height != null ? pageDTO.height : 4000}`
		);
	}
	
	static load(url){
		document.location.href = url;
	}
	
	static loadPage(obj, name){
		if(typeof obj === 'string') obj = document.querySelector(obj);
		if(obj == null) throw 'LoadPage element is NULL';
		Ajax.get(`view/${obj.id}`, `${Session.get('baseUrlFront')}/`).done((html, status, xhr) => {
			if(status === 'success'){
				$(obj.getAttribute('href')).html(html);
				if(name != null && name != ""){
					window.history.pushState(html, '', `${Session.get("baseUrlFront")}/${name}`);
				}
			}
		})
	}
	
	static perfilado(){
		this.load(`/santander-app-sica-02/perfilado`);
	}
	
	static login(){
		this.load(`/santander-app-sica-02/login`);
	}
}

//=================== BOOTSTRAPTABLE - UTILIDADES ===================
class TableUtil {
	constructor(element){
		this.element = element;
	}
	
	setTableConfig(configDTO){
		$(this.element).bootstrapTable(configDTO);
	}
	
	getData(){
		var lstData = $(this.element).bootstrapTable('getData');
		lstData.forEach(data => {
		    delete data['0']
		});
		
		return lstData;
	}
	
	getSelections(){
		var lstSelections = $(this.element).bootstrapTable('getSelections');
		lstSelections.forEach(data => {
		    delete data['0']
		});
		
		return lstSelections;
	}
	
	getSelected(){
		var selections = $(this.element).bootstrapTable('getSelections')[0];
		selections.forEach(data => {
		    delete data['0']
		});
		
		return selections;
	}
	
	checkAll(){
		$(this.element).bootstrapTable('checkAll');
	}
	
	uncheckAll(){
		$(this.element).bootstrapTable('uncheckAll');
	}
	
	checkInvert(){
		$(this.element).bootstrapTable('checkInvert');
	}
	
	destroy(){
		$(this.element).bootstrapTable('destroy');
	}
	
	formatShowingRows (pageFrom, pageTo, totalRows) {
		return `Mostrando ${pageFrom} al ${pageTo} de ${totalRows} registros`;
	}
		
	formatRecordsPerPage (pageNumber) {
		return `${pageNumber} registros por p\u00e1gina`;
	}
	 
	formatLoadingMessage () {
		return 'Cargando, espere por favor...';
	}
	 
	formatSearch () {
		return 'Buscar';
	}
	 
	formatNoMatches () {
		return 'No se encontr&oacute; informaci&oacute;n';
	}
	
	loadSuccess(fn){
		$(this.element).on('load-success.bs.table', fn);
	}
}

// =================== BOOTSTRAPTABLE - SERVER ===================
class TableServer extends TableUtil {
	constructor(element, options){
		super(element);

		this.type = 'server';
		this.options = null;
		if(options != undefined) setOptions(options);
		
		this.name = element.getAttribute('data-table-server');
	}

	setOptions(options){
		var _this = this;
		if(options == null) throw 'Table Server options is NULL';
		if(options.url == null) throw 'URL is NULL';
		
		var DEFAULT = _this.DEFAULT_OPTIONS();
		Object.keys(DEFAULT).forEach(name => {
			if(options[name] == null) options[name] = DEFAULT[name];
		});
		
		this.options = options;
	}
	
	setTable(options){
		this.setOptions(options);
		this.destroy();
		$(this.element).bootstrapTable(this.options);
	}
	
	refresh(url){
		if(url != null) this.options.url = url;
		$(this.element).bootstrapTable('refresh', {url: this.options.url});
	}
	
	queryParams(params){
		return {
			limit : params.limit,
			offset : params.offset,
			search : params.search,
			name : params.sort,
			order : params.order
		};
	}
	
	responseHandler(response) {
		return {
			rows: response.body.rows,
			total: response.body.total
		};
	}
	
	DEFAULT_OPTIONS(){
		return {
			search: false,
			pagination: true,
			pageSize: 10,
			pageList: [10, 25, 50],
			sortable: true,
			lstBtn: [],
			checkboxHeader: false,
			clickToSelect: false,
			singleSelect: false,
			maintainSelected: true,
			sidePagination: 'server',
			queryParams: this.queryParams,
			responseHandler : this.responseHandler,
			formatShowingRows: this.formatShowingRows,
			formatRecordsPerPage: this.formatRecordsPerPage,
			formatLoadingMessage: this.formatLoadingMessage,
			formatSearch: this.formatSearch,
			formatNoMatches: this.formatNoMatches
		};
	}
	
	convertData(){
		this.element.removeAttribute('data-table-server');
		this.element.setAttribute('data-table', this.name);
		window[this.name] = new TableData(this.element);
	}
}

//=================== BOOTSTRAPTABLE - DATA ===================
class TableData extends TableUtil {
	constructor(element, options){
		super(element);

		this.type = 'data';
		this.options = null;
		if(options != undefined) this.setOptions(options);
		
		this.stUrl = false;
		this.url = null;
		this.host = null;
		
		this.name = element.getAttribute('data-table');
	}
	
	setOptions(options){
		var _this = this;
		var DEFAULT = _this.DEFAULT_OPTIONS();
		
		if(options == null) {
			options = DEFAULT;
		} else {
			Object.keys(DEFAULT).forEach(name => {
				if(options[name] == null) options[name] = DEFAULT[name];
			});
		}
		
		this.options = options;
	}
	
	setTable(options){
		this.setOptions(options);
		if(this.stUrl) {
			this.executeAjax();
		} else {
			this.destroy();
			$(this.element).bootstrapTable(this.options);
		}
	}
	
	setUrl(url, host){
		if(url == null) throw 'URL is NULL';
		this.stUrl = true;
		this.url = url;
		if(host === null) throw 'Host is NULL';
		if(host !== undefined) this.host = host;
	}
	
	executeAjax(){
		var _this = this;
		Ajax.get(_this.url, _this.host).done(data => {
			if(Ajax.statusOK(data, _this.show)){
				_this.options.data = data.body;
				_this.destroy();
				$(_this.element).bootstrapTable(_this.options);
			} else {
				_this.options.data = [];
				_this.destroy();
				$(_this.element).bootstrapTable(_this.options);
			}
		});
	}
	
	load(data){
		if(this.stUrl && data == undefined){
			this.executeAjax();
		} else {
			$(this.element).bootstrapTable('load', data);
		}
	}
	
	DEFAULT_OPTIONS(){
		return {
			search: false,
			pagination: true,
			pageSize: 10,
			pageList: [10, 25, 50],
			sortable: true,
			lstBtn:  [],
			checkboxHeader: false,
			clickToSelect: false,
			singleSelect: false,
			maintainSelected: true,
			data: [],
			formatShowingRows: this.formatShowingRows,
			formatRecordsPerPage: this.formatRecordsPerPage,
			formatLoadingMessage: this.formatLoadingMessage,
			formatSearch: this.formatSearch,
			formatNoMatches: this.formatNoMatches
		};
	}
	
	convertServer(){
		this.element.removeAttribute('data-table');
		this.element.setAttribute('data-table-server', this.name);
		window[this.name] = new TableServer(this.element);
	}
}

// =================== ALERT ===================
class Alert {
	static error(message){
		$.dialog({
		    title: 'Error',
		    theme: 'material',
		    type: 'red',
		    content: `<strong>${message != null ? message : ''}</strong>`,
		    buttons: {
		    	cerrar: {
		    		text: '<strong>Cerrar</strong>',
		            btnClass: 'btn-danger'
		    	},
		    }
		});
	}
	
	static confirm(message, fn){
		if(fn == undefined || fn == null) fn = function(){};
		$.confirm({
		    title: '',
		    content: message,
		    theme: 'material',
		    type: 'blue',
		    buttons: {
		        aceptar: {
		            text: '<strong>Aceptar</strong>',
		            btnClass: 'btn-blue btn-sm',
		            action: fn
		        },
		        cancelar: {
		    		text: '<strong>Cancelar</strong>',
		            btnClass: 'btn-blue btn-sm'
		    	}
		    }
		});
	}
}

// =================== UTIL ===================
class Util {
	static isString(value){
		return typeof value === 'string';
	}
	
	static upper(value){
		if(this.isString(value)){
			return value.toUpperCase().trim();
		} else{
			return value
		}
	}
	
	static lower(value){
		if(this.isString(value)){
			return value.toLowerCase().trim();
		} else{
			return value
		}
	}
	
	static replaceAll(string, search, newValue){
		if(string != undefined && string != null){
			return string.replace(new RegExp(search, 'g'), newValue);
		} else {
			return null;
		}
	}
	
	static validateNumber(event){
		var bool = false;
	  	var letter = event.key;
	    var key = event.keyCode;
		
		bool = new RegExp("[0-9]+").test(letter);

	    if(key == 8 || key == 32 || (event.ctrlKey && key == 86) || (event.ctrlKey && letter == 67)){
	        bool = true;
	  	}

	    event.returnValue = bool;
	}
	
	static validateLstNumber(event) {
	    var bool = false;
	  	var letter = event.key;
	    var key = event.keyCode;
		
		bool = new RegExp("[0-9,]+").test(letter);

	    if(key == 8 || key == 32 || (event.ctrlKey && key == 86) || (event.ctrlKey && letter == 67)){
	        bool = true;
	  	}

	    event.returnValue = bool;
	}
	
	static validateLetter(event){
		var bool = false;
	  	var letter = event.key;
	    var key = event.keyCode;
		
		bool = new RegExp("[aA-zZ]+").test(letter);

	    if(key == 8 || key == 32 || (event.ctrlKey && key == 86) || (event.ctrlKey && letter == 67)){
	        bool = true;
	  	}

	    event.returnValue = bool;
	}
	
	static validateLstLetter(event) {
	    var bool = false;
	  	var letter = event.key;
	    var key = event.keyCode;
		
		bool = new RegExp("[aA-zZ,]+").test(letter);

	    if(key == 8 || key == 32 || (event.ctrlKey && key == 86) || (event.ctrlKey && letter == 67)){
	        bool = true;
	  	}

	    event.returnValue = bool;
	}
	
	static changeUpper(obj) {
		obj.value = obj.value.toUpperCase();
	}
	
	static html(el, text){
		el.innerHTML = text;
	}
	
	static emptyNull(value){
		return (value != null && typeof value === 'string' && value.trim() != '' ? value.trim() : null)
	}
	
	static hasClass(el, className){
		return el.classList.contains(className);
	}
	
	static change(el, fn){
		el.addEventListener('change', fn);
	}
}

class Model {
	constructor(element, form){
		var search = null;
		if(typeof form === 'string') search = form;
		if(search == null) search = (form != null ? 'data-form-model' : 'data-model');
		
		if(typeof element === 'string') {
			var value = element;
			element = document.querySelector(`*[${search}=${value}]`);
		}
		
		if(element == null) throw 'Model element is NULL';
		
		this.elementName = element.getAttribute(search) || search;
		this.element = element;
		
		this.form = (typeof form === 'string' ? null : form);
		
		if(this.form != null){
			this.elementName = `${this.form.formName}.${this.elementName}`;
		}
		
		this.init();
		if(this.element.tagName == 'SELECT' && !this.element.type == 'select-multiple') this.valueTemp = null;
	}
	
	init(){
		if(this.element.tagName == 'INPUT'){
			if(this.hasClass('onlyNumber')){
				this.element.removeEventListener('keydown', Util.validateLstNumber, false);
				this.element.addEventListener('keydown', Util.validateLstNumber);
			}
			
			if(this.hasClass('onlyLstNumber')){
				this.element.removeEventListener('keydown', Util.validateNumber, false);
				this.element.addEventListener('keydown', Util.validateNumber);
			}
		}
		
		if(this.element.tagName == 'SELECT'){
			if(this.element.type == 'select-multiple'){
				this['val'] = function(){
					var values = [];
					var options = this.element.querySelectorAll('option');
					options.forEach(el => {
						if(el.selected) values.push(el.value);
					})
					
					return values;
				}
				
				this['text'] = function(){
					
					var texts = [];
					var options = this.element.querySelectorAll('option');
					options.forEach(el => {
						if(el.selected) texts.push(el.text);
					})
					
					return texts;
				}
				
				this['getSelectedOption'] = function() {
					var values = [];
					
					var options = this.element.querySelectorAll('option');
					options.forEach(el => {
						if(el.selected) {
							values.push({
								value: el.value,
								text: el.text
							});
						}
					})
					
					return values;
				}
				
				this['getAllOption'] = function(){
					var values = [];
					
					var options = this.element.querySelectorAll('option');
					options.forEach(el => {
						values.push({
							value: el.value,
							text: el.text
						});
					})
					
					return values;
				}
				
				this['removeSelectedOption'] = function() {
					var i = 0;
					while(i < this.element.length){
						var option = this.element[i];
						if(option.selected) {
							this.element.remove(i);
							i = 0;
						} else {
							i ++;
						}
					}
				}
				
				this['removeAllOption'] = function() {
					while(this.element.length != 0){
						this.element.remove(0);
					}
				}
			} else {
				this['val'] = function(value){
					if(value !== undefined){
						if(typeof value === 'object' && value !== null) value = value[this.elementName];
						if(value === null || value == 'null' || value == '') value = '-1';
						
						this.valueTemp = value;
						this.element.value = value;
					}
					
					return this.element.value != '-1' && this.element.value != null ? this.element.value : null;
				}
				
				this['text'] = function(){
					return this.element.options[this.element.selectedIndex].text;
				}
				
				var _this = this;
				_this.change(function(){
					_this.valueTemp = _this.val();
				})
			}
			
			this['setCombo'] = function (options){
				if(this.element.type == 'select-multiple') options.stFirst= false;
				$(this.element).select(options);
				this.val(this.valueTemp);
			}
			
			this['setComboServer'] = function (url, options){
				var _this = this;
				Ajax.get(url).done(function(data){
					if(Ajax.statusOK(data, false)){
						if(_this.element.type == 'select-multiple') options.stFirst= false;
						options.data = data.body;
						$(_this.element).select(options);
						_this.val(_this.valueTemp);
					} else {
						$(_this.element).select('error');
						_this.val(null);
					}
				});
			}
			
			this['pushCombo'] = function (options){
				options.push = true;
				$(this.element).select(options);
				if(this.element.type == 'select-one') this.val(this.valueTemp);
			}
			
			this['pushComboServer'] = function(url, options){
				var _this = this;
				Ajax.get(url).done(function(data){
					if(Ajax.statusOK(data, false)){
						options.data = data.body;
						options.push = true;
						$(_this.element).select(options);
						if(_this.element.type == 'select-one') _this.val(_this.valueTemp);
					} else {
						$(_this.element).select('error');
						if(_this.element.type == 'select-one') _this.val(null);
					}
				});
			}
		} else {
			if(this.element.type == 'checkbox' || this.element.type == 'radio'){
				this['isChecked'] = function() {
					return this.element.checked;
				}
				
				this['checked'] = function(bool){
					if(bool !== undefined) {
						if(typeof bool != 'boolean'){
							if(bool === null || bool == '0') bool = false;
							if(bool == '1') bool = true;
						}
						
						this.element.checked = bool;
					}
					
					return (this.element.checked ? '1' : '0');
				}
			}
			
			
			if(this.element.type == 'radio' || this.element.type == 'text' || this.element.type == 'textarea'){
				this['val'] = function(value){
					if(value !== undefined){
						if(typeof value === 'object' && value !== null) value = value[this.elementName];
						if(value === null) value == '';
						
						this.element.value = value;
					}
					
					if(this.hasClass('text-uppercase')) this.element.value = Util.upper(this.element.value);
					if(this.hasClass('text-lowercase')) this.element.value = Util.lower(this.element.value);
					if(this.hasClass('trim')) this.element.value = this.element.value.trim();
					
					var formatter = this.element.dataset.formatter;
					if(formatter != null) this.element.value = eval(`${formatter}(${this.element.value})`);
					
					return this.element.value == '' ? null : this.element.value;
				}
				
				this['trim'] = function (){
					var value = this.element.value;
					if(Util.isString(value)){
						value = value.trim();
					}
					return value;
				}
				
				this['upper'] = function (){
					var value = this.element.value;
					if(Util.isString(value)){
						value = Util.upper(value);
					}
					return value;
				}
				
				this['lower'] = function (){
					var value = this.element.value;
					if(Util.isString(value)){
						value = Util.lower(value);
					}
					return value;
				}
			}
		}
	}
	
	disabled(bool){
		if(bool == undefined) bool = true;
		this.element.disabled = bool;
		
		var lstElements = document.querySelectorAll(`[data-disabled='${this.elementName}']`);
		lstElements.forEach(el => {
			el.disabled = _this.element.disabled;
		});
		
		return this.element.disabled;
	}
	
	show(bool){
		if(bool == undefined) bool = true;
		var code = (bool ? 'inline-block' : 'none');
				
		this.element.style.display = code;

		var _this = this;
		var lstElements = document.querySelectorAll(`[data-show='${this.elementName}']`);
		lstElements.forEach(el => {
			el.style.display = _this.element.style.display
		});
	}
	
	hasClass(className){
		return Util.hasClass(this.element, className);
	}
	
	change(fn){
		Util.change(this.element, fn);
	}
}

//=================== DATE PICKER - BOOTSTRAP ===================
class DatePicker extends Model {
	constructor(element, form){
		super(element, form);
		
		this.options = null;
	}
	
	yearInit(options){
		this.init(options, true);
	}
	
	init(options, year){
		var DEFAULT_OPTIONS = (year ? this.DEFAULT_OPTIONS_YEAR() : this.DEFAULT_OPTIONS());
		
		if(options == null){
			this.options = DEFAULT_OPTIONS;
		} else {
			Object.keys(DEFAULT_OPTIONS).filter(name => {
				if(options[name] == null) options[name] = DEFAULT_OPTIONS[name];
			});
			this.options = options;
		}
		
		this.destroy();
		$(this.element).datepicker(this.options);
	}

	val(value){
		return this.element.value == '' ? null : this.element.value;
	}
	
	getDate(){
		return $(this.element).datepicker('getDate');
	}
	
	setDate(value){
		if(value != null) value = new Date(value);
		$(this.element).datepicker('setDate', value);
	}
	
	changeYear(fn){
		var fhAnio = null;
		$(this.element).datepicker().on('changeDate', ev => {
			var $this = this;
			if(ev.date != undefined && ev.date != null){
				var fhAnio = ev.date.getFullYear();
				if(fn == null) throw 'Funcion no declarado';
				fn(fhAnio)
			}
		});
	}
	
	change(fn){
		var date = null;
	}
	
	destroy(){
		$(this.element).datepicker('destroy');
	}
	
	DEFAULT_OPTIONS() {
		return {
			language: 'es',
			format: 'dd/mm/yyyy',
			autoclose: true,
			todayHighlight: true
		};
	}
	
	DEFAULT_OPTIONS_YEAR() {
		return {
			format: "yyyy",
			viewMode: 2,
			startView: 2,
			minViewMode: 2,
			maxViewMode: 2,
			autoclose: true
		};
	}
}

//=================== MASK MONEY ===================
class Money extends Model {
	constructor(element, model){
		super(element, model);
		
		this.options = null;
	}
	
	init(options){
		var DEFAULT_OPTIONS = this.DEFAULT_OPTIONS()
		if(options == null){
			this.options = DEFAULT_OPTIONS;
		} else {
			Object.keys(DEFAULT_OPTIONS).filter(name => {
				if(options[name] == null) options[name] = DEFAULT_OPTIONS[name];
			});
			
			this.options = options;
		}
		
		this.destroy();
		$(this.element).maskMoney(this.options);
	}

	val(value){
		return this.element.value == '' ? null : this.element.value;
	}
	
	setMoney(value){
		if(value == null) value = 0;
		$(this.element).maskMoney('mask', value);
		
		if(value == 0){
			this.element.value = '';
		}
	}
	
	getMoney(){
		return $(this.element).maskMoney('unmasked')[0];
	}
	
	destroy(){
		$(this.element).maskMoney('destroy');
	}
	
	DEFAULT_OPTIONS(){
		return {
			precision: 2
		};
	}
}

//	======================= MODEL =======================
class Form {
	constructor(form, search){
		if(typeof form === 'string') form = document.querySelector(model);
		if(form == null) throw 'form element is NULL';
		
		this.formName = form.dataset.form;
		
		this.form = form;
		this.lstModel = [];
		this.init();
	}
	
	init(){
		var _this = this;
		var lstModel = _this.form.querySelectorAll(`[data-form-model]`);
		lstModel.forEach((model, index) => {
			var name = model.dataset.formModel;
			
			_this.lstModel.push({
				key: name,
				element: model,
				type: model.type,
				tag: model.tagName,
				classType: null
			});
			
//			ADD CLASSES
			_this[name] = new Model(model, _this);
			_this.lstModel[index].classType = 'model';
			
			if(_this[name].hasClass('date')){
				_this[name] = new DatePicker(model, _this);
				_this[name].init();
				_this.lstModel[index].classType = 'datepicker';
			}
			
			if(_this[name].hasClass('money')){
				_this[name] = new Money(model, _this);
				_this[name].init();
				_this.lstModel[index].classType = 'money';
			}
		});
	}
	
	getLstModel(){
		return this.lstModel;
	}
	
	getModel(name){
		var model = this.lstModel.filter(model => model.key == name)[0];
		if(model != null){
			return model;
		} else{
			return null;
		}
	}
	
	getData(){
		var data = {};
		var _this = this;
		this.lstModel.forEach(model => {
			var name = model.key;
			var type = model.type;
			var tag = model.tag;
			var classType = model.classType;
			var elem = model.element;
			var value = null;
			
			switch(classType){
			case 'datepicker':
				value = _this[name].hasClass('date-text') ? _this[name].val() : _this[name].getDate();
				break;
			case 'money':
				value = _this[name].hasClass('money-text') ? _this[name].val() : _this[name].getMoney();
				break;
			default:
				if(tag == 'SELECT'){
					value = _this[name].hasClass('select-text') ? _this[name].text() : (_this[name].val() != '-1' ? _this[name].val() : null);
				} else {
					switch(type){
					case 'checkbox':
						value = _this[name].checked();
						break;
					case 'radio':
						_this[name].forEach(row => {
							if(row.checked) value = row.value;
						});
						break;
					default:
						value = _this[name].val();
						break;
					}
				}
				break;
			}
			
			data[name] = value;
		});
		
		return data;
	}
	
	setData(data){
		var _this = this;
		Object.keys(data).forEach(name => {
			var model = _this.getModel(name);
			if(model != null){
				var type = model.type;
				var tag = model.tag;
				var classType = model.classType;
				
				switch(classType){
				case 'datepicker':
					 _this[name].setDate(data[name]);
					break;
				case 'money':
					_this[name].setMoney(data[name]);
					break;
				default:
					switch(type){
					case 'checkbox':
						_this[name].checked(data[name] == '1');
						break;
					case 'radio':
						_this[name].forEach(row => {
							if(row.value == data[name]) row.checked = true;
						});
						break;
					default:
						_this[name].val(data[name]);
						break;
					}
					break;
				}
			}
		})
	}
	
	setDataElement(data){
		var _this = this;
		Object.keys(data).forEach(name => {
			var model = _this.getModel(name);
			if(model != null){
				if(model.element.hasAttribute('data-formatter')){
					var fn = model.element.getAttribute('data-formatter');
					var value = data[name];
					model.element.innerHTML = eval(`${fn}(${value})`);
				} else {
					model.element.innerHTML = data[name];
				}
			}
		})
	}
	
	serialize(data, bool){
		if(bool == null) bool = false;
		if(data == null) data = this.getData();
		
		var serial = (bool ? '?search=' : '');
		
		serial += encodeURI(JSON.stringify(data));
		
		return serial;
	}
	
	reset(){
		var _this = this;
		this.lstModel.forEach(field => {
			var name = field.key;
			var type = field.type;
			var tag = field.tag;
			var classType = field.classType;
			var elem = field.element;
			if(_this[name] != null){
				switch(classType){
				case 'datepicker':
					 _this[name].setDate(null);
					break;
				case 'money':
					_this[name].setMoney(null);
					break;
				default:
					switch(type){
					case 'checkbox':
						_this[name].checked(false);
						break;
					case 'radio':
						_this[name].forEach(row => {
							row.checked = false;
						});
						break;
					default:
						_this[name].val(null);
						break;
					}
					break;
				}
			}
		});
	}
	
	disabledAll(bool){
		if(bool == undefined) bool = true;
		var lstModel = this.form.querySelectorAll(`[data-form-model]`);
		lstModel.forEach(model => {
			model.disabled = bool;
		});
		
	}
	
	readonlyAll(bool){
		if(bool == undefined) bool = true;
		var lstModel = this.form.querySelectorAll(`[data-form-model]`);
		lstModel.forEach(model => {
			model.readOnly = bool;
		});
		
	}
	
	setCombo(lstModel, options){
		var _this = this;
		var lstTemp = lstModel.split('|');
		lstTemp.forEach(model => {
			var model = _this[model];
			if(model != null){
				model.setCombo(options);
			}
		})
	}
	
	setComboServer(lstModel, url, options){
		var _this = this;
		var lstTemp = lstModel.split('|');
		lstTemp.forEach(model => {
			var model = _this[model];
			if(model != null){
				model.setComboServer(url, options);
			}
		})
	}
}

//=================== CATALOGO ==================
class CatalogoSia {
	
	static cdCatalogo(cdCatalogo, model, options){
		if(typeof model === 'string') model = new Model(field); 
		
		Ajax.get(`CatalogoSiaService/lstCatalogo/cdCatalogo/${cdCatalogo}`).done(data => {
			if(Ajax.statusOK(data, false)){
				if(options == undefined){
					model.setCombo({
						data: data.body,
						value: 'cdDetCatalogo',
						text: 'nbValor',
						firstOption: '-- Seleccione --'
					});
				} else {
					if(options.data == null) options.data = data.body;
					
					model.setCombo(options);
				}
			} else {
				model.setCombo('error');
			}
		});
	}
	
	static buscar(path, model, options){
		if(typeof model === 'string') model = new Model(field); 
		
		Ajax.get(`CatalogoSiaService/${path}`).done(data => {
			if(Ajax.statusOK(data, false)){
				if(options == undefined){
					model.setCombo({
						data: data.body,
						value: 'cdDetCatalogo',
						text: 'nbValor',
						firstOption: '-- Seleccione --'
					});
				} else {
					if(options.data == null) options.data = data.body;
					
					model.setCombo(options);
				}
			} else {
				model.setCombo('error');
			}
		});
	}
}

class Script {
	constructor(options){
		this.host = `${Session.get('baseUrlFront')}/`;
		this.src = null;
		this.script = null;
		this.status = 0;
		this.options(options);
	}
	
	init(){
		this.script = document.createElement('script');
		this.script.src = this.host + this.src;
		this.script.async = false;
		this.script.defer = true;
		document.body.append(this.script);
		this.status = 1;
	}
	
	reload(){
		if(this.script == null) throw 'Script is NULL';
		document.body.removeChild(this.script);
		this.init();
	}
	
	options(options){
		if(options == null) throw 'Error: options is NULL';
		
		if(typeof options === 'string') {
			this.src = options;
		} else { 
			if(options != null){
				if(options.host != null) this.host = options.host;
				if(options.src != null) this.src = options.src;
			}
		}
	}
	
}

//=================== SELECT  ===================
(function($) {
	
	var DEFAULTS = {
		concatText: ' - ',
		concatValue: '|',
		concatTitle: ' - ',
		firstOption: '-- Seleccione --',
		stFirst: true,
		push: false
	}
	
	$.fn.select = function(options){
		
		this.each((index, row) => {
			var _this = $(row);
			if(options == null) throw 'Options es NULL';
			
			if(typeof options === 'string'){
				switch(options){
				case 'error':
					_this.html(`<option value="-1">Ocurri\u00f3 un error</option>`);
					break;
				case 'remove':
					_this.html(`<option value="-1">${DEFAULTS.firstOption}</option>`);
					break;
				}
			} else {
				if(!options.push) _this.html('');
				
				var data = options.data;
				
				if(options.value == null) throw 'options.value es NULL';
				if(options.text == null) throw 'options.text es NULL';
				
				var value = options.value.split('|');
				var text = options.text.split('|');
				
				var title = null;
				if(options.title != null) title = options.title.split('|');
				
				Object.keys(DEFAULTS).forEach(name => {
					if(options[name] == null) options[name] = DEFAULTS[name];
				});
				
				if(!options.push){
					if(options.stFirst) _this.append(`<option value="-1">${options.firstOption}</option>`);
				}
				
				data.forEach(el => {
					var valueOption = '';
					for(var i = 0; i < value.length; i++){
						if(i == (value.length - 1)){
							valueOption += el[value[i]];
						} else {
							valueOption += el[value[i]] + options.concatValue;
						}
					}
					
					var textOption = '';
					for(var i = 0; i < text.length; i++){
						if(i == (text.length - 1)){
							textOption += el[text[i]];
						} else {
							textOption += el[text[i]] + options.concatText;
						}
					}
					
					var textTitle = '';
					if(title != null){
						textTitle = 'title="'
						for(var i = 0; i < title.length; i++){
							if(i == (title.length - 1)){
								textTitle += el[title[i]];
							} else {
								textTitle += el[title[i]] + options.concatTitle;
							}
						}
						textTitle += '"';
					}
					
					_this.append(`<option value="${valueOption}" ${textTitle}>${textOption}</option>`);
				});
			}
		})
	};
	
}( jQuery ));