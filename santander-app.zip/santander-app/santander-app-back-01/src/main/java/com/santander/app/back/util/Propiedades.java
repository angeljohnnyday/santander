package com.santander.app.back.util;

public class Propiedades {

}
