package com.santander.app.back.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class VistaRapidaSiaDTO {
	private String mePracticas;
	private String transaccion;
	private String nuFolio;
	private String nuFolioSistema;
	private String cdCliente;
	private String nbCliente;
	private String nuCuenta;
	private Date fhDeteccion;
	private Date fhReporte;
	private Date fhTransaccion;
	private Date fhOperacion;
	private String nbOficina;
	private String cdEmpleado;
	private String nbEmpleado;
	private String nbMercado;
	private String nbDivision;
	private BigDecimal imLocal;
	private BigDecimal importe;
	private String opinion;
	private Date fhProceso;
	private Date fhAlerta;
	private String stEstado;
	private String nuIdentificacion;
	private String vigIndentificacion;
	private String autIdentificacion;
	private String cdDivisa;
	private String tipoReporte;
	private String nbBanca;
	private String nbSistema;
	private String tpOperacion;
	private String nbOperacion;
	private String tpInsMonetario;
	private Date fhNacimiento;
	private Date fhApertura;
	private String cdRfc;
	private String cdCurp;
	private String tpCuenta;
	private String nbProducto;
}
