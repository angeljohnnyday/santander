package com.santander.app.back.srv;

import java.math.BigDecimal;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.santander.app.back.util.Response;

@Path("/CasosPendientesSiaService")
public interface CasosPendientesSiaService {
	
	@GET
	@Path("/lstCasos/{cdUsuario}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstCasos(
		@PathParam("cdUsuario") BigDecimal cdUsuario,
		@QueryParam("limit") Integer limit,
		@QueryParam("offset") Integer offset,
		@QueryParam("name") String name,
		@QueryParam("order") String order,
		@QueryParam("q") String q
	);
	
}
