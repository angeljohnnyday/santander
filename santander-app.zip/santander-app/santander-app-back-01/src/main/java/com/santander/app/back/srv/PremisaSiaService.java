package com.santander.app.back.srv;

import java.math.BigDecimal;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.santander.app.back.dto.PremisaSiaDTO;
import com.santander.app.back.util.Response;

@Path("/PremisaSiaService")
public interface PremisaSiaService {
	
	@GET
	@Path("/lstPremisas/stCompartido/{stCompartido}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstPremisasByStCompartido(
		@PathParam("stCompartido") String stCompartido
	);
	
	@GET
	@Path("/lstDecisionPremisa")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstDecisionPremisa();
	
	@GET
	@Path("/lstAccionPremisa")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstAccionPremisa();
	
	@PUT
	@Path("/guardarPremisa")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> guardarPremisa(
		PremisaSiaDTO premisaSiaDTO
	);
	
	@PUT
	@Path("/guardarPremisa/{cdPremisa}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> guardarPremisa(
		@PathParam("cdPremisa") BigDecimal cdPremisa,
		PremisaSiaDTO premisaSiaDTO
	);
	
	@DELETE
	@Path("/eliminarPremisa/{cdPremisa}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> eliminarPremisa(
		@PathParam("cdPremisa") BigDecimal cdPremisa
	);
	
}
