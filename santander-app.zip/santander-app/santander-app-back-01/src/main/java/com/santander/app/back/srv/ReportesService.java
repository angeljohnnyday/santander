package com.santander.app.back.srv;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.santander.app.back.util.Response;

@Path("/ReportesService")
public interface ReportesService {
	
	@GET
	@Path("/lstReportes")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstReportes();
	
	@GET
	@Path("/lstReportesTable")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstReportes(
		@QueryParam("limit") Integer limit,
		@QueryParam("offset") Integer offset,
		@QueryParam("search") String search,
		@QueryParam("name") String name, 
		@QueryParam("order") String order
	);
	
	@GET
	@Path("/lstTpReporte")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstTpReporte();
	
	@GET
	@Path("/lstDetalleTpReporte/{tpReporte}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstDetalleTpReporte(
		@PathParam("tpReporte") String tpReporte
	);

	
	@GET
	@Path("/getDetalleReporte/{tpReporte}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> getDetalleReporte(
		@PathParam("tpReporte") String tpReporte
	);

	
	@GET
	@Path("/getDetalleReporteAsignado/cdReporte/{cdReporte}/tpReporte/{tpReporte}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> getDetalleReporteAsignado(
		@PathParam("cdReporte") String cdReporte,
		@PathParam("tpReporte") String tpReporte
	);

	
	@GET
	@Path("/getDetalleReporteNoAsignado/cdReporte/{cdReporte}/tpReporte/{tpReporte}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> getDetalleReporteNoAsignado(
		@PathParam("cdReporte") String cdReporte,
		@PathParam("tpReporte") String tpReporte
	);
}
