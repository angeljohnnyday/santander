function formatterDate(value, row, index) {
	var date = "";
	
	if( value != null && value != '' && value != undefined && value != 'null'){
		datePicker.setDate(new Date(value));
		var date = datePicker.val();
		datePicker.val(null);
	}
	
	return date;
}

function formatterMoney(value, row, index) {
	var money = "0";
	
	if( value != null && value != '' && value != 'null'){
		maskMoney.setMoney(value);
		money = maskMoney.val();
		maskMoney.val(null);
	}
	
	return money;
}

function formatterNumber(value, row, index){
	var number = "0";
	
	if( value != null && value != '' && value != 'null'){
		maskNumber.setMoney(value);
		number = maskNumber.val();
		maskNumber.val(null);
	}
	
	return number;
}

function formatterTotal() {
	return 'Total:';
}

function formatterSumaOperacion(data, field){
	var field = this.field;
	var suma = 0;
	data.forEach((row)=>{
		if(row[field] != null){
			suma += row[field];
		}
	});
	return suma;
}

function formatterSumaMonto(data, field){
	var field = this.field;
	var suma = 0;
	data.forEach((row)=>{
		if(row[field] != null){
			suma += row[field];
		}
	});
	
	if(suma != 0) suma = parseFloat(suma.toFixed(2));
	
	return formatterMoney(suma);
}

function formatterSumaPorcentaje(data, field){

	var field = this.field;
	var suma = 0;
	data.forEach((row)=>{
		if(row[field] != null){
			suma += row[field];
		}
	});
	
	if(suma != 0) suma = Math.round(suma.toFixed(2));
	
	return `${suma}%`;
}

function formatterPorcentaje(value, row, index){
	value = formatterMoney(value);
	return `${value}%`;
}

function formatterSumaPromedio(data, field){
	var field = this.field;
	var suma = 0;
	
	data.forEach((row)=>{
		if(row[field] != null){
			suma += row[field];
		}
	});
	
	if(suma != 0) suma = parseFloat(suma.toFixed(2));
	
	return formatterMoney(suma);
}

function formatterPromedio(data, field){
	var field = this.field;
	var suma = 0;
	var total = 0;
	
	data.forEach((row)=>{
		if(row[field] != null && row[field] != 0){
			total ++;
			suma += row[field];
		}
	});

	var promedio = (suma / total);
	if(promedio != 0) promedio = parseFloat(promedio.toFixed(2));
	
	return formatterMoney(promedio);
}