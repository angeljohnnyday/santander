package com.santander.app.back.util;

public class Constantes {
	public final static String EJEMPLO = "vengo del back";
}
