package com.santander.app.back.dto;

import java.math.BigDecimal;
import lombok.Data;

@Data
public class MecanicaOperacionalSiaDTO {
	private String cdCuadroTC;
	private String nbConceptoTC;
	private BigDecimal nuMovimientosTC;
	private BigDecimal imMontoTC;
	private BigDecimal nuPorcentajeTC;
	private BigDecimal nuPromedioTC;
	private BigDecimal nuMovimientosATC;
	private BigDecimal imMontoATC;
	private BigDecimal nuPorcentajeATC;
	private BigDecimal nuPromedioATC;
	
	
	private String nbConceptoTCF;
	private BigDecimal nuMovimientosTCF;
	private BigDecimal imMontoTCF;
	private BigDecimal nuPorcentajeTCF;
	private BigDecimal nuPromedioTCF;
	private BigDecimal nuMovimientosATCF;
	private BigDecimal imMontoATCF;
	private BigDecimal nuPorcentajeATCF;
	private BigDecimal nuPromedioATCF;
}
