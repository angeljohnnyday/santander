package com.santander.app.back.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.CatalogoSiaDTO;
import com.santander.app.back.dto.DetalleReportesDTO;
import com.santander.app.back.dto.ReportesDTO;
import com.santander.app.back.util.QueryUtil;

@Component
public class ReportesDAO {
	@PersistenceContext private EntityManager em;
	@Autowired private QueryUtil queryUtil;
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public List<ReportesDTO> lstReportes() throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstReportes")); 
		query.unwrap(NativeQuery.class)
		.addScalar("cdReporte")
		.addScalar("nbReporte",StringType.INSTANCE)
		.addScalar("nbTipo",StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(ReportesDTO.class));
		
		return query.getResultList();
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public List<ReportesDTO> lstReportes(Integer limit, Integer offset, String name, String order) throws Exception {
		String consulta = Consultas.getConsultaSia("lstReportes");
		consulta += queryUtil.orderBy(name, "nbReporte", order, "ASC");
		
		Query query = em.createNativeQuery(consulta); 
		query.unwrap(NativeQuery.class)
		.addScalar("cdReporte")
		.addScalar("nbReporte",StringType.INSTANCE)
		.addScalar("nbTipo",StringType.INSTANCE)
		.addScalar("nbUsuario",StringType.INSTANCE)
		.addScalar("tpReporte")
		.setResultTransformer(Transformers.aliasToBean(ReportesDTO.class));
		query.setFirstResult(offset);
		query.setMaxResults(limit);
		
		return query.getResultList();
	}
	
	public Integer totalLstReportes() throws Exception {
		String consulta = "SELECT COUNT(1) FROM ("+ Consultas.getConsultaSia("lstReportes")+ ")";	
		Query query = em.createNativeQuery(consulta);

		return ((Number) query.getSingleResult()).intValue();
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public List<CatalogoSiaDTO> lstTpReporte() throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstTpReporte"));
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor",StringType.INSTANCE)
		.addScalar("nbValor",StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));
		
		return query.getResultList();
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public List<CatalogoSiaDTO> lstDetalleTpReporte(String tpReporte) throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstDetalleTpReporte"));
		query.setParameter("tpReporte", tpReporte);
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor",StringType.INSTANCE)
		.addScalar("nbValor",StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));
		
		return query.getResultList();
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public List<ReportesDTO> getDetalleReporte(String tpReporte) throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getDetalleReporte"));
		query.setParameter("tpReporte", tpReporte);
		query.unwrap(NativeQuery.class)
		.addScalar("cdReporte", BigDecimalType.INSTANCE)
		.addScalar("nbReporte", StringType.INSTANCE)
		.addScalar("cdTipoReporte", BigDecimalType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(ReportesDTO.class));
		
		return query.getResultList();
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public List<DetalleReportesDTO> getDetalleReporteAsignado(String cdReporte, String tpReporte) throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getDetalleReporteAsignado"));
		query.setParameter("cdTpReporte", tpReporte);
		query.setParameter("cdReporte", cdReporte);
		query.unwrap(NativeQuery.class)
		.addScalar("nbColumna", StringType.INSTANCE)
		.addScalar("cdColumna", BigDecimalType.INSTANCE)
		.addScalar("nbOrden", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(DetalleReportesDTO.class));
		
		return query.getResultList();
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public List<DetalleReportesDTO> getDetalleReporteNoAsignado(String cdReporte, String tpReporte) throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getDetalleReporteNoAsignado"));
		query.setParameter("cdTpReporte", tpReporte);
		query.setParameter("cdReporte", cdReporte);
		query.unwrap(NativeQuery.class)
		.addScalar("nbColumna", StringType.INSTANCE)
		.addScalar("cdColumna", BigDecimalType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(DetalleReportesDTO.class));
		
		return query.getResultList();
	}
}
