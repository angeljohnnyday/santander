package com.santander.app.back.util;

import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class QueryUtil {
	public int Count (EntityManager em, String consulta) {
		try {
			String consultaCount = "SELECT COUNT(1) FROM ( "+ consulta +" )";
			Query query = em.createNativeQuery(consultaCount);
			return ((Number)query.getSingleResult()).intValue();
		} catch (Exception e) {
			log.error("ERROR: "+ e.getMessage());
			return 0;
		}
	}
	
	public Query maxSize(Query query, Integer offset, Integer limit) {
		query.setFirstResult(offset);
		query.setMaxResults(limit);
		return query;
	}
	
	public boolean value(String value) {
		return value != null && !value.trim().equals("");
	}
	
	public String Where(boolean condicion) {
		return " "+ (condicion ? "AND" : "WHERE") +" ";
	}
	
	public String orderBy(String name, String alterName, String order, String alterOrder) {
		return " ORDER BY " +(name != null && !"".equals(name) ? name : alterName)+ " "+ (order != null && !"".equals(order) ? order : alterOrder);
	}
	
	public String orderName(String name, String alter) {
		return " ORDER BY " +(name != null && !"".equals(name) ? name : alter);
	}
	
	public String orderAsc(String order, String alter) {
		return " "+(order != null && !"".equals(order) ? order : alter);
	}
}
