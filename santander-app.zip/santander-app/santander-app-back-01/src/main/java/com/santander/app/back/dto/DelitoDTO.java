package com.santander.app.back.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class DelitoDTO {
	private BigDecimal cdDelito;
	private String nbDelito;
	private String stDelito;
}
