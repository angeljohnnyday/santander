package com.santander.app.sia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Gestion-Alertas")
public class GestionAlertasController {
	
	@GetMapping("/Casos-Pendientes")
	public String casosPendientes() {
		return "MSIAVEPEN01";
	}
	
	@GetMapping("/Casos-Pendientes/Vista-Rapida")
	public String casosPendientesVistaRapida() {
		return "MSIAVEALER01";
	}
	
	@GetMapping("/Casos-Pendientes/Analisis")
	public String casosPendientesAnalisis() {
		return "MSIAVEAN001";
	}
	
	@GetMapping("/Casos-Pendientes/Analisis/Movimientos")
	public String casosPendientesAnalisisMovimientos() {
		return "MSIAVEMOV01";
	}
}
