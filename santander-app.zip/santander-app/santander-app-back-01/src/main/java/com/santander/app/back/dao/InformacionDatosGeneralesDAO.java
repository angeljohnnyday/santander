package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.InformacionDatosGeneralesDTO;

@Component
public class InformacionDatosGeneralesDAO {
	@PersistenceContext private EntityManager em;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public InformacionDatosGeneralesDTO getDatosGenerales(BigDecimal cdCaso, String nuFolioAlerta) throws Exception {
		InformacionDatosGeneralesDTO informacionDatosGeneralesDTO = new InformacionDatosGeneralesDTO();
		List<InformacionDatosGeneralesDTO> resultado = new ArrayList<InformacionDatosGeneralesDTO>();
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getDatosGenerales"));
		query.setParameter("cdCaso", cdCaso);
		query.setParameter("nuFolioAlerta", nuFolioAlerta); 
		
		query.unwrap(NativeQuery.class)

		 .addScalar("nuFolio",StringType.INSTANCE)
		 .addScalar("nbConsultor",StringType.INSTANCE)
		 .addScalar("nuFolios",StringType.INSTANCE)
		 .addScalar("cdTipo",StringType.INSTANCE)
		 .addScalar("nuCasos",StringType.INSTANCE)
		 .addScalar("nuFolioBase",StringType.INSTANCE)
		 .addScalar("cdSistema",StringType.INSTANCE)
		 .addScalar("nuCuentaReportada",StringType.INSTANCE)
		 .addScalar("imReportado")
		 .addScalar("cdPrioridad",StringType.INSTANCE)
		 .addScalar("cdDivisa",StringType.INSTANCE)
		 .addScalar("fhOperacion",TimestampType.INSTANCE)
		 .addScalar("fhDeteccion",TimestampType.INSTANCE)
		 .addScalar("fhReporteBuzon",TimestampType.INSTANCE)
		 .addScalar("fhAsignacion",TimestampType.INSTANCE)
		 .addScalar("cdSesion",StringType.INSTANCE)
		 .addScalar("importeDivisa",StringType.INSTANCE)
		 .addScalar("cdPrioridadCed2",StringType.INSTANCE)
		 .addScalar("imReportadoNuevo")
		 .addScalar("importeDivisaCed2",StringType.INSTANCE)
		 .addScalar("cdInusual",StringType.INSTANCE)
		 .addScalar("opinionPrevia",StringType.INSTANCE)
		 .addScalar("decisionFinal",StringType.INSTANCE)
		 .addScalar("nuFolioAlerta",StringType.INSTANCE)
		 .addScalar("fhReconsideracion",TimestampType.INSTANCE)
		 .addScalar("nbMultibanca",StringType.INSTANCE)
		 .addScalar("cdSesionIn",StringType.INSTANCE)
		 
		.setResultTransformer(Transformers.aliasToBean(InformacionDatosGeneralesDTO.class));
		
		resultado = (List<InformacionDatosGeneralesDTO>) query.getResultList();
		
		if( !resultado.isEmpty() ){
			informacionDatosGeneralesDTO = resultado.get(0);	
		}
		
		return informacionDatosGeneralesDTO;
	}
}
