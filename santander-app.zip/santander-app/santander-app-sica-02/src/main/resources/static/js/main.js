$(document).ready(function(){
	validateSession();
	validatePage();
	datePicker.init();
	maskMoney.init();
	maskNumber.init({precision: 0});
});

function validateSession(){
	var usuarioDTO = Session.getUser();
	if(usuarioDTO == null){
		Screen.login();
	};
}

function validatePage(){
	var lstElement = document.querySelectorAll('#nav-menu #navbar-content a.d-none');
    for(menu of lstElement){
    	 var pathname = menu.getAttribute('href');
         if(new RegExp(pathname, 'g').test(window.location.href)){
         	Screen.login();
         }
    }
}

function showMenu(name){
	var total = Session.lstModulos().filter(moduloDTO => moduloDTO.nbModulo == name).length;
	return (total == 0 ? 'd-none' : '');
}

function stPerfil (){
	return (Session.getUser().cdPerfil2 == null ? 'd-none' : '');
};

$(document).on({
	ajaxStart: function(){
		$("body").addClass("loading");
	},
	ajaxStop: function(event, request, settings){
		$("body").removeClass("loading");
	},
	ajaxError: function(event, jqxhr, settings, thrownError){
		Ajax.statusOK({
			message: 'Estimado usuario, ocurrió un error en el sistema por favor intente mas tarde.',
			statusCodeValue: 500,
			errorException: null
//			errorException: JSON.parse(jqxhr.responseText)
		});
	}
});