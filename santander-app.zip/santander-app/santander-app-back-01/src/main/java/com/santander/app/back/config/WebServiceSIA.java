package com.santander.app.back.config;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.springframework.context.annotation.Configuration;

import com.santander.app.back.srv.CasosPendientesSiaServiceImpl;
import com.santander.app.back.srv.CatalogoSiaServiceImpl;
import com.santander.app.back.srv.ConsensoSiaServiceImpl;
import com.santander.app.back.srv.ConsultaCasosSiaServiceImpl;
import com.santander.app.back.srv.DelitoServiceImpl;
import com.santander.app.back.srv.InformacionAdministrativaServiceImpl;
import com.santander.app.back.srv.InformacionOperativaServiceImpl;
import com.santander.app.back.srv.PremisaSiaServiceImpl;
import com.santander.app.back.srv.ReportesServiceImpl;

@Configuration
@ApplicationPath("/services/rest/sia")
public class WebServiceSIA extends Application {
	@Override
    public Set<Object> getSingletons() {
		final Set<Object> singletons = new HashSet<>();
        singletons.add(new ConsensoSiaServiceImpl());
        singletons.add(new CatalogoSiaServiceImpl());
        singletons.add(new PremisaSiaServiceImpl());
        singletons.add(new CasosPendientesSiaServiceImpl());
        singletons.add(new ConsultaCasosSiaServiceImpl());
        singletons.add(new InformacionAdministrativaServiceImpl());
        singletons.add(new InformacionOperativaServiceImpl());
        singletons.add(new ReportesServiceImpl());
        singletons.add(new DelitoServiceImpl());
        return singletons;
    }
}
