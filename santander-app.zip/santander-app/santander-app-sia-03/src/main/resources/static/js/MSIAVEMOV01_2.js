var tableMuestra = new Table({
	server: {
		muestraAbonos:{
			option:{
				url: `${Session.get('baseUrl')}/InformacionOperativaService/lstMovMuestra/${TP_ABONO}/${movDTO.cdCasoSica}/${movDTO.cdCaso}/${movDTO.nuCuenta}`,
				pageSize: 5,
				pageList: [5, 25, 50, 100],
				search: true,
				checkboxHeader: true
			}
		},
		muestraCargos:{
			option:{
				url: `${Session.get('baseUrl')}/InformacionOperativaService/lstMovMuestra/${TP_CARGO}/${movDTO.cdCasoSica}/${movDTO.cdCaso}/${movDTO.nuCuenta}`,
				pageSize: 5,
				pageList: [5, 25, 50, 100],
				search: true,
				checkboxHeader: true
			}
		}
	},
	formatter:{
		tipoMov(value, row, index){
			if(value != null){
				return (value == "H" ? "ABONO" : "CARGO")
			} else {
				return '';
			}
		}
	},
	ready($this){
		var changeTables = () => {
			var totalAbono = $this.muestraAbonos.getSelections().length;
			var totalCargo = $this.muestraCargos.getSelections().length;
			$('#btnQuitaMuestra').prop('disabled', totalAbono == 0 && totalCargo == 0);
		}
		
		$this.muestraAbonos.checkEvent(changeTables);
		$this.muestraCargos.checkEvent(changeTables);
	}
});