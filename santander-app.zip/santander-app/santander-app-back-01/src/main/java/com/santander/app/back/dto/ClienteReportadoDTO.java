package com.santander.app.back.dto;

import java.util.Date;

import lombok.Data;

@Data
public class ClienteReportadoDTO {
	private String nuCliente;
	private String nbCliente;
	private String apPaterno;
	private String apMaterno;
	private String nuTelParticular;
	private String nuTelOficina;
	private String fhNacimiento;
	private Date fhAntiguedad;
	private String nuRFC;
	private String nbDomicilio;
	private String nbNacionalidad;
	private String nbCiudadPoblacion;
	private String nbEntidadFederativa;
	private String fhRepotpPersonarteBuzon;
	private String nbActividadBanxico;
	private String nbActividadBanxicoCed2;
	private String tipoPersona;
	private String cdSectorD;
	private String nbSegmentoCte;
}
