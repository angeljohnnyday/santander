package com.santander.app.back.srv;

//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.PerfiladoDAO;
import com.santander.app.back.dto.UsuarioDTO;
import com.santander.app.back.util.Response;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PerfiladoServiceImpl implements PerfiladoService {
	@Autowired private PerfiladoDAO perfiladoDAO;

	@Override
	public Response<Object> consultarUsuario(String nbCveRed) {
		try {
			UsuarioDTO usuarioDTO = perfiladoDAO.getUsuario(nbCveRed, "null");
			
			if(usuarioDTO == null) {
				return new Response<>(Mensaje.getText("OK"), HttpStatus.NOT_FOUND);
			}

//			HttpSession session = request.getSession();
//			if(session != null) {
//				session.removeAttribute("userDTO");
//				session.setAttribute("userDTO", usuarioDTO.getNbCveRed());
//			}
			
			return new Response<>(usuarioDTO, Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> consultarUsuario(String nbCveRed, String cdPerfil) {
		try {
			UsuarioDTO usuarioDTO = perfiladoDAO.getUsuario(nbCveRed, cdPerfil);
			
			if(usuarioDTO == null) {
				return new Response<>(Mensaje.getText("OK"), HttpStatus.NOT_FOUND);
			}
			
//			HttpSession session = request.getSession();
//			if(session != null) {
//				session.removeAttribute("userDTO");
//				session.setAttribute("userDTO", usuarioDTO.getNbCveRed());
//			}
			
			return new Response<>(usuarioDTO, Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
