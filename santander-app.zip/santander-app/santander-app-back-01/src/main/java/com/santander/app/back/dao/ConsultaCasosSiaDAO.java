package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.VistaRapidaSiaDTO;

@Component
public class ConsultaCasosSiaDAO {
	@PersistenceContext EntityManager em;
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public VistaRapidaSiaDTO getVistaRapida(BigDecimal cdCaso, String cdSistema, String cdAlerta, String nuCuenta, Integer historico) throws Exception{
		List<VistaRapidaSiaDTO> resultado = new ArrayList<VistaRapidaSiaDTO>();
		
		Query query;
		
		if(historico == 1) {
			query = em.createNativeQuery(Consultas.getConsultaSia("getVistaRapidaHistorico"));
			query.setParameter("cdCaso", cdCaso);
		} else {
			query = em.createNativeQuery(Consultas.getConsultaSia("getVistaRapida"));
		    query.setParameter("cdCaso", cdCaso);
			query.setParameter("cdSistema", cdSistema);
			query.setParameter("cdAlerta", cdAlerta);
			query.setParameter("nuCuenta", nuCuenta);
		}
		
		query.unwrap(NativeQuery.class)
		.addScalar("mePracticas", StringType.INSTANCE)
		.addScalar("transaccion", StringType.INSTANCE)
		.addScalar("nuFolio", StringType.INSTANCE)
		.addScalar("nuFolioSistema", StringType.INSTANCE)
		.addScalar("cdCliente", StringType.INSTANCE)
		.addScalar("nbCliente", StringType.INSTANCE)
		.addScalar("nuCuenta", StringType.INSTANCE)
		.addScalar("fhDeteccion", TimestampType.INSTANCE)
		.addScalar("fhReporte", TimestampType.INSTANCE)
		.addScalar("fhTransaccion", TimestampType.INSTANCE)
		.addScalar("fhOperacion", TimestampType.INSTANCE)
		.addScalar("nbOficina", StringType.INSTANCE)
		.addScalar("cdEmpleado", StringType.INSTANCE)
		.addScalar("nbEmpleado", StringType.INSTANCE)
		.addScalar("nbMercado", StringType.INSTANCE)
		.addScalar("nbDivision", StringType.INSTANCE)
		.addScalar("imLocal")
		.addScalar("importe")
		.addScalar("opinion", StringType.INSTANCE)
		.addScalar("fhProceso", TimestampType.INSTANCE)
		.addScalar("fhAlerta", TimestampType.INSTANCE)
		.addScalar("stEstado", StringType.INSTANCE)
		.addScalar("nuIdentificacion", StringType.INSTANCE)
		.addScalar("vigIndentificacion", StringType.INSTANCE)
		.addScalar("autIdentificacion", StringType.INSTANCE)
		.addScalar("cdDivisa", StringType.INSTANCE)
		.addScalar("tipoReporte", StringType.INSTANCE)
		.addScalar("nbBanca", StringType.INSTANCE)
		.addScalar("nbSistema", StringType.INSTANCE)
		.addScalar("tpOperacion", StringType.INSTANCE)
		.addScalar("nbOperacion", StringType.INSTANCE)
		.addScalar("tpInsMonetario", StringType.INSTANCE)
		.addScalar("fhNacimiento", TimestampType.INSTANCE)
		.addScalar("fhApertura", TimestampType.INSTANCE)
		.addScalar("cdRfc", StringType.INSTANCE)
		.addScalar("cdCurp", StringType.INSTANCE)
		.addScalar("tpCuenta", StringType.INSTANCE)
		.addScalar("nbProducto", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(VistaRapidaSiaDTO.class));
		
		resultado = query.getResultList();
		
		if(!resultado.isEmpty()) {
			return resultado.get(0);
		}
		
		return new VistaRapidaSiaDTO();
	}
	
}
