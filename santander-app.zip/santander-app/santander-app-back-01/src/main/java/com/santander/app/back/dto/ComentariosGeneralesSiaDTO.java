package com.santander.app.back.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ComentariosGeneralesSiaDTO {
	private BigDecimal cdCasoSia;
	private String  cdPaginaWeb;
	private String  nbPaginaWeb;
	private String  cdMapCasa;
	private String  cdMapEdificio;
	private String  cdMapTerreno;
	private String  cdMapLocal;
	private String  cdMapLogo;
	private String  cdMapRural;
	private String  cdMapNoPreciso;
	private String  cdMapNoImg;
	private String  nbMaps;
	private String cdOtrNoCte;
	private String  nbOtrNoCte;
	private String  cdNotPeriodico;
	private String  nbNotPeriodico;
	
	private String stCteCali;
	private String stParRepPrevio;
	private String stCteAltoRiesgo;
	private String stParAltoRiesgo;
	private String stCteLstPerBloq;
	private String stCteLstPeps;
	private String stCtaRepBloq;
	
	private String nbCteCali;
	private String nbParRepPrevio;
	private String nbCteAltoRiesgo;
	private String nbParAltoRiesgo;
	private String nbCteLstPerBloq;
	private String nbCteLstPeps;
	private String nbCtaRepBloq;
}
