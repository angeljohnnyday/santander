var actionEvents = {
	'click .detailAlerta': function(e, value, row, index){
		Session.set('casoDTO', row);
		
		Screen.open({
			path: `${Session.get('baseUrlFront')}/Casos/Vista-Rapida`,
			name: `Vista_Rapida: ${row.cdCaso}`
		});
	},
	'click .detailCaso': function(e, value, row, index){
		Session.set('casoDTO', row);
		
		Screen.open({
			path: `${Session.get('baseUrlFront')}/Casos/Analisis`,
			name: `Analisis_Caso: ${row.cdCaso}`
		});
	}
};

var cdUsuario = Session.getUser().cdUsuario;

$(function(){
	dateYear.yearInit();
	dateYear.changeYear(lstSesionActaByCdUsuarioActa);
	
	lstPrioridad();
	lstAppOringen();
	
	tableCasosPend.setTable({
		url: `${Session.get('baseUrl')}/CasosPendientesSiaService/lstCasos/${cdUsuario}`,
		pagination: false
	});
})

//=================== FORMATTERS ===================
function formatterDetailConsultadeCasos(value, row, index){
	var nbSistema = row.nbSistema==null ? "" : row.nbSistema;
	var nuCuenta = row.nuCuenta == null ? "": row.nuCuenta;
	var nbConsultor = row.nbConsultor == null ? "" : row.nbConsultor;
	var nbActa = row.nbActa == null ? "" : row.nbActa;
	var fhAsignacion = row.fhAsignacion == null ? "" : formatterDate(row.fhAsignacion);
	var tpCaso = row.tpCaso == null ? "" : row.tpCaso;
	
	return [
		'<i class="fas fa-angle-right text-info"></i><b>Sesi&oacute;n-Acta: </b>'+nbActa+'<br />',
		'<i class="fas fa-angle-right text-info"></i><b>Sistema: </b>'+nbSistema+'<br />',
		'<i class="fas fa-angle-right text-info"></i><b>No.Cuenta: </b>'+nuCuenta+'<br />',
		'<i class="fas fa-angle-right text-info"></i><b>Consultor: </b>'+nbConsultor+'<br />',
		'<i class="fas fa-angle-right text-info"></i><b>Fecha Asignaci&oacute;n: </b>'+fhAsignacion+'<br />',
		'<i class="fas fa-angle-right text-info"></i><b>Tipo de caso: </b>'+tpCaso + '<br />'
	].join('');		
}

function formatterEstatus(value, row, index){
	if(value == "AS"){
		return ['ASIGNADO'].join('');
	}else if(value == "RE"){
		return ['REANALISIS'].join('');
	}else{
		return [''].join('');
	}
}

function formtatterIcons(value, row, index){
	return [
		'<a class="detailAlerta" href="javascript:void(0)" title="Vista Rapida"><i class="far fa-list-alt text-info"></i></a>',
		'<a class="detailCaso" href="javascript:void(0)" title="Análisis del Caso"><i class="far fa-clipboard text-info"></i></a>',
		'<a class="detailCedula" href="javascript:void(0)" title="Cedula del Caso"><i class="fas fa-clipboard-list text-info"></i></a>',
		'<a class="detailIX-X" href="javascript:void(0)" title="Automatico IX-X"><i class="far fa-file-alt text-info"></i></a>',
	].join('');
}

function formatterNuDiasReportar(value, row, index){
	var code = null
	if(value != null){
		var fhHoy = new Date().getTime();
		
		var diff = fhHoy - row.fhAlerta;
		var dias = 60 - (Math.floor(diff / (1000*60*60*24)));
		
		var fhAlerta = formatterDate(row.fhAlerta);
		var color = '';
		
		if(dias <= 60 & dias >= 21){
			color = 'badge-info'; 
		}else if(dias <= 20 & dias >= 6){
			color = 'badge-secondary';
		}else if(dias <= 5 & dias >= 1){
			color = 'badge-danger';
		}else{
			color = 'badge-danger';
		}
		
		code = `${fhAlerta} <span class="badge badge-pill ${color}">${dias}</span>`;
	}
	
	return [code].join('');
}

//=================== RESET FORM PARAM ===================
function resetFormBusq(){
	formParam.nuActa.setCombo('remove');
	lstPrioridad();
	lstAppOringen();
	formParam.reset();
	
	tableCasosPend.refresh(`${Session.get('baseUrl')}/CasosPendientesSiaService/lstCasos/${cdUsuario}`);
}

//=================== CHANGE BTN CALENDAR YEAR ===================
function lstSesionActaByCdUsuarioActa(fhAnio) {
	Ajax.get(`CatalogoSiaService/lstSessionActa/cdUsuario/${cdUsuario}/fhAnio/${fhAnio}`).done(function(data){
		if(Ajax.statusOK(data, false)){
			formParam.nuActa.setCombo({
				data: data.body,
				value: 'nbValor',
				text: 'nbValor',
				firstOption: `-- Seleccione - ${fhAnio} --`
			});
		} else {
			formParam.nuActa.setCombo('error');
		}
	});
}

function buscarLstCasos(){
	var paramDTO = formParam.getData();
	if(paramDTO.imMontoDel == 0) paramDTO.imMontoDel = null;
	if(paramDTO.imMontoAl == 0) paramDTO.imMontoAl = null;
	
	var filtro = formParam.serialize(paramDTO, true);
	var url = `${Session.get('baseUrl')}/CasosPendientesSiaService/lstCasos/${cdUsuario}${filtro}`;
	
	tableCasosPend.refresh(url);
}

// =================== SERVICES ===================
function lstPrioridad(){
	Ajax.get('CatalogoSiaService/lstCatalogo/cdCatalogo/14').done(function(data){
		if(Ajax.statusOK(data, false)){
			formParam.cdPrioridad.setCombo({
				data: data.body,
				value: 'cdDetCatalogo',
				text: 'cdDetCatalogo|nbValor'
			});
		} else {
			formParam.cdPrioridad.setCombo('error');
		}
	});
}

function lstAppOringen(){
	Ajax.get('CatalogoSiaService/lstCatalogoSistema').done(function(data){
		if(Ajax.statusOK(data, false)){
			formParam.cdAppOrigen.setCombo({
				data: data.body,
				value: 'cdValor',
				text: 'nbValor'
			});
		} else {
			formParam.cdAppOrigen.setCombo('error');
		}
	});
}