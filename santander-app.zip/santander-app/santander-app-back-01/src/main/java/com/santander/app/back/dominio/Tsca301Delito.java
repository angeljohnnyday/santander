package com.santander.app.back.dominio;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@Table(name =  "TSCA301_DELITO", schema = "GORAPR")
public class Tsca301Delito {
	@Id
	@NotNull
    @SequenceGenerator(name = "SQ_TSCA301", sequenceName = "SQ_TSCA301", schema = "GORAPR", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_TSCA301")
	@Column(name = "CD_DELITO")
	private BigDecimal cdDelito;
	
	@Column(name = "NB_DELITO")
	private String nbDelito;
	
	@Column(name = "ST_DELITO")
	private String stDelito;
}
