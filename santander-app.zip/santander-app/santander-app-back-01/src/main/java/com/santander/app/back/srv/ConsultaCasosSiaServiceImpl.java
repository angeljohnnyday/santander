package com.santander.app.back.srv;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.ConsultaCasosSiaDAO;
import com.santander.app.back.util.Response;
public class ConsultaCasosSiaServiceImpl implements ConsultaCasosSiaService {
	@Autowired private ConsultaCasosSiaDAO consultaCasosSiaDAO;

	@Override
	public Response<Object> getVistaRapida(BigDecimal cdCaso, String cdSistema, String cdAlerta, String nuCuenta, Integer historico) {
		try {
			return new Response<>(consultaCasosSiaDAO.getVistaRapida(cdCaso, cdSistema, cdAlerta, nuCuenta, historico), Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
