package com.santander.app.back.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:messages.properties")
public class Mensaje {
	@Bean
    public MyBean myBean () {
        return new MyBean();
    }

    @SuppressWarnings("resource")
	public static String getText(String property) {
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Mensaje.class);
    	return context.getBean(MyBean.class).showProp(property);
    }
    
    public static class MyBean {
        @Autowired
        Environment env;

        public String showProp (String property) {
            return env.getProperty(property);
        }
    }
}
