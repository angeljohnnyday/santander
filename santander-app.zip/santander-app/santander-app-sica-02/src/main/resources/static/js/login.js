$(function(){
	Session.clean();
	Session.remove('cdUserTemp');
	Session.remove('cdPerfilTemp');
	validateLogin();
});

function inicio(){
	Session.set('cdUserTemp', Util.upper( $('#nbCveRed').val() ) );
	Screen.perfilado();
}

function validateLogin() {
	$('#formLogin').validate({
		rules: {
			nbCveRed: {
				required: true
			},
			nbPass: {
				required: true
			}
		},
		errorPlacement: function (error, element) {
			$(element).removeClass("border border-success");
			$(element).addClass("border border-danger");
		},
		success: function (label, element) {
			$(element).removeClass("border border-danger");
			$(element).addClass("border border-success");
		}
	});
}

function initLogin(){
	sessionStorage.clear();
	$("#btnAceptar").focus();
	Session.set("baseUrl", baseUrl);
    Session.set("baseUrlFront", baseUrlFront);
    Session.set("baseUrlBack", baseUrlBack);
}