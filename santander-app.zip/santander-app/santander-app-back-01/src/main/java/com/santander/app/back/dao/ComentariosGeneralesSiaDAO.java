package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.ComentariosGeneralesSiaDTO;

@Component
public class ComentariosGeneralesSiaDAO {
	@PersistenceContext private EntityManager em;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public ComentariosGeneralesSiaDTO getComentariosGenerales(BigDecimal cdCasoSia) throws Exception{
		ComentariosGeneralesSiaDTO comentariosGeneralesDTO = new ComentariosGeneralesSiaDTO();
		List<ComentariosGeneralesSiaDTO> resultado = new ArrayList<ComentariosGeneralesSiaDTO>();
		 
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getComentariosGenerales"));
		query.setParameter("cdCasoSia", cdCasoSia);
		
		query.unwrap(NativeQuery.class)
		 .addScalar("cdCasoSia")
		 .addScalar("cdPaginaWeb")
		 .addScalar("nbPaginaWeb")
		 .addScalar("cdMapCasa")
		 .addScalar("nbMaps")
		 .addScalar("cdOtrNoCte")
		 .addScalar("nbOtrNoCte")
		 .addScalar("cdNotPeriodico")
		 .addScalar("nbNotPeriodico")
		 .addScalar("stCteCali",StringType.INSTANCE)
		 .addScalar("stParRepPrevio",StringType.INSTANCE)
		 .addScalar("stCteAltoRiesgo",StringType.INSTANCE)
		 .addScalar("stParAltoRiesgo",StringType.INSTANCE)
		 .addScalar("stCteLstPerBloq",StringType.INSTANCE)
		 .addScalar("stCteLstPeps",StringType.INSTANCE)
		 .addScalar("stCtaRepBloq",StringType.INSTANCE)
		 .addScalar("nbCteCali")
		 .addScalar("nbParRepPrevio")
		 .addScalar("nbCteAltoRiesgo")
		 .addScalar("nbParAltoRiesgo")
		 .addScalar("nbCteLstPerBloq")
		 .addScalar("nbCteLstPeps")
		 .addScalar("nbCtaRepBloq")
		 .setResultTransformer(Transformers.aliasToBean(ComentariosGeneralesSiaDTO.class));
		
		resultado = (List<ComentariosGeneralesSiaDTO>)query.getResultList();
		
		if( !resultado.isEmpty() ){
			comentariosGeneralesDTO = resultado.get(0);	
		}
		
		return comentariosGeneralesDTO;
	}
}
