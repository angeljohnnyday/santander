package com.santander.app.back.util;

import lombok.Data;

@Data
public class Pagination {
	private Integer total;
	private Object rows;
}
