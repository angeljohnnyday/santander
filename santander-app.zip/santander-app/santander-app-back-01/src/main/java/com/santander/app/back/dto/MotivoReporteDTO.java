package com.santander.app.back.dto;

import lombok.Data;

@Data
public class MotivoReporteDTO {
	private String txMotivoReporte;
	private String txMotivoReporte2;
	private String txInusualidad;
}
