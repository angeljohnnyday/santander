var tableMov = new Table({
	server: {
		movimientos:{
			option:{
				url: `${Session.get('baseUrl')}/InformacionOperativaService/lstMovimientosSia/${movDTO.cdCasoSica}/${movDTO.nuCuenta}`,
				pageSize: 5,
				pageList: [5, 25, 50, 100],
				search: true,
				checkboxHeader: true,
				lstBtn: ['#btnMuestra']
			}
		}
	},
	data: {
		montoMovimientos: {
			option: {
				maintainSelected: true
			}
		}
	},
	formatter:{
		tipoMov(value, row, index){
			if(value != null){
				return (value == "H" ? "ABONO" : "CARGO")
			} else {
				return '';
			}
		}
	},
	ready($this){
		$this.movimientos.checkEvent(()=>{
			$this.movimientos.getSelections()
		})
		
		$this.movimientos.loadSuccess(()=>{
			Ajax.get(`InformacionOperativaService/getMontoTotales/${movDTO.cdCasoSica}/${movDTO.nuCuenta}`, data => {
				if(Mensaje.cargar(data, false)){
					$this.montoMovimientos.load(data);
				}
			})
		})
	}
});