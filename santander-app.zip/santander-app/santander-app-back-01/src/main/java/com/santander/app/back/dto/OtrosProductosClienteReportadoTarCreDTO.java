package com.santander.app.back.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

@Data
public class OtrosProductosClienteReportadoTarCreDTO {
	private String fhAperturaOPCR;
	private String nuCuentaOPCR;
	private String nbProductoOPCR;
	private String nbSubproductoOPCR;
	private String nbEstatusOPCR;
	private String fhCancelacionOPCR;
	private String nbTitularOPCR;
	private String nuCtePartOPCR;
	private String nbParticipesOPCR;
	private String imProductoOPCR;
	private BigDecimal imProPromOPCR;
	private BigDecimal imSaldoCCR;
	private List<?> listOtrosProDet;
	private String tpCargaOPCR;
	private String nbComentariosOPCR;
	private String nbBancaOPCR;
	private String tpCargaOPCR22;
	private String nuCtePartCCR;
	private String cdSec;
	private String nbDetParticipesOPCR;
}
