// =================== SESSION STORAGE ===================
class Session extends Map {
	static set(id, value) {
		if (typeof value === 'object') value = JSON.stringify(value);
		sessionStorage.setItem(id, value);
	}

	static get(id) {
		const value = sessionStorage.getItem(id);
		try {
			return JSON.parse(value);
		} catch (e) {
			return value;
		}
	}
	
	static remove(id){
		sessionStorage.removeItem(id);
	}
	
	static clean(){
		sessionStorage.clear();
	}
	
	static getUser(){
		var usuarioDTO = this.get("usuario");
		return usuarioDTO;
	}
	
	static lstModulos(){
		var usuarioDTO = this.getUser();
		if(usuarioDTO != null){
			return usuarioDTO.lstModulos1;
		} else {
			return [];
		}
	}
	
	static perfil(){
		var usuarioDTO = this.getUser();
		return usuarioDTO.cdPerfil1;
	}
	
	static changePerfil(cdPerfil){
		var usuarioDTO = this.getUser();

		this.clean();
		this.set('cdUserTemp', usuarioDTO.nbCveRed);
		this.set('cdPerfilTemp', usuarioDTO.cdPerfil2);
		Screen.perfilado();
	}
	
	static logout(){
		this.clean();
		Screen.login();
	}
}

//=================== AJAX ===================
class Ajax {
	static get(option, fnDone, fnError){
		var ajax = {}
		if(typeof option === 'string')  {ajax = {url: option} ;} else { ajax = option }
		if(ajax.host == null) ajax.host = `${Session.get('baseUrl')}/`;
		if(fnDone == null) fnDone = (response, statusText, xhrObj) => {};
		if(fnError == null) fnError = (xhrObj, textStatus, err) => { console.info(xhrObj); console.info(textStatus); console.info(err); }
		
		$.ajax({
			url : ajax.host + ajax.url,
			type : 'GET'
		}).then(fnDone, fnError);
	}
	
	static post(option, fnDone, fnError){
		var ajax = option;
		if(ajax.host == null) ajax.host = `${Session.get('baseUrl')}/`;
		if(fnDone == null) fnDone = (response, statusText, xhrObj) => {};
		if(fnError == null) fnError = (xhrObj, textStatus, err) => { console.info(xhrObj); console.info(textStatus); console.info(err); }
		
		$.ajax({
			url : ajax.host + ajax.url,
			type : 'POST',
			contentType: 'application/json',
			dataType: 'JSON',
			data: JSON.stringify(ajax.data)
		}).then(fnDone, fnError);
	}
	
	static put(option, fnDone, fnError){
		if(ajax.host == null) ajax.host = `${Session.get('baseUrl')}/`;
		if(fnDone == null) fnDone = (response, statusText, xhrObj) => {};
		if(fnError == null) fnError = (xhrObj, textStatus, err) => { console.info(xhrObj); console.info(textStatus); console.info(err); }
		
		$.ajax({
			url : ajax.host + ajax.url,
			type : 'PUT',
			contentType: 'application/json',
			dataType: 'JSON',
			data: JSON.stringify(ajax.data)
		}).then(fnDone, fnError);
	}
	
	static delet(option, fnDone, fnError){
		var ajax = {}
		if(typeof option === 'string')  {ajax = {url: option} ;} else { ajax = option }
		if(ajax.host == null) ajax.host = `${Session.get('baseUrl')}/`;
		if(fnDone == null) fnDone = (response, statusText, xhrObj) => {};
		if(fnError == null) fnError = (xhrObj, textStatus, err) => { console.info(xhrObj); console.info(textStatus); console.info(err); }
		
		$.ajax({
			url :  ajax.host + ajax.url,
			type : 'DELETE'
		}).then(fnDone, fnError);
	}
	
	static postFile(option, fnDone, fnError){
		var ajax = {}
		if(typeof option === 'string')  {ajax = {url: option} ;} else { ajax = option }
		if(ajax.host == null) ajax.host = `${Session.get('baseUrl')}/`;
		if(fnDone == null) fnDone = (response, statusText, xhrObj) => {};
		if(fnError == null) fnError = (xhrObj, textStatus, err) => { console.info(xhrObj); console.info(textStatus); console.info(err); }
		
		$.ajax({
			url: ajax.host + ajax.url,
			type: "POST",
			data: fileData,
			enctype: 'multipart/form-data',
			contentType: false,
			processData: false,
			cache: false
		}).then(fnDone, fnError);
	}
}

// =================== CONFIG PANTALLA  ===================
class Screen {
	static open(pageDTO) {
		window.open(
			pageDTO.path,
			pageDTO.name,
			'fullscreen=yes,toolbar=yes,location=yes,directories=yes,status=yes,menubar=yes,scrollbars=yes,copyhistory=yes,resizable=yes',
			function(response, status, xhr) {
				if(status != 'success'){
					Mensaje.cargar({
						message: 'Pagina no encontrada',
						status: 500
					});
				}
			}
		);
	}
	
	static openWindow(pageDTO) {
		window.open(
			pageDTO.path, 
			pageDTO.name, 
			`width=4000, height=4000`
		);
	}
	
	static load(url){
		document.location.href = url;
	}
	
	static page($el){
		Ajax.get({
			url: `view/${$el.dataset.page}`,
			host: `${Session.get('baseUrlFront')}/`
		}, response => {
			$($el.getAttribute('href')).html(response);
		});
//		
	}
	
	static perfilado(){
		this.load(`/santander-app-sica-02/perfilado`);
	}
	
	static login(){
		this.load(`/santander-app-sica-02/login`);
	}
}

//=================== MENSAJES ===================
class Mensaje {
	static cargar(data, show){
		var bool = (data.statusCodeValue == '200');
		
		if(!bool || show){
			var color = null;
			
			switch (data.statusCodeValue) {
			case 200:
				color = 'blue';
				break;

			case 500:
				color = 'red';
				break;
			default:
				color = 'yellow'
				break;
			}
			
			ohSnap(data.message, {color: color, duration: '8000'});
		}
		
		if(!bool) console.error( data.errorException );
		
		return bool;
	}
}

// =================== ALERT ===================
class Alert {
	static error(message){
		$.dialog({
		    title: 'Error',
		    theme: 'material',
		    type: 'red',
		    content: `<strong>${message != null ? message : ''}</strong>`,
		    buttons: {
		    	cerrar: {
		    		text: '<strong>Cerrar</strong>',
		            btnClass: 'btn-danger'
		    	},
		    }
		});
	}
	
	static confirm(message, fn){
		if(fn == null && typeof fn != 'function') fn = function(){};
		$.confirm({
		    title: '',
		    content: message,
		    theme: 'material',
		    type: 'dark',
		    buttons: {
		        aceptar: {
		            text: '<strong>Aceptar</strong>',
		            btnClass: 'btn-dark btn-sm',
		            action: fn
		        },
		        cancelar: {
		    		text: '<strong>Cancelar</strong>',
		            btnClass: 'btn-dark btn-sm'
		    	}
		    }
		});
	}
}

// =================== UTIL ===================
class Util {
	static isString(value){
		return typeof value === 'string';
	}
	
	static upper(value){
		if(this.isString(value)){
			return value.toUpperCase().trim();
		} else{
			return value;
		}
	}
	
	static lower(value){
		if(this.isString(value)){
			return value.toLowerCase().trim();
		} else{
			return value
		}
	}
	
	static replaceAll(string, search, newValue){
		if(string != undefined && string != null){
			return string.replace(new RegExp(search, 'g'), newValue);
		} else {
			return null;
		}
	}
	
	static validateNumber(event){
		var bool = false;
	  	var letter = event.key;
	    var key = event.keyCode;
		
		bool = new RegExp("[0-9]+").test(letter);

	    if(key == 8 || key == 32 || (event.ctrlKey && key == 86) || (event.ctrlKey && letter == 67)){
	        bool = true;
	  	}

	    event.returnValue = bool;
	}
	
	static validateLstNumber(event) {
	    var bool = false;
	  	var letter = event.key;
	    var key = event.keyCode;
		
		bool = new RegExp("[0-9,]+").test(letter);

	    if(key == 8 || key == 32 || (event.ctrlKey && key == 86) || (event.ctrlKey && letter == 67)){
	        bool = true;
	  	}

	    event.returnValue = bool;
	}
	
	static validateLetter(event){
		var bool = false;
	  	var letter = event.key;
	    var key = event.keyCode;
		
		bool = new RegExp("[aA-zZ]+").test(letter);

	    if(key == 8 || key == 32 || (event.ctrlKey && key == 86) || (event.ctrlKey && letter == 67)){
	        bool = true;
	  	}

	    event.returnValue = bool;
	}
	
	static validateLstLetter(event) {
	    var bool = false;
	  	var letter = event.key;
	    var key = event.keyCode;
		
		bool = new RegExp("[aA-zZ,]+").test(letter);

	    if(key == 8 || key == 32 || (event.ctrlKey && key == 86) || (event.ctrlKey && letter == 67)){
	        bool = true;
	  	}

	    event.returnValue = bool;
	}
	
	static changeUpper(obj) {
		obj.value = obj.value.toUpperCase();
	}
	
	static hasClass(el, className){
		return el.classList.contains(className);
	}
	
	static change(el, fn){
		el.addEventListener('change', fn);
	}
}

//=================== CATALOGO ==================
class CatalogoSia {
	static cdCatalogo = (cdCatalogo, fnDone, fnError) => {
		Ajax.get(`CatalogoSiaService/lstCatalogo/cdCatalogo/${cdCatalogo}`, fnDone, fnError);
	}
	
	static buscar = (path, fnDone, fnError) => {
		Ajax.get(`CatalogoSiaService/${path}`, fnDone, fnError);
	}
}

//=================== SELECT  ===================
class Select {
	constructor(object, $this){
		
		this.__defineGetter__('DEFAULT_OPTION', () => {
			return {concatText: ' - ', concatValue: '|', concatTitle: ' - ', firstOption: '-- Seleccione --', stFirstOption: true}
		})
		
		this.init(object, $this);
	}
	
	init(object, $this){
		var $select = this;
		
		Object.keys(object).forEach(name => {
			var option  = object[name];
			var $o = {};
			
			Object.keys($select.DEFAULT_OPTION).forEach(name_default => {
				if(option[name_default] == null) option[name_default] = $select.DEFAULT_OPTION[name_default];
			});
			
			$o.option = option;
			$o.el = ($this != null ? $this.$el.querySelector(`select[name=${name}]`) : document.querySelector(`select[name=${name}]`));
			if($o.option.ajax != null) {
				$o.ajax = $o.option.ajax;
				delete $o.option.ajax;
			}
			
			if($o.option.value == null) throw 'option.value is NULL';
			if($o.option.text == null) throw 'option.text is NULL';
			
//			===================== SELECT =====================
			$o.setCombo = (lst) => {
				var value = $o.option.value.split('|');
				var text = $o.option.text.split('|');
				var title = ($o.option.title != null ? $o.option.title.split('|') : null);
				
				if($o.option.stFirstOption) $($o.el).html(`<option value="-1">${$o.option.firstOption}</option>`);
				
				lst.forEach(row => {
					var valueOption = '';
					for(var i = 0; i < value.length; i++){
						if(i == (value.length - 1)){
							valueOption += row[value[i]];
						} else {
							valueOption += row[value[i]] + $o.option.concatValue;
						}
					}
					
					var textOption = '';
					for(var i = 0; i < text.length; i++){
						if(i == (text.length - 1)){
							textOption += row[text[i]];
						} else {
							textOption += row[text[i]] + $o.option.concatText;
						}
					}
					
					var textTitle = '';
					if(title != null){
						textTitle = 'title="'
						for(var i = 0; i < title.length; i++){
							if(i == (title.length - 1)){
								textTitle += row[title[i]];
							} else {
								textTitle += row[title[i]] + $o.option.concatTitle;
							}
						}
						textTitle += '"';
					}
					
					var selected = $o.el.dataset.value !== undefined && $o.el.dataset.value == valueOption ? 'selected' : '';
					
					$($o.el).append(`<option ${selected} value="${valueOption}" ${textTitle}>${textOption}</option>`);
				});
			}
			
			$o.push = ()=>{
				$o.option.stFirstOption = false;
				$o.setCombo();
				$o.option.stFirstOption = true;
			}
			
			$o.remove = ()=>{
				$o.setCombo([]);
			}
			
			$select.__defineGetter__(name, () => {
				return $o;
			});
		})
	}
}

//=================== DATEPICKER  ===================
class DatePicker {
	constructor(object){
		this.__defineGetter__('DEFAULT_OPTION', () => {
			return {
				language: 'es', 
				format: 'dd/mm/yyyy', 
				autoclose: true, 
				todayHighlight: true
			}
		});
		
		this.__defineGetter__('DEFAULT_OPTION_YEAR', () => {
			return {
				format: "yyyy",
				viewMode: 2,
				startView: 2,
				minViewMode: 2,
				maxViewMode: 2,
				autoclose: true
			}
		});
		
		if(object.el != null){
			this.__defineGetter__('$this', () => {
				return  object.el
			});
		}
		
		this.init(object);
	}
	
	init(object){
		var $datepicker = this;
		if(object.data != null){
			object.data.forEach(o => {
				var name = (typeof o === 'string' ? o : o.name);
				var el = ($datepicker.$this != null ? $datepicker.$this.$el.querySelector(`[data-date-picker=${name}]`) : document.querySelector(`[data-date-picker=${name}]`));
				$(el).datepicker(this.optionConfig(o));
				
				if(typeof o.change == 'function') {
					$(el).datepicker().on('changeDate', $datepicker.$this == null ? o.change : o.change.bind(null, $datepicker.$this));
				}
				
				$datepicker.__defineGetter__(name, () => {
					return el.value == '' ? null : $(el).datepicker('getDate');
				});
				
				$datepicker.__defineSetter__(name, (newValue) => {
					var date = null;
					if(newValue != null) date = new Date(newValue);
					$(el).datepicker('setDate', date);
				})
			});
		}
	}
	
	optionConfig(el){
		if(typeof el === 'string'){
			return this.DEFAULT_OPTION;
		} else {
			var default_option = (el.year ? this.DEFAULT_OPTION_YEAR : this.DEFAULT_OPTION);
			
			if(el.option == null){
				el.option = default_option;
			} else {
				Object.keys(default_option).filter(name => {
					if(el.option[name] == null) el.option[name] = default_option[name];
				});
			}
			
			return el.option;
		}
	}
	
	val(name){
		var value = null;
		if(this[name] !== undefined) value = $(`[data-date-picker=${name}]`).val();
		
		return value;
	}
}

//=================== MONEY  ===================
class Money {
	constructor(object){
		this.__defineGetter__('DEFAULT_OPTION', () => {
			return  {
				precision: 2
			}
		});
				
		if(object.el != null){
			this.__defineGetter__('$this', () => {
				return  object.el
			});
		}
		
		this.init(object);
	}
	
	init(object){
		var $money = this;
		if(object.data != null){
			object.data.forEach(o => {
				var name = (typeof o === 'string' ? o : o.name);
				var el = ($money.$this != null ? $money.$this.$el.querySelector(`[data-money=${name}]`) : document.querySelector(`[data-money=${name}]`));
				$(el).maskMoney(this.optionConfig(o));
				
				$money.__defineGetter__(name, () => {
					return el.value == '' ? null : $(el).maskMoney('unmasked')[0];
				});
				
				$money.__defineSetter__(name, (newValue) => {
					$(el).maskMoney('mask', newValue);
				})
			});
		}
	}
	
	optionConfig(el){
		if(typeof el === 'string'){
			return this.DEFAULT_OPTION;
		} else {
			if(el.option == null){
				el.option = this.DEFAULT_OPTION;
			} else {
				Object.keys(this.DEFAULT_OPTION).filter(name => {
					if(el.option[name] == null) el.option[name] = DEFAULT_OPTION[name];
				});
			}
			return el.option;
		}
	}
}

class Form {
	constructor(object){
		if(object.el == null) throw `el is NULL or it's empty`;
		
		var $form = this;
		
		this.__defineGetter__('$el', () => {
			return object.module != null ? object.module.querySelector(`[data-form=${object.el}]`) : document.querySelector(`[data-form=${object.el}]`);
		});
		
		this.init(object);
		if(typeof object.ready === 'function') object.ready(this);
	}
	
	init(object){
		var $form = this;
		
//		METHODS
		if(object.methods != null){
			for(let name of Object.keys(object.methods)){
				var m = object.methods[name];
				$form.methods[name] = m.bind(null, $form);
			}
		}
		
//		DATA CONFIGURATION
		if(object.data != null){
			var lstVariable = Object.keys(object.data);
			lstVariable.forEach(name => {
				var el =  $form.$el.querySelector(`[name=${name}]`);
				
				$form.__defineGetter__(name, () => {
					return getValue(el);
//					return this.value;
				});
				
				$form.__defineSetter__(name, newValue => {
					this.value = newValue;
					setValue(el, newValue);
				});
			});
		}

//		DATEPICKER CONFIGURATION
		var lstDatepicker = object.datepicker;
		if(lstDatepicker != null && lstDatepicker.length != 0){
			lstDatepicker.forEach(o => {
				var name = (typeof o === 'string' ? o : o.name);
				var el = $form.$el.querySelector(`[data-date-picker=${name}]`);
				
			});
			
			this.datepicker = new DatePicker({
				el: $form,
				data: lstDatepicker
			});
		}
		
//		MONEY CONFIGURATION
		var lstMoney = object.money;
		if(lstMoney != null && lstMoney.length != 0){
			lstMoney.forEach(o => {
				var name = (typeof o === 'string' ? o : o.name);
				var el = $form.$el.querySelector(`[data-money=${name}]`);
			});
			
			this.money = new Money({
				el: $form,
				data: lstMoney
			});
		}
		
		if(object.select != null) $form.select = new Select(object.select, $form);
	}
	
	methods= {};
	datepicker = {};
	money = {};
	select = {};
}

class Module {
	constructor(object){
		if(object.el == null || object.el.trim() == '') throw `el is NULL or it's empty`;
		this.__defineGetter__('$el', () => {
			return document.querySelector(`[data-module=${object.el}]`);
		});
		
		this.init(object);
		if(typeof object.ready === 'function') object.ready(this);
	}
	
	init(object){
		var $module = this;
		
//		FORM 
		if(object.form != null){
			var lst = Object.keys(object.form);
			lst.forEach(name => {
				var $o = object.form[name];
				$o.module = $module.$el;
				$o.el = name;
				if($o.ready != null) delete object.form.ready;
				var form = new Form($o);
				
				$module.form.__defineGetter__(name, ()=>{
					return form;
				})
			})
		}
		
//		METHODS
		if(object.methods != null){
			for(let name of Object.keys(object.methods)){
				var m = object.methods[name];
				$module.methods[name] = m.bind(null, $module);
			}
		}
		
//		DATA CONFIGURATION
		if(object.data != null){
			var lstVariable = Object.keys(object.data);
			
			lstVariable.forEach(name => {
				var el = $module.$el.querySelector(`[name=${name}]`);
				if(el != null){
					$module.__defineGetter__(name, () => {
						return getValue(el);
//						return this.value;
					});
					
					$module.__defineSetter__(name, newValue => {
						this.value = newValue;
						setValue(el, newValue);
					});
				}
				
				$module[name] = object.data[name];
			});
		}

//		DATEPICKER CONFIGURATION
		var lstDatepicker = object.datepicker;
		if(lstDatepicker != null && lstDatepicker.length != 0){
			lstDatepicker.forEach(o => {
				var name = (typeof o === 'string' ? o : o.name);
				var el = $module.$el.querySelector(`[data-date-picker=${name}]`);
				
			});
			
			this.datepicker = new DatePicker({
				el: $module,
				data: lstDatepicker
			});
		}
		
//		MONEY CONFIGURATION
		var lstMoney = object.money;
		if(lstMoney != null && lstMoney.length != 0){
			lstMoney.forEach(o => {
				var name = (typeof o === 'string' ? o : o.name);
				var el = $module.$el.querySelector(`[data-money=${name}]`);
			});
			
			this.money = new Money({
				el: $module,
				data: lstMoney
			});
		}
		
		if(object.select != null) $module.select = new Select(object.select, $module);
	}
	
	methods= {};
	datepicker = {};
	money = {};
	select = {};
	form = {};
}

class Table {
	constructor(object){
		this.init(object);
	}
	
	init(object){
		if(object.events != null) this.events = object.events;
		if(object.formatter != null) this.configFormatter(object.formatter);
		if(object.data != null) this.data(object.data);
		if(object.server != null) this.server(object.server);
		if(object.ready != null) object.ready(this);
	}
	
	server($server){
		var $table = this;
		var lst = Object.keys($server);
		lst.forEach(name => {
			var $o = {};
			$table.methods($o, name);
			$o.option = $table.configOption($server[name].option, 'server');
			$o.refresh = (url) => {
				if(url == null) url = $o.option.url;
				$($o.el).bootstrapTable('refresh', {url: url});
			}
			
			$table.__defineGetter__(name, ()=>{
				return $o;
			})
			
			$($o.el).bootstrapTable($o.option);
			$table.configFooter($o, $server[name]);
		});
	}
	
	data($data){
		var $table = this;
		
		var lst = Object.keys($data);
		lst.forEach(name => {
			var $o = {};
			$table.methods($o, name);
			$o.option = $table.configOption($data[name].option, 'data');
			$o.load = (data) => {
				$($o.el).bootstrapTable('load', data);
			}
			
			$table.__defineGetter__(name, ()=>{
				return $o;
			})
			
			$($o.el).bootstrapTable($o.option);
			$table.configFooter($o, $data[name]);
		});
	}
	
	methods($o, name){
		$o.el = document.querySelector(`table[data-table=${name}]`);
		
		$o.getData = () => {
			var data = $($o.el).bootstrapTable('getData');
			var lst = [];
			var object;
			data.forEach(row => {
				object = {};
				Object.keys(row).forEach(name => {
					if(name != 0) object[name] = row[name];
				})
				lst.push(object);
			})
			return lst;
		}
		
		$o.getDataCurrent = () => {
			var data = $($o.el).bootstrapTable('getData', {useCurrentPage:true});
			var lst = [];
			var object;
			data.forEach(row => {
				object = {};
				Object.keys(row).forEach(name => {
					if(name != 0) object[name] = row[name];
				})
				lst.push(object);
			})
			return lst;
		}
		
		$o.getSelections = () => {
			var data = $($o.el).bootstrapTable('getSelections');
			var lst = [];
			var object;
			data.forEach(row => {
				object = {};
				Object.keys(row).forEach(name => {
					if(name != 0) object[name] = row[name];
				})
				lst.push(object);
			})
			return lst;
		}
		
		$o.getSelected = () => {
			var data = $($o.el).bootstrapTable('getSelections')[0];
			var object = null;
			if(data != null){
				object = {};
				data.forEach(row => {
					Object.keys(row).forEach(name => {
						if(name != 0) object[name] = row[name];
					})
				})
			}
			return object;
		}
		
		$o.checkAll = () => {
			$($o.el).bootstrapTable('checkAll');
		}
		
		$o.uncheckAll = () => {
			$($o.el).bootstrapTable('uncheckAll');
		}
		
		$o.checkInvert = () => {
			$($o.el).bootstrapTable('checkInvert');
		}
		
		$o.checkEvent = fn => {
			$($o.el).on('check.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', fn);
		}
		
		$o.loadSuccess = fn => {
			$($o.el).on('load-success.bs.table' , fn);
		}
		
		if($o.el.querySelector('tfoot') != null){
			$o.footer = {};
			$o.footer.url = (url) => {
				Ajax.get(url, data => {
					if(Mensaje.cargar(data, false)){
						$o.footer.data(data.body);
					}
				});
			}
			
			$o.footer.data = (data) => {
				var footer = $o.el.querySelector('tfoot');
				var lst = Object.keys(data);
				lst.forEach(name => {
					var el = footer.querySelector(`[data-field-footer=${name}]`);
					if(el != null){
						if(el.dataset.formatter != null && el.dataset.formatter != ''){
							var fn = eval(el.dataset.formatter);
							var value = fn(data[name]);
							el.innerHTML = value;
						} else {
							el.innerHTML = data[name];
						}
					}
				})
			}
		}
		
		$o.destroy = () => {
			$($o.el).bootstrapTable('destroy');
		}
	}
	
	configFormatter($formatter){
		var $table = this;
		var lst = Object.keys($formatter);
		lst.forEach(name => {
			var $o = $formatter[name];
			
			$table.formatter.__defineGetter__(name, ()=> {
				return $o;
			})
		})
	}
	
	configFooter($o, $object){
		if($object.footer != null){
			if(typeof $object.footer.url == 'string'){
				$o.footer.url($object.footer.url);
			}
			
			if(typeof $object.footer.data == 'object'){
				$o.footer.data($object.footer.data);
			}
		}
	}
	
	configOption(option, type){
		var $table = this;
		var DEFAULT = (type == 'server' ? $table.OPTION_SERVER() : $table.OPTION_DATA());
		
		if(option == null) {
			option = DEFAULT;
		} else {
			Object.keys(DEFAULT).forEach(name => {
				if(option[name] == null) option[name] = DEFAULT[name];
			});
		}
		
		return option;
	}
	
	OPTION_SERVER() {
		var $table = this;
		return {
			search: false,
			pagination: true,
			pageSize: 10,
			pageList: [10, 25, 50],
			sortable: true,
			lstBtn: [],
			checkboxHeader: false,
			clickToSelect: false,
			singleSelect: false,
			maintainSelected: true,
			sidePagination: 'server',
			queryParams: params => { return { limit : params.limit, offset : params.offset, search : params.search, name : params.sort, order : params.order };},
			responseHandler: response => { return { rows: response.body.rows, total: response.body.total };},
			formatShowingRows: formatShowingRows,
			formatRecordsPerPage: formatRecordsPerPage,
			formatLoadingMessage: formatLoadingMessage,
			formatSearch: formatSearch,
			formatNoMatches: formatNoMatches
		}
	}
	
	OPTION_DATA() {
		var $table = this;
		return {
			search: false,
			pagination: true,
			pageSize: 10,
			pageList: [10, 25, 50],
			sortable: true,
			lstBtn:  [],
			checkboxHeader: false,
			clickToSelect: false,
			singleSelect: false,
			maintainSelected: true,
			data: [],
			formatShowingRows: formatShowingRows,
			formatRecordsPerPage: formatRecordsPerPage,
			formatLoadingMessage: formatLoadingMessage,
			formatSearch: formatSearch,
			formatNoMatches: formatNoMatches
		}
	};
	
	formatter = {};
	events = {};
}