package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.MovimientosSiaDTO;
import com.santander.app.back.util.QueryUtil;

@Component
public class MovimientosSiaDAO {
	@PersistenceContext private EntityManager em;
	@Autowired private QueryUtil queryUtil;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<MovimientosSiaDTO> lstMovimientosSia(BigDecimal cdCaso, String nuCuenta, Integer limit, Integer offset,String search, String name, String order) throws Exception{
		String consulta = Consultas.getConsultaSia("lstMovimientosSia");
		
		if(search != null && !search.equals("")) consulta += " WHERE nuNumero LIKE '%"+ search.toUpperCase().trim() +"%' ";
		
		consulta += queryUtil.orderBy(name, "nuNumero", order, "ASC");
		
		Query query = em.createNativeQuery(consulta);
		query.setParameter("cdCasoSica", cdCaso);
		query.setParameter("nuCuenta", nuCuenta);
		query.unwrap(NativeQuery.class)
		.addScalar("nuNumero",StringType.INSTANCE)
		.addScalar("cdCaso")
		.addScalar("nuCuenta")
		.addScalar("cdOficina")
		.addScalar("nbOficina")
		.addScalar("nbConcepto")
		.addScalar("nbTipoMovimiento")
		.addScalar("fhMovimiento",TimestampType.INSTANCE)
		.addScalar("cdDivisa",StringType.INSTANCE)
		.addScalar("imMonto")
		.addScalar("imEfectivo")
		.addScalar("nbDescripcion")
		.addScalar("nbTerminal")
		.addScalar("nbHoraOpe")
		.addScalar("cdCentro")
		//NUEVOS CAMPOS AGREGADOS MEJORA
		.addScalar("nuCtaContraParteMov")
		.addScalar("nuClienteMov")
		.addScalar("nbClienteMov")
		.addScalar("nbApePaternoMov")
		.addScalar("nbApeMaternoMov")
		.addScalar("tpPersonaMov",StringType.INSTANCE)
		.addScalar("nbConceptoMov")
		.addScalar("nuChequeMov",StringType.INSTANCE)
		.addScalar("imOperacionMov",StringType.INSTANCE)
		.addScalar("nbProductoMov")
		.addScalar("cdCasosSiaMov")
		.addScalar("stCuentaMov",StringType.INSTANCE)
		.addScalar("cdRfcMov")
		.addScalar("nbActividadMov")
		.addScalar("nbInterMov")
		.addScalar("cdCentroContMov")
		.addScalar("cdTerminalMov")
		.addScalar("nbHmMov")
		.addScalar("cdCentroMov")
		.setResultTransformer(Transformers.aliasToBean(MovimientosSiaDTO.class));
		query.setFirstResult(offset);
		query.setMaxResults(limit);
		
		return (List<MovimientosSiaDTO>) query.getResultList();
	}
	
	public Integer totalLstMovimientosSia(BigDecimal cdCaso, String nuCuenta, String search) throws Exception {
		String consulta = "SELECT COUNT(1) FROM (" + Consultas.getConsultaSia("lstMovimientosSia") +")";
		
		if(search != null && !search.equals("")) consulta += " WHERE nuNumero LIKE '%"+ search.toUpperCase().trim() +"%' ";
		
		Query query = em.createNativeQuery(consulta);
		query.setParameter("cdCasoSica", cdCaso);
		query.setParameter("nuCuenta", nuCuenta);
		
		return ((Number)query.getSingleResult()).intValue();
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public MovimientosSiaDTO getMontoTotales(BigDecimal cdCasoSica, String nuCuenta) throws Exception {
		List<MovimientosSiaDTO> resultado = new ArrayList<MovimientosSiaDTO>();
		
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getMontoTotales"));   
		query.setParameter("cdCasoSica", cdCasoSica);
		query.setParameter("nuCuenta", nuCuenta);
		query.unwrap(NativeQuery.class)
		.addScalar("numCargosTotal")
		.addScalar("imCargosTotal")
		.setResultTransformer(Transformers.aliasToBean(MovimientosSiaDTO.class));
		
		resultado = (List<MovimientosSiaDTO>) query.getResultList();
		if(!resultado.isEmpty()) {
			return resultado.get(0);
		}
		
		return new MovimientosSiaDTO();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<MovimientosSiaDTO> lstMovMuestra(String tpMovimiento, BigDecimal cdCaso, BigDecimal cdCasoSia, String nuCuenta, Integer limit, Integer offset, String search, String name, String order) throws Exception{
		String consulta = Consultas.getConsultaSia("lstMovMuestra");
		consulta += queryUtil.orderBy(name, "cdMontoReportado", order, "DESC");
		
		Query query = em.createNativeQuery(consulta);
		query.setParameter("tpMov", tpMovimiento);
		query.setParameter("cdCaso", cdCaso);
		query.setParameter("cdCasoSia", cdCasoSia);
		query.setParameter("nuCuenta", nuCuenta);
		query.unwrap(NativeQuery.class)
		.addScalar("nuNumero")
		.addScalar("cdCaso")
		.addScalar("cdCasoSIA")
		.addScalar("cdMontoReportado")
		.addScalar("nuCuenta")
		.addScalar("cdOficina")
		.addScalar("nbOficina")
		.addScalar("nbConcepto")
		.addScalar("nbTipoMovimiento")
		.addScalar("fhMovimiento",TimestampType.INSTANCE)
		.addScalar("cdDivisa",StringType.INSTANCE)
		.addScalar("imMonto")
		.addScalar("nbDescripcion")
		.addScalar("stResumen")
//		CAMPOS NUEVOS AGREGADOS A LA MUESTRA
		.addScalar("cdClienteMues")
		.addScalar("nbClienteMues")
		.addScalar("nbApePaternoMues")
		.addScalar("nbApeMaternoMues")
		.addScalar("nbTpPersonaMues")
		.addScalar("cdCuentaMues")
		.addScalar("cdRefInternaMues")
		.addScalar("nuOperaMuesDet")
		.addScalar("nuChequeMues")
		.addScalar("imOperacionMues")
		.addScalar("nbProductoMues")
		.addScalar("cdCasosSiaMues")
		.addScalar("stCuentaMues")
		.addScalar("cdRfcMues")
		.addScalar("nbActividadMues")
		.addScalar("nbInterMues")
		.addScalar("cdCentroContMues")
		.addScalar("cdTerminalMues")
		.addScalar("nbHmMues")
		.addScalar("cdCentroMues")
		.addScalar("fhIniOperMues")
		.addScalar("fhFinOperMues")
		.addScalar("fhIniOperMuesDEL")
		.addScalar("fhFinOperMuesAL")
		.addScalar("imMinMues")
		.addScalar("imMaxMues")
		.addScalar("nbDesgloseMues")
		.addScalar("fhRepAutMues")
		.addScalar("nbActInternetMues")
		.addScalar("nbDetDiaMues")
		.addScalar("nbDetSucMues")
		.addScalar("stInusualMues")
		.addScalar("nbCaracterMues")
		.addScalar("fhStMuestra")
		.addScalar("cdBanco")
		.addScalar("nbCompuesto")
		.addScalar("stClienteMues", StringType.INSTANCE)
		.addScalar("cdClienteMues1", StringType.INSTANCE)
		.addScalar("cdClienteMues2", StringType.INSTANCE)
		.addScalar("cdClienteMues3", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(MovimientosSiaDTO.class));
		query.setFirstResult(offset);
		query.setMaxResults(limit);
		
		return (List<MovimientosSiaDTO>) query.getResultList();
	}
	
	public Integer totalLstMovMuestra(String tpMovimiento, BigDecimal cdCaso, BigDecimal cdCasoSia, String nuCuenta) throws Exception {
		String consulta = "SELECT COUNT(1) FROM (" + Consultas.getConsultaSia("lstMovMuestra") +")";
		
		Query query = em.createNativeQuery(consulta);
		query.setParameter("tpMov", tpMovimiento);
		query.setParameter("cdCaso", cdCaso);
		query.setParameter("cdCasoSia", cdCasoSia);
		query.setParameter("nuCuenta", nuCuenta);
		
		return ((Number)query.getSingleResult()).intValue();
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public MovimientosSiaDTO getTotalAbonosSia(BigDecimal cdCaso, String nuCuenta) throws Exception{
		MovimientosSiaDTO montosTotalDTO = null; 
		List<MovimientosSiaDTO> nuCuentaDTO = new ArrayList<MovimientosSiaDTO>();
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getTotalAbonosSia"));
		query.setParameter("cdCaso", cdCaso);
		query.setParameter("nuCuenta", nuCuenta);
		query.unwrap(NativeQuery.class)
		.addScalar("numAbonosTotal")
		.addScalar("imAbonosTotal")
		.setResultTransformer(Transformers.aliasToBean(MovimientosSiaDTO.class));
         
		nuCuentaDTO = (List<MovimientosSiaDTO>)query.getResultList();        
		if(!nuCuentaDTO.isEmpty() ){montosTotalDTO = nuCuentaDTO.get(0);}
         
        return montosTotalDTO;
    }
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	public MovimientosSiaDTO getTotalCargosSia(BigDecimal cdCaso, String nuCuenta) throws Exception{
		MovimientosSiaDTO montosTotalDTO = null; 
		List<MovimientosSiaDTO> nuCuentaDTO = new ArrayList<MovimientosSiaDTO>();
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getTotalCargosSia"));
		query.setParameter("cdCaso", cdCaso);
		query.setParameter("nuCuenta", nuCuenta);
		query.unwrap(NativeQuery.class)
		.addScalar("numCargosTotal")
		.addScalar("imCargosTotal")
		.setResultTransformer(Transformers.aliasToBean(MovimientosSiaDTO.class));
         
		nuCuentaDTO = (List<MovimientosSiaDTO>)query.getResultList();
		if(!nuCuentaDTO.isEmpty() ){montosTotalDTO = nuCuentaDTO.get(0);}
         
        return montosTotalDTO;
    }
}
