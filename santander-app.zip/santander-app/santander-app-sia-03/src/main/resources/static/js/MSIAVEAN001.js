const casoDTO = Session.get('casoDTO');

var cuadrosTexto = new Form({
	el: 'cuadrosTexto',
	data: {
		nbDescripcionOperacion: '',
		nbRazonesInusual: '',
	},
	methods:{
		getCuadrosTexto($this){
			Ajax.get(`InformacionAdministrativaService/getCuadrosTexto/${casoDTO.cdCaso}`, data => {
				$this.nbDescripcionOperacion = data.body.nbDescripcionOperacion;
				$this.nbRazonesInusual = data.body.nbRazonesInusual;
			});
		},
		btnGuardar(){
			
		}
	},
	ready($this){
		$('#label-cliente').html(`Cliente: ${casoDTO.cdCliente}`);
		$('#label-cuenta').html(`Cuenta: ${casoDTO.nuCuenta}`);
		$('#label-caso').html(`Caso:: ${casoDTO.cdCaso}`);
		
		$this.methods.getCuadrosTexto();
	}
});