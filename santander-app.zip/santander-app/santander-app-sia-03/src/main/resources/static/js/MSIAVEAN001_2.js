var module001_2 = new Module({
	el: 'msiavean001_2',
	data:{
		comboCuenta: '-1'
	},
	methods:{
		getComboCuenta($this){
			CatalogoSia.buscar(`lstCuentasRelacionadas/${casoDTO.cdCasoSica}`, data => {
				if(Mensaje.cargar(data, false)){
					$this.select.comboCuenta.setCombo(data.body)
				}
			});
		},
		getCuenta($this){
			var nuCuenta = null;
			if($this.comboCuenta != null && $this.comboCuenta != '-1')
				nuCuenta = $this.comboCuenta.substr(-10);
			else
				nuCuenta = casoDTO.nuCuenta.substr(-10);
			
			return nuCuenta;
		},
		geCuentaCombo($this){
			var nuCuenta = $this.methods.getCuenta();
			
			table.cuatrimestral.refresh(`${Session.get('baseUrl')}/InformacionOperativaService/lstMecanicaOperacional/${casoDTO.cdCasoSica}/${nuCuenta}`);
			table.cuatrimestral.footer.url(`InformacionOperativaService/getCuadroConceptoTotal/${casoDTO.cdCasoSica}/${nuCuenta}`);
		},
		movimientos($this, stCuenta){
			var nuCuenta = $this.methods.getCuenta();
			
			Session.set('movDTO', {
				cdCasoSica: casoDTO.cdCasoSica,
				cdCaso: casoDTO.cdCaso,
				cdCliente: casoDTO.cdCliente,
				stCuenta: stCuenta,
				nuCuenta: nuCuenta,
				stVinculado: 0,
			});
			
			Screen.open({
				path: `${Session.get('baseUrlFront')}/Gestion-Alertas/Casos-Pendientes/Analisis/Movimientos`,
				name: `Movimiento: ${casoDTO.cdCasoSica} - ${casoDTO.cdCaso} - ${nuCuenta}`
			});
		}
	},
	select:{
		comboCuenta:{
			value:'cdValor',
			text:'cdValor'
		}
	},
	ready($this){
		$this.methods.getComboCuenta();
	}
});

var table = new Table({
	server:{
		cuatrimestral: {
			option: {
				url: `${Session.get('baseUrl')}/InformacionOperativaService/lstMecanicaOperacional/${casoDTO.cdCasoSica}/${module001_2.methods.getCuenta()}`,
				pageSize: 5,
				pageList: [5, 25, 50,100]
			},
			footer:{
				url: `InformacionOperativaService/getCuadroConceptoTotal/${casoDTO.cdCasoSica}/${module001_2.methods.getCuenta()}`
			}
		}
	}
})

//$(function(){
//	CatalogoSia.buscar(`lstCuentasRelacionadas/${casoDTO.cdCasoSica}`, cdCuentaR , {
//		value: 'cdValor',
//		text: 'cdValor'
//	});
//
//	cdCuentaR.change(function(){
//		getCuadroConceptoTotal(getCuenta());
//		tablaCuatrimestral.refresh(`${Session.get('baseUrl')}/InformacionOperativaService/lstMecanicaOperacional/${casoDTO.cdCasoSica}/${getCuenta()}`);
//	});
//	
//	getCuadroConceptoTotal(getCuenta());
//	
//	tablaCuatrimestral.setTable({
//		url: `${Session.get('baseUrl')}/InformacionOperativaService/lstMecanicaOperacional/${casoDTO.cdCasoSica}/${getCuenta()}`,
//		pageSize: 5,
//		pageList: [5, 25, 50,100]
//	});
//});
//
//function getCuenta(){
//	var nuCuenta = cdCuentaR.val();
//	if(nuCuenta != null && nuCuenta != '')
//		return nuCuenta.substr(-10);
//	else
//		return casoDTO.nuCuenta.substr(-10);
//}
//
//function getCuadroConceptoTotal(nuCuenta){
//	Ajax.get(`InformacionOperativaService/getCuadroConceptoTotal/${casoDTO.cdCasoSica}/${nuCuenta}`).done(function(data){
//		if(Ajax.statusOK(data, false)){
//			footerCuadroConcepto.setDataElement(data.body);
//		}
//	});
//}
//
//function detalleMovimientos(stCuenta){
//	var nuCuenta = getCuenta();
//	
//	Session.set('movimientoDTO' ,{
//		cdCasoSica: casoDTO.cdCasoSica,
//		cdCaso: casoDTO.cdCaso,
//		cdCliente: casoDTO.cdCliente,
//		nuCuenta: nuCuenta,
//		stCuenta: stCuenta
//	});
//	
//	Screen.open({
//		path: `${Session.get('baseUrlFront')}/Casos/Movimientos`,
//		name: `Movimientos: caso ${casoDTO.cdCaso} - ${casoDTO.cdCasoSica} - ${nuCuenta}`
//	});
//}