package com.santander.app.front.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Utilidad {
	@Value("${project.spring.host}") private String HOST;
	@Value("${project.spring.modulo.back}") private String URL_BACK;
	@Value("${project.spring.modulo.sica}") private String URL_FRONT_SICA;
	@Value("${project.spring.modulo.sia}") private String URL_FRONT_SIA;
	@Value("${project.spring.modulo.red}") private String URL_FRONT_RED;
	@Value("${project.spring.index}") private String FRONT_INDEX;
	@Value("${project.spring.rest}") private String REST;
	
	public String getUrlBase() {
		return  HOST + URL_BACK + REST;
	}
	
	public String getUrlFrontSica() {
		return  HOST + URL_FRONT_SICA;
	}
	
	public String getUrlFrontSia() {
		return  HOST + URL_FRONT_SIA;
	}
	
	public String getUrlFrontRed() {
		return  HOST + URL_FRONT_RED;
	}
	
	public String getUrlIndex() {
		return  FRONT_INDEX;
	}
}
