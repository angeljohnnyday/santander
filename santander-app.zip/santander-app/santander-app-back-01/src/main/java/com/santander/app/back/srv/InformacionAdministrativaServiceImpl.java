package com.santander.app.back.srv;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.ComentariosGeneralesSiaDAO;
import com.santander.app.back.dao.CuadrosTextoAnalisisDAO;
import com.santander.app.back.dao.DatosGeneralesClienteReportadoSiaDAO;
import com.santander.app.back.dao.InformacionDatosGeneralesDAO;
import com.santander.app.back.dao.InformacionPldDAO;
import com.santander.app.back.dao.MotivoReporteDAO;
import com.santander.app.back.dao.OficinaGestoraReportaDAO;
import com.santander.app.back.dao.OtrasCuentasClienteReportadoDAO;
import com.santander.app.back.dao.OtrosProductosClienteReportadoSiaDAO;
import com.santander.app.back.util.Response;

public class InformacionAdministrativaServiceImpl implements InformacionAdministrativaService {
	@Autowired private InformacionDatosGeneralesDAO informacionDatosGeneralesDAO;
	@Autowired private ComentariosGeneralesSiaDAO comentariosGeneralesSiaDAO;
	@Autowired private CuadrosTextoAnalisisDAO cuadrosTextoAnalisisDAO;
	@Autowired private DatosGeneralesClienteReportadoSiaDAO datosGeneralesClienteReportadoSiaDAO;
	@Autowired private OficinaGestoraReportaDAO oficinaGestoraReportaDAO;
	@Autowired private OtrosProductosClienteReportadoSiaDAO otrosProductosClienteReportadoSiaDAO;
	@Autowired private OtrasCuentasClienteReportadoDAO otrasCuentasClienteReportadoDAO;
	@Autowired private MotivoReporteDAO motivoReporteDAO;
	@Autowired private InformacionPldDAO informacionPldDAO;

	@Override
	public Response<Object> getDatosGenerales(BigDecimal cdCaso, String nuFolioAlerta) {
		try {
			return new Response<>(informacionDatosGeneralesDAO.getDatosGenerales(cdCaso, nuFolioAlerta), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getComentariosGenerales(BigDecimal cdCasoSia) {
		try {
			return new Response<>(comentariosGeneralesSiaDAO.getComentariosGenerales(cdCasoSia), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getCuadrosTexto(BigDecimal cdCasoSia) {
		try {
			return new Response<>(cuadrosTextoAnalisisDAO.getCuadrosTexto(cdCasoSia), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getOficinaGestoraReporta(BigDecimal cdCaso, String tpOficina) {
		try {
			return new Response<>(oficinaGestoraReportaDAO.getOficinaGestoraReporta(cdCaso, tpOficina), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getDatosGeneralesByClienteReportado(String cdCliente, BigDecimal cdCaso) {
		try {
			return new Response<>(datosGeneralesClienteReportadoSiaDAO.getDatosGeneralesByClienteReportado(cdCliente, cdCaso), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstOtrosProductosClienteReportado(BigDecimal cdCaso, String cdCliente) {
		try {
			return new Response<>(otrosProductosClienteReportadoSiaDAO.lstOtrosProductosClienteReportado(cdCaso, cdCliente), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstOtrasCuentasClienteReportado(BigDecimal cdCaso, String cdCliente) {
		try {
			return new Response<>(otrasCuentasClienteReportadoDAO.lstOtrasCuentasClienteReportado(cdCaso, cdCliente), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getMotivoReporte(BigDecimal cdCasoSica) {
		try {
			return new Response<>(motivoReporteDAO.getMotivoReporte(cdCasoSica), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getInformacionPLD(BigDecimal cdCasoSia) {
		try {
			return new Response<>(informacionPldDAO.getInformacionPLD(cdCasoSia), Mensaje.getText("SUCCESS"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
