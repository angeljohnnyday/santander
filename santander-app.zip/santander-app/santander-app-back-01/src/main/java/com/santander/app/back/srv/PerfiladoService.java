package com.santander.app.back.srv;

//import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.santander.app.back.util.Response;

@Path("/PerfiladoService")
public interface PerfiladoService {
	@GET
	@Path("/consultarUsuario/nbUserRed/{nbCveRed}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> consultarUsuario(
		@PathParam("nbCveRed") String nbCveRed
//		@Context HttpServletRequest request
	);

	@GET
	@Path("/consultarUsuario/nbUserRed/{nbCveRed}/cdPerfil/{cdPerfil}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> consultarUsuario(
		@PathParam("nbCveRed") String nbCveRed,
		@PathParam("cdPerfil") String cdPerfil
//		@Context HttpServletRequest request
	);
}
