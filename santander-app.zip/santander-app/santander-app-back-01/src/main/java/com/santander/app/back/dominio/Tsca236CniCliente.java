package com.santander.app.back.dominio;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name =  "TSCA236_CNI_CLIENTE", schema = "GORAPR")
public class Tsca236CniCliente {
	@Id
	@Column(name = "CD_CASO")
	private BigDecimal cdCaso;
	
	@Column(name = "CD_NACIONALIDAD")
	private String cdNacionalidad;
	
	@Column(name = "CD_ACTIVIDAD")
	private String cdActividad;
	
	@Column(name = "TP_OPERACION")
	private String tpOperacion;
	
	@Column(name = "CD_TIPOLOGIA")
	private String cdTipologia;
	
	@Column(name = "TP_PERSONA")
	private String tpPersona;
	
	@Column(name = "CD_INSTRUMENTO")
	private String cdInstrumento;
	
	@Column(name = "CD_ORIGEN_ALERTA")
	private BigDecimal cdOrigenAlerta;
	
	@Column(name = "CD_ORDEN_PAGO")
	private BigDecimal cdOrdenPago;
	
	@Column(name = "CD_DELITO")
	private String cdDelito;
}
