var actionDelito = { 
    'click .detailEdit': function (e, value, row, index) {
    	msiavepar01_4.methods.modalDelito('Editar Delito');
    	msiavepar01_4.cdDelito = row.cdDelito;
    	msiavepar01_4.nbDelito = row.nbDelito;
    	msiavepar01_4.stDelito = row.stDelito;
    }
};

var msiavepar01_4 = new Module({
	el: 'msiavepar01_4',
	data:{
		nbDelito: '',
		stDelito: 'A',
		cdDelito: null,
	},
	methods:{
		modalDelito($this, title){
			$this.cdDelito =  null;
			$this.nbDelito =  '';
			$this.stDelito =  'A';
			$("#titleModalDelito").html(title);
			$("#modalDelito").modal();
		},
		guardarDelito($this){
			var delitoDTO = new Object();
			delitoDTO.nbDelito = $this.nbDelito.trim().toUpperCase();
			delitoDTO.stDelito = $this.stDelito;
			var path = $this.cdDelito != null ? `/${$this.cdDelito}` : '';
			
			Ajax.post({
				url: `DelitoService/guardarDelito${path}`,
				data: delitoDTO
			}, data => {
				if(Mensaje.cargar(data, true)) {
					table.delitos.refresh();
					$("#modalDelito").modal('hide');
				}
			});
		},
		cambiarStatus(){
			var data = table.delitos.getSelections();
			data.forEach(row => {
				row.stDelito = (row.stDelito == 'A' ? 'I' : 'A');
			});
			
			Alert.confirm( 'Desea cambiar los status de los elementos seleccionados?', () => {
				Ajax.post({
					url: 'DelitoService/cambiarStatus',
					data: data
				}, (data) => {
					if(Mensaje.cargar(data, true)){
						table.delitos.refresh();
					}
				})
			});
		},
		eliminarDelitos(){
			var mensaje = 'Desea eliminar los elementos seleccionados?'
			Alert.confirm(mensaje, () => {
				Ajax.post({
					url: 'DelitoService/eliminarDelitos',
					data: table.delitos.getSelections()
				}, (data) => {
					if(Mensaje.cargar(data, true)){
						table.delitos.refresh();
					}
				})
			});
		}
	}
})

var table = new Table({
	server:{
		delitos:{
			option:{
				checkboxHeader: true,
				url: `${Session.get("baseUrl")}/DelitoService/lstDelitos`,
				lstBtn:['#btnStatusDelito', '#btnEliminarDelito']
			}
		}
	},
	formatter:{
		status(value, row, index){
			var string = "-";
			
			if(row.stDelito == 'A')
				string = "<strong style='color:green;'>Activo</strong>";
			else
				string = "<strong style='color:red;'>Inactivo</strong>";
			
			return string;
		},
		buttons(value, row, index) {
			return [
				'<a class="detailEdit text-red" href="javascript:void(0)" title="Modificar">',
				'<i class="fas fa-edit"></i>',
				'</a>'
			].join('');
		}
	}
})