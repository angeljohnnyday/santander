package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.MecanicaOperacionalSiaDTO;
import com.santander.app.back.util.QueryUtil;

@Component
public class MecanicaOperacionalSiaDAO {
	@PersistenceContext EntityManager em;
	@Autowired QueryUtil queryUtil;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public MecanicaOperacionalSiaDTO getCuadroConceptoTotal(BigDecimal cdCasoSica, String nuCuenta) throws Exception { 
		MecanicaOperacionalSiaDTO datosMecanica = new MecanicaOperacionalSiaDTO();
		List<MecanicaOperacionalSiaDTO> lstDatosMecanica = null;
	 	  
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getCuadroConceptoTotal"));
		query.setParameter("cdCasoSica", cdCasoSica);
		query.setParameter("nuCuenta", nuCuenta);
		query.unwrap(NativeQuery.class)
		.addScalar("nbConceptoTCF")
		.addScalar("nuMovimientosTCF")
		.addScalar("imMontoTCF")
		.addScalar("nuPorcentajeTCF")
		.addScalar("nuPromedioTCF")
		.addScalar("nuMovimientosATCF")
		.addScalar("imMontoATCF")
		.addScalar("nuPorcentajeATCF")
		.addScalar("nuPromedioATCF")
		.setResultTransformer(Transformers.aliasToBean(MecanicaOperacionalSiaDTO.class)); 
		
		lstDatosMecanica = ( List<MecanicaOperacionalSiaDTO> ) query.getResultList();
		
		if(!lstDatosMecanica.isEmpty()){
			datosMecanica = lstDatosMecanica.get(0);
		}
		
		return datosMecanica; 
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<MecanicaOperacionalSiaDTO> lstMecanicaOperacional(BigDecimal cdCasoSica, String nuCuenta, Integer limit, Integer offset,String search, String name, String order) throws Exception {
		String consulta = Consultas.getConsultaSia("lstMecanicaOperacional");
		consulta += queryUtil.orderBy(name, "cdCuadroTC", order, "ASC");
		
		Query query = em.createNativeQuery(consulta);
		query.setParameter("cdCasoSica", cdCasoSica);
		query.setParameter("nuCuenta", nuCuenta);
		query.unwrap(NativeQuery.class)
		.addScalar("cdCuadroTC", StringType.INSTANCE)
		.addScalar("nbConceptoTC")
		.addScalar("nuMovimientosTC")
		.addScalar("imMontoTC")
		.addScalar("nuPorcentajeTC")
		.addScalar("nuPromedioTC")
		.addScalar("nuMovimientosATC")
		.addScalar("imMontoATC")
		.addScalar("nuPorcentajeATC")
		.addScalar("nuPromedioATC")
		.setResultTransformer(Transformers.aliasToBean(MecanicaOperacionalSiaDTO.class));
		query.setFirstResult(offset);
		query.setMaxResults(limit);
		 
		return (List<MecanicaOperacionalSiaDTO>) query.getResultList();
	}
	
	public Integer totalLstMecanicaOperacional(BigDecimal cdCasoSica, String nuCuenta) throws Exception {
		String consulta = " SELECT COUNT(1) FROM ( "+Consultas.getConsultaSia("lstMecanicaOperacional")+" ) ";
		Query query = em.createNativeQuery(consulta);
		query.setParameter("cdCasoSica", cdCasoSica);
		query.setParameter("nuCuenta", nuCuenta);
		return ((Number) query.getSingleResult()).intValue();
	}
}
