package com.santander.app.sia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class IndexSiaController {
	
	@GetMapping("/admon")
	public String admon() {
		return "admon";
	}
	
	@GetMapping("/view/{page}")
	public String view(@PathVariable("page") String page) {
		return page +" :: "+ page;
	}
}
