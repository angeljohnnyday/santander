package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dominio.Tsca301Delito;
import com.santander.app.back.dto.DelitoDTO;
import com.santander.app.back.repo.Tsca301Repo;
import com.santander.app.back.util.QueryUtil;

@Component
public class DelitoDAO {
	@PersistenceContext private EntityManager em;
	@Autowired private QueryUtil queryUtil;
	@Autowired private Tsca301Repo tsca301Repo;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<DelitoDTO> lstDelitos (Integer limit, Integer offset, String search, String name, String order) throws Exception {
		String consulta = Consultas.getConsultaSia("lstDelitos");
		consulta += queryUtil.orderBy(name, "stDelito, cdDelito", order, "ASC");

		Query query = em.createNativeQuery(consulta);
		query.unwrap(NativeQuery.class)
		.addScalar("cdDelito", BigDecimalType.INSTANCE)
		.addScalar("nbDelito", StringType.INSTANCE)
		.addScalar("stDelito", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(DelitoDTO.class));
		query.setFirstResult(offset);
		query.setMaxResults(limit);

		return (List<DelitoDTO>)query.getResultList();
	}
	
	public Integer totalLstDelitos() throws Exception {
		Query query = em.createNativeQuery("SELECT COUNT(1) FROM ("+Consultas.getConsultaSia("lstDelitos") +")");
		return ((Number) query.getSingleResult()).intValue();
	}
	
	@Transactional
	public void guardarDelito(DelitoDTO delitoDTO) {
		Tsca301Delito t301 = new Tsca301Delito();
		t301.setNbDelito(delitoDTO.getNbDelito());
		t301.setStDelito(delitoDTO.getStDelito());
		
		tsca301Repo.saveAndFlush(t301);
	}
	
	@Transactional
	public void guardarDelito(BigDecimal cdDelito, DelitoDTO delitoDTO) {
		Tsca301Delito t301 = null;
		
		if(tsca301Repo.existsById(cdDelito)) {
			t301 = tsca301Repo.getOne(cdDelito);
			t301.setNbDelito(delitoDTO.getNbDelito());
			t301.setStDelito(delitoDTO.getStDelito());
			tsca301Repo.saveAndFlush(t301);
		}
	}
	
	@Transactional
	public void cambiarStatus(List<DelitoDTO> lstDelitos) {
		for(DelitoDTO delitoDTO : lstDelitos) {
			if(tsca301Repo.existsById(delitoDTO.getCdDelito())) {
				Tsca301Delito t301 = tsca301Repo.getOne(delitoDTO.getCdDelito());
				t301.setStDelito(delitoDTO.getStDelito());
				tsca301Repo.save(t301);
			}
		}
		tsca301Repo.flush();
	}
	
	@Transactional
	public void eliminarDelitos(List<DelitoDTO> lstDelitos) {
		for(DelitoDTO delitoDTO : lstDelitos) {
			if(tsca301Repo.existsById(delitoDTO.getCdDelito())) {
				tsca301Repo.deleteById(delitoDTO.getCdDelito());
			}
		}
		tsca301Repo.flush();
	}
}
