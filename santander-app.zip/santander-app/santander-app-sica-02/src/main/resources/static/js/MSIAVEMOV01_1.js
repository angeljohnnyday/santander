var table = new Table({
	server: {
		movimientos:{
			url: `${Session.get('baseUrl')}/InformacionOperativaService/lstMovimientosSia/${movDTO.cdCasoSica}/${movDTO.nuCuenta}`,
			pageSize: 5,
			pageList: [5, 25, 50, 100],
			search: true,
			checkboxHeader: true,
			lstBtn: ['#btnMuestra']
		}
	}
})


//$(function(){
//	tableMontoMov.setTable({
//		maintainSelected: true
//	});
//	
//	tableMovimientos.setTable({
//		url: `${Session.get('baseUrl')}/InformacionOperativaService/lstMovimientosSia/${movDTO.cdCasoSica}/${movDTO.nuCuenta}`,
//		pageSize: 5,
//		pageList: [5, 25, 50, 100],
//		search: true,
//		checkboxHeader: true,
//		lstBtn: ['#btnMuestra']
//	});
//});
//
//tableMontoMov.loadSuccess(() => {
//	
//})