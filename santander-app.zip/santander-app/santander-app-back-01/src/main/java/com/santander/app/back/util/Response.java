package com.santander.app.back.util;

import org.springframework.http.HttpStatus;
import org.springframework.lang.Nullable;

import lombok.Getter;

public class Response<T> {
	
	public Response(@Nullable String message, HttpStatus status) {
		this.message = message;
		this.status = status;
	}
	
	public Response(@Nullable String message, String errorException, HttpStatus status) {
		this.message = message;
		this.errorException = errorException;
		this.status = status;
	}
	
	public Response(@Nullable T body, @Nullable String message, HttpStatus status) {
		this.body = body;
		this.message = message;
		this.status = status;
	}

	@Getter private T body;
	@Getter private String message;
	@Getter private String errorException;
	private final Object status;
	
	public int getStatusCodeValue() {
		if (this.status instanceof HttpStatus) {
			return ((HttpStatus) this.status).value();
		}
		else {
			return (Integer) this.status;
		}
	}
	
	public HttpStatus getStatusCode() {
		if (this.status instanceof HttpStatus) {
			return (HttpStatus) this.status;
		}
		else {
			return HttpStatus.valueOf((Integer) this.status);
		}
	}
}
