package com.santander.app.back.srv;

import java.math.BigDecimal;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.santander.app.back.util.Response;

@Path("/InformacionAdministrativaService")
public interface InformacionAdministrativaService {
	
	@GET
	@Path("/getDatosGenerales/{cdCaso}/{nuFolioAlerta}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> getDatosGenerales(
		@PathParam("cdCaso") BigDecimal cdCaso,
		@PathParam("nuFolioAlerta") String nuFolioAlerta
	);
	
	@GET
	@Path("/getComentariosGenerales/{cdCasoSia}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> getComentariosGenerales(
		@PathParam("cdCasoSia") BigDecimal cdCasoSia
	);

	@GET
	@Path("/getCuadrosTexto/{cdCasoSia}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> getCuadrosTexto(
		@PathParam("cdCasoSia") BigDecimal cdCasoSia
	);
	
	@GET
	@Path("/getOficinaGestoraReporta/{cdCaso}/{tpOficina}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> getOficinaGestoraReporta(
		@PathParam("cdCaso") BigDecimal cdCaso,
		@PathParam("tpOficina") String tpOficina
	);
	
	@GET
	@Path("/getDatosGenerales/clienteReportado/{cdCliente}/{cdCaso}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> getDatosGeneralesByClienteReportado(
		@PathParam("cdCliente") String cdCliente,
		@PathParam("cdCaso") BigDecimal cdCaso
	);
	
	@GET
	@Path("/lstOtrosProductosClienteReportado/{cdCaso}/{cdCliente}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstOtrosProductosClienteReportado(
		@PathParam("cdCaso") BigDecimal cdCaso,
		@PathParam("cdCliente") String cdCliente
	);
	
	@GET
	@Path("/lstOtrasCuentasClienteReportado/{cdCaso}/{cdCliente}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstOtrasCuentasClienteReportado(
		@PathParam("cdCaso") BigDecimal cdCaso,
		@PathParam("cdCliente") String cdCliente
	);
	
	@GET
	@Path("/getMotivoReporte/{cdCasoSica}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> getMotivoReporte(
		@PathParam("cdCasoSica") BigDecimal cdCasoSica
	);
	
	@GET
	@Path("/getInformacionPLD/{cdCasoSia}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> getInformacionPLD(
		@PathParam("cdCasoSia") BigDecimal cdCasoSia
	);
}
