package com.santander.app.back.srv;

import java.math.BigDecimal;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.santander.app.back.util.Response;

@Path("/ConsultaCasosSiaService")
public interface ConsultaCasosSiaService {
	
	@GET
	@Path("/getVistaRapida/{cdCaso}/{cdSistema}/{cdAlerta}/{nuCuenta}/{historico}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> getVistaRapida(
		@PathParam("cdCaso") BigDecimal cdCaso,
		@PathParam("cdSistema") String cdSistema,
		@PathParam("cdAlerta") String cdAlerta,
		@PathParam("nuCuenta") String nuCuenta,
		@PathParam("historico") Integer historico
	);
}
