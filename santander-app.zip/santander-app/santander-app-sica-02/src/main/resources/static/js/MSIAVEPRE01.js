var actionEvents = {
	'click .detailEdit' : function(e, value, row, index) {
		modalPremisa(row.cdPremisa);
		
		var PLD = row.nbOficialPld.split('|');
		var Banca = row.nbBanca.split('|');
		var Juridico = row.nbJuridico.split('|');
		
		row.cdDecisionPLD = PLD[0];
		row.cdAccionPLD = PLD[1];
		row.cdDecisionBanca = Banca[0];
		row.cdAccionBanca = Banca[1];
		row.cdDecisionJuridico = Juridico[0];
		row.cdAccionJuridico = Juridico[1];
		
		formPremisa.setData(row);
		
		changeDecisionAccion();
		formPremisa.cdOpinion.val(row.stOpinion);
		
		if(row.stVerse == '1'){
			formPremisa.cdOpinion.val('-1');
			formPremisa.cdOpinion.disabled(true);
			formPremisa.cdDictamenFinal.show(false);
		}
		
		if(row.cdDecisionFinal != null){
			changeOpinion();
			formPremisa.cdDictamenFinal.val(row.cdDecisionFinal);
		}
	}, 'click .detailDelete' : function(e, value, row, index) {
		Alert.confirm('¿Desea eliminar la premisa?', function (){
			Ajax.delet(`PremisaSiaService/eliminarPremisa/${row.cdPremisa}`).done(function(data){
				if(Ajax.statusOK(data, true)){
					tablePremisas.load();
				}
			})
		});
	}
};

$(function(){
	tablePremisas.setUrl(`PremisaSiaService/lstPremisas/stCompartido/1`)
	tablePremisas.setTable({
		pageSize: 10,
		pageList: [10, 25, 50]
	});

	formPremisa.stVerse.change(changeStVerse);
	formPremisa.cdOpinion.change(changeOpinion);
});

// ======================= FORMATTERS =======================
function formatterPremisas(value, row, index) {
	return [
		(value != 'E' ? '<a class="detailEdit" href="javascript:void(0)" title="Modificar">' : ''),
		(value != 'E' ? '<i class="fas fa-pen"></i></a>' : ''),
		'<a class="detailDelete text-danger" href="javascript:void(0)" title="Eliminar">',
		'<i class="fas fa-trash-alt"></i>', 
		'</a>' 
	].join('');
}

function formatterStPremisa(value, row, index){
	var estatus = "";
	switch(value){
	case 'A':
		estatus = "<label class='text-success'>ACTIVA</label>";
		break;
	case 'I':
		estatus = "<label class='text-danger'>INACTIVA</label>";
		break;
	case 'E':
		estatus = "<label class='text-info'>ESPECIAL</label>";
		break;
	}
	
	return estatus;
}

//======================= FUNCTIONS =======================
function modalPremisa(cdPremisa) {
	formPremisa.reset();
	formPremisa.cdOpinion.disabled(false);
	formPremisa.cdDictamenFinal.show(false);
	formPremisa.cdOpinion.setCombo({
		data: [{cdValor: '4', nbValor: 'OTRO'}],
		value: 'cdValor',
		text: 'nbValor',
		firstOption: '-- OPINIÓN --'
	});
	
	formPremisa.setCombo('remove');
	
//	========= DECISION =========
	formPremisa.setComboServer('cdDecisionPLD|cdDecisionBanca|cdDecisionJuridico', 'PremisaSiaService/lstDecisionPremisa', {
		value: 'cdDetCatalogo',
		text: 'nbValor',
		firstOption: '-- DECISIÓN --'
	});
	
//	========= ACCION ========= 
	formPremisa.setComboServer('cdAccionPLD|cdAccionBanca|cdAccionJuridico', 'PremisaSiaService/lstAccionPremisa', {
		value: 'cdDetCatalogo',
		text: 'nbValor',
		firstOption: '-- ACCIÓN --'
	});
	
	$("#btn-guardar-premisa").attr("onclick", `guardarPremisa(${cdPremisa})`);
	$('#modal-form-premisa').modal();
}

function changeStVerse(){
	formPremisa.cdOpinion.disabled(formPremisa.stVerse.isChecked());
	if(formPremisa.stVerse.isChecked()) {
		formPremisa.cdOpinion.val('-1');
		formPremisa.cdDictamenFinal.show(false);
	}
}

function changeDecisionAccion(){
	var lstData = [];
	
	if(formPremisa.cdAccionPLD.val() != null){
		lstData.push({
			cdValor: '1',
			nbValor: 'OFICIAL/PLD',
		})
	}
	
	if(formPremisa.cdAccionBanca.val() != null){
		lstData.push({
			cdValor: '2',
			nbValor: 'BANCA',
		})
	}
	
	if(formPremisa.cdAccionJuridico.val() != null){
		lstData.push({
			cdValor: '3',
			nbValor: 'JURIDICO',
		})
	}
	
	lstData.push({
		cdValor: '4',
		nbValor: 'OTRO',
	});
	
	formPremisa.cdOpinion.setCombo({
		data: lstData,
		value: 'cdValor',
		text: 'nbValor',
		firstOption: '-- OPINI&Oacute;N --'
	});
}

function guardarPremisa(cdPremisa){
	var objectTemp = formPremisa.getData();

	var stVerse = objectTemp.stVerse;
	var cdOpinion = objectTemp.cdOpinion;
	var cdDictamenFinal = objectTemp.cdDictamenFinal;
	
	var cdDecisionPLD = formPremisa.cdDecisionPLD.val();
	var cdDecisionBanca = formPremisa.cdDecisionBanca.val();
	var cdDecisionJuridico = formPremisa.cdDecisionJuridico.val();
	
	var cdAccionPLD = formPremisa.cdAccionPLD.val();
	var cdAccionBanca = formPremisa.cdAccionBanca.val();
	var cdAccionJuridico = formPremisa.cdAccionJuridico.val();
	
	var combinacion = "";
	combinacion += (cdAccionPLD != null ? formPremisa.cdAccionPLD.text() : "X") + "-";
	combinacion += (cdAccionBanca != null ? formPremisa.cdAccionBanca.text() : "X") +"-";
	combinacion += (cdAccionJuridico != null ? formPremisa.cdAccionJuridico.text() : "X");
	
//	-------------------------------------- SQL --------------------------------------
	var sqlUpdate = "UPDATE GORAPR.TSCA217_REL_CASO_SIA SET CD_DECISION_FINAL = (CASE WHEN ";
	var sql = "SELECT COUNT(1) FROM GORAPR.TSCA206_CASO_OPINION T206 INNER JOIN GORAPR.TSCA217_REL_CASO_SIA T217 ON T217.CD_CASO_SIA = T206.CD_CASO LEFT JOIN GORAPR.TSCA010_SIPEMPLEADO T010 ON T206.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA024_USUARIO T024 ON T024.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA030_GERENCIA T030 ON T030.CD_GERENCIA = T024.CD_GERENCIA INNER JOIN GORAPR.TSCA282_GPO_CALIFICADOR T282 ON T282.CD_GPO_CALIFICADOR = T030.CD_GPO_CALIFICADOR WHERE T217.CD_CASO_SICA = ?";
	var sql2 = "SELECT COUNT(1) FROM GORAPR.TSCA206_CASO_OPINION T206 INNER JOIN GORAPR.TSCA217_REL_CASO_SIA T217 ON T217.CD_CASO_SIA = T206.CD_CASO AND T217.CD_CASO_SICA = ?";
//	-------------------------------------- PLD SQL --------------------------------------
	var sqlOficial = null;
	var sqlPLD = null;
	var sqlSupervisor = null;
	if(cdDecisionPLD != null || cdAccionPLD != null){
		sqlPLD = "(";
		sqlSupervisor = `(${sql2}`;
		sqlSupervisor += (configDecision(cdDecisionPLD));
		sqlSupervisor += (cdAccionPLD != null ? " AND (SELECT NB_VALOR FROM GORAPR.TSCA018_DET_CATALOG WHERE CD_CATALOGO = 15 AND CD_DET_CATALOGO = T206.CD_OPINION) "+configOpinion("cdAccionPLD") : "");
		sqlSupervisor += " AND T206.ST_SUPERVISOR = 1) = 1 OR ";
		
		sqlOficial = "("+sql;
		sqlOficial += (configDecision(cdDecisionPLD));
		sqlOficial += (cdAccionPLD != null ? " AND (SELECT NB_VALOR FROM GORAPR.TSCA018_DET_CATALOG WHERE CD_CATALOGO = 15 AND CD_DET_CATALOGO = T206.CD_OPINION) "+configOpinion("cdAccionPLD") : "");
		sqlOficial += " AND T030.CD_GPO_CALIFICADOR = 1 AND T206.ST_SUPERVISOR IS NULL) = 1 OR ";
		
		sqlPLD += sqlSupervisor + sqlOficial;
		sqlPLD += "("+sql;
		sqlPLD += (configDecision(cdDecisionPLD));
		sqlPLD += (cdAccionPLD != null ? " AND (SELECT NB_VALOR FROM GORAPR.TSCA018_DET_CATALOG WHERE CD_CATALOGO = 15 AND CD_DET_CATALOGO = T206.CD_OPINION) "+configOpinion("cdAccionPLD") : "");
		sqlPLD += " AND T030.CD_GPO_CALIFICADOR = 2 AND T206.ST_SUPERVISOR IS NULL) = 1) AND";
	} else {
		sqlPLD = "( (SELECT COUNT(1) FROM GORAPR.TSCA206_CASO_OPINION T206 INNER JOIN GORAPR.TSCA217_REL_CASO_SIA T217 ON T217.CD_CASO_SIA = T206.CD_CASO LEFT JOIN GORAPR.TSCA010_SIPEMPLEADO T010 ON T206.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA024_USUARIO T024 ON T024.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA030_GERENCIA T030 ON T030.CD_GERENCIA = T024.CD_GERENCIA INNER JOIN GORAPR.TSCA282_GPO_CALIFICADOR T282 ON T282.CD_GPO_CALIFICADOR = T030.CD_GPO_CALIFICADOR WHERE T217.CD_CASO_SICA = ? AND T206.CD_OPINION_INUSUAL IS NOT NULL AND T206.CD_OPINION IS NOT NULL AND T030.CD_GPO_CALIFICADOR IN (1,2) AND T206.ST_SUPERVISOR IS NULL) = 0 AND (SELECT COUNT(1) FROM GORAPR.TSCA206_CASO_OPINION T206 INNER JOIN GORAPR.TSCA217_REL_CASO_SIA T217 ON T217.CD_CASO_SIA = T206.CD_CASO AND T217.CD_CASO_SICA = 426579 AND T206.ST_SUPERVISOR = 1) = 0 ) AND";
	}
//	-------------------------------------- BANCA SQL --------------------------------------
	var sqlBanca = null;
	if(cdDecisionBanca != null || cdAccionBanca != null){
		sqlBanca = "("+sql;
		sqlBanca += (configDecision(cdDecisionBanca));
		sqlBanca += (cdAccionBanca != null ? " AND (SELECT NB_VALOR FROM GORAPR.TSCA018_DET_CATALOG WHERE CD_CATALOGO = 15 AND CD_DET_CATALOGO = T206.CD_OPINION) "+configOpinion("cdAccionBanca") : "");
		sqlBanca += " AND T030.CD_GPO_CALIFICADOR = 3 AND T206.ST_SUPERVISOR IS NULL) = 1 AND";
	} else {
		sqlBanca = "(SELECT COUNT(1) FROM GORAPR.TSCA206_CASO_OPINION T206 INNER JOIN GORAPR.TSCA217_REL_CASO_SIA T217 ON T217.CD_CASO_SIA = T206.CD_CASO LEFT JOIN GORAPR.TSCA010_SIPEMPLEADO T010 ON T206.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA024_USUARIO T024 ON T024.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA030_GERENCIA T030 ON T030.CD_GERENCIA = T024.CD_GERENCIA INNER JOIN GORAPR.TSCA282_GPO_CALIFICADOR T282 ON T282.CD_GPO_CALIFICADOR = T030.CD_GPO_CALIFICADOR WHERE T217.CD_CASO_SICA = ? AND T206.CD_OPINION_INUSUAL IS NOT NULL AND T206.CD_OPINION IS NOT NULL AND T030.CD_GPO_CALIFICADOR = 3) = 0 AND";
	}
//	-------------------------------------- JURIDICO SQL --------------------------------------
	var sqlJuridico = null;
	if(cdDecisionJuridico != null || cdAccionJuridico != null){
		sqlJuridico = "("+sql;
		sqlJuridico += (cdDecisionJuridico != null ? configDecision(cdDecisionJuridico) : "");
		sqlJuridico += (cdAccionJuridico != null ? " AND (SELECT NB_VALOR FROM GORAPR.TSCA018_DET_CATALOG WHERE CD_CATALOGO = 15 AND CD_DET_CATALOGO = T206.CD_OPINION) "+configOpinion("cdAccionJuridico") : "");
		sqlJuridico += " AND T030.CD_GPO_CALIFICADOR = 4 AND T206.ST_SUPERVISOR IS NULL) = 1";
	} else {
		sqlJuridico = "(SELECT COUNT(1) FROM GORAPR.TSCA206_CASO_OPINION T206 INNER JOIN GORAPR.TSCA217_REL_CASO_SIA T217 ON T217.CD_CASO_SIA = T206.CD_CASO LEFT JOIN GORAPR.TSCA010_SIPEMPLEADO T010 ON T206.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA024_USUARIO T024 ON T024.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA030_GERENCIA T030 ON T030.CD_GERENCIA = T024.CD_GERENCIA INNER JOIN GORAPR.TSCA282_GPO_CALIFICADOR T282 ON T282.CD_GPO_CALIFICADOR = T030.CD_GPO_CALIFICADOR WHERE T217.CD_CASO_SICA = ? AND T206.CD_OPINION_INUSUAL IS NOT NULL AND T206.CD_OPINION IS NOT NULL AND T030.CD_GPO_CALIFICADOR = 4) = 0";
	}
//	-------------------------------------- OPINION SQL --------------------------------------
	var sqlOpinion = null;
	var sqlOpinionOficial = null;
	if(cdOpinion == '4' || stVerse == 1){
		if(stVerse == 1){
			sqlOpinion = " THEN(NULL) ";
		}
		
		if(cdDictamenFinal != null){
			sqlOpinion = ` THEN('${cdDictamenFinal}') `;
		}
	} else {
		sqlOpinion = " THEN (SELECT (SELECT CD_OPINION_COMB FROM GORAPR.TSCA289_COMBINACION_CONSENSO WHERE CD_OPINION_INUSUAL = T206.CD_OPINION_INUSUAL AND CD_OPINION = T206.CD_OPINION) FROM GORAPR.TSCA206_CASO_OPINION T206 INNER JOIN GORAPR.TSCA217_REL_CASO_SIA T217 ON T217.CD_CASO_SIA = T206.CD_CASO LEFT JOIN GORAPR.TSCA010_SIPEMPLEADO T010 ON T206.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA024_USUARIO T024 ON T024.CD_USUARIO = T010.NU_NOMINA LEFT JOIN GORAPR.TSCA030_GERENCIA T030 ON T030.CD_GERENCIA = T024.CD_GERENCIA INNER JOIN GORAPR.TSCA282_GPO_CALIFICADOR T282 ON T282.CD_GPO_CALIFICADOR = T030.CD_GPO_CALIFICADOR WHERE T217.CD_CASO_SICA = ?";
		switch(cdOpinion){
		case '1':
			sqlOpinion += (configDecision(cdDecisionPLD));
			sqlOpinion += (cdAccionPLD != null ? " AND (SELECT NB_VALOR FROM GORAPR.TSCA018_DET_CATALOG WHERE CD_CATALOGO = 15 AND CD_DET_CATALOGO = T206.CD_OPINION) "+configOpinion("cdAccionPLD") : "");
			sqlOpinion += " AND ((T030.CD_GPO_CALIFICADOR IN (1,2) AND T206.ST_SUPERVISOR IS NULL) OR T206.ST_SUPERVISOR = 1) AND ROWNUM = 1)";
			break;
		case '2':
			sqlOpinion += (configDecision(cdDecisionBanca));
			sqlOpinion += (cdAccionBanca != null ? " AND (SELECT NB_VALOR FROM GORAPR.TSCA018_DET_CATALOG WHERE CD_CATALOGO = 15 AND CD_DET_CATALOGO = T206.CD_OPINION) "+configOpinion("cdAccionBanca") : "");
			sqlOpinion += " AND T030.CD_GPO_CALIFICADOR = 3 AND T206.ST_SUPERVISOR IS NULL)";
			break;
		case '3':
			sqlOpinion += (configDecision(cdDecisionJuridico));
			sqlOpinion += (cdAccionJuridico != null ? " AND (SELECT NB_VALOR FROM GORAPR.TSCA018_DET_CATALOG WHERE CD_CATALOGO = 15 AND CD_DET_CATALOGO = T206.CD_OPINION) "+configOpinion("cdAccionJuridico") : "");
			sqlOpinion += " AND T030.CD_GPO_CALIFICADOR = 4 AND T206.ST_SUPERVISOR IS NULL)";
			break;
		}
	}
	
	var sqlCase = null;
	sqlCase = `${sqlPLD} ${sqlBanca} ${sqlJuridico}`;
	sqlCase += sqlOpinion;
	sqlUpdate += `${sqlCase}ELSE(SELECT CD_DECISION_FINAL FROM GORAPR.TSCA217_REL_CASO_SIA WHERE CD_CASO_SICA = ?) END) WHERE CD_CASO_SICA = ?`;
	
	var premisaDTO = new Object();
	premisaDTO.nbNombre = objectTemp.nbNombre;
	premisaDTO.nbDescripcion = combinacion;
	premisaDTO.txQuery = sqlUpdate.substring(0, 3999);
	premisaDTO.stActivo = "A";
	premisaDTO.txQueryExt = sqlUpdate.substring(3999, 79998);
	premisaDTO.stVerse =  objectTemp.stVerse ;
	premisaDTO.cdSegmento = objectTemp.cdSegmento;
	premisaDTO.nuDiasCte = objectTemp.nuDiasCte;
	premisaDTO.nuDiasCta = objectTemp.nuDiasCta;
	premisaDTO.nbOficialPld = `${objectTemp.cdDecisionPLD}|${objectTemp.cdAccionPLD}`;
	premisaDTO.nbBanca = `${objectTemp.cdDecisionBanca}|${objectTemp.cdAccionBanca}`;
	premisaDTO.nbJuridico = `${objectTemp.cdDecisionJuridico}|${objectTemp.cdAccionJuridico}`;
	premisaDTO.stOpinion = objectTemp.cdOpinion;
	premisaDTO.cdDecisionFinal = objectTemp.cdDictamenFinal;
	premisaDTO.stCompartido = '1';
	
//	console.info(sqlUpdate);
//	console.info(premisaDTO);
	
	Ajax.put('PremisaSiaService/guardarPremisa' + (cdPremisa != null ? `/${cdPremisa}` : ''), premisaDTO).done(function(data){
		if(Ajax.statusOK(data, true)){
			tablePremisas.load();
		}
	})
}

function configDecision(cdDecision){
	var sql = '';
	
	if(cdDecision != null){
		var value = cdDecision.split('-');
		
		sql = ` AND (T206.CD_OPINION_INUSUAL = '${value[0]}' `;
		if(value.length > 1){
			sql += `OR T206.CD_OPINION_INUSUAL = '${value[1]}'`
		}
		sql += ')';
	}
	
	
	return sql;
}

function configOpinion(cdAccion){
	var valueAccion = formPremisa[cdAccion].val();
	var value = formPremisa[cdAccion].text();
	var sql;
	
	if(valueAccion.indexOf("CAL") == 0 || valueAccion.indexOf("CAN") == 0 || valueAccion.indexOf("CON") == 0){
		sql = `LIKE '%${value}%'`;
	} else {
		sql = `= '${value}'`;
	}
	
	return sql;
}
//======================= SERVICES =======================
function changeOpinion(){
	var cdOpinion = formPremisa.cdOpinion.val();
	
	if(cdOpinion == 4){
		CatalogoSia.cdCatalogo(15, formPremisa.cdDictamenFinal, {
			value: 'cdDetCatalogo',
			text: 'nbValor',
			firstOption: '-- DICTAMEN FINAL --'
		});
	} else {
		formPremisa.cdDictamenFinal.setCombo('remove');
	}
	
	formPremisa.cdDictamenFinal.show(cdOpinion == 4)
}