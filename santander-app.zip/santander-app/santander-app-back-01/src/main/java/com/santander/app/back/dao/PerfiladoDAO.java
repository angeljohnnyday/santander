package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.ModuloDTO;
import com.santander.app.back.dto.UsuarioDTO;

@Component
public class PerfiladoDAO {
	private static Logger LOGGER = LoggerFactory.getLogger(PerfiladoDAO.class);
	@PersistenceContext private EntityManager em;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public UsuarioDTO getUsuario(String nbCveRed, String cdPerfil) throws Exception{
		List<UsuarioDTO> resultado = new ArrayList<UsuarioDTO>();
		UsuarioDTO usuarioDTO = null;
		Query query = em.createNativeQuery(Consultas.getConsulta("getUsuario"));
		query.setParameter("nbCveRed", nbCveRed);
		query.setParameter("cdPerfil", cdPerfil);
		query.unwrap(NativeQuery.class)
		.addScalar("cdUsuario", StringType.INSTANCE)
		.addScalar("cdPerfil1", BigDecimalType.INSTANCE)
		.addScalar("nbPerfil1", StringType.INSTANCE)
		.addScalar("cdPerfil2", BigDecimalType.INSTANCE)
		.addScalar("nbPerfil2", StringType.INSTANCE)
		.addScalar("nbCveRed", StringType.INSTANCE)
		.addScalar("nbPersona", StringType.INSTANCE)
		.addScalar("nbMaterno", StringType.INSTANCE)
		.addScalar("nbPaterno", StringType.INSTANCE)
		.addScalar("cdStSistema", StringType.INSTANCE)
		.addScalar("cdSupervisor", StringType.INSTANCE)
		.addScalar("cdGerencia", BigDecimalType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(UsuarioDTO.class));
		resultado = (List<UsuarioDTO>)query.getResultList();
		
		if(!resultado.isEmpty() ) {
			usuarioDTO = resultado.get(0);
			LOGGER.info(usuarioDTO.toString());
			if(usuarioDTO.getCdPerfil1() != null){
				usuarioDTO.setLstModulos1(lstModulosPerfil(usuarioDTO.getCdPerfil1()));
			}
		}
		
		return usuarioDTO;
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<ModuloDTO> lstModulosPerfil(BigDecimal cdPerfil) throws Exception{
		List<ModuloDTO> lstModulos = null;

		Query query = em.createNativeQuery(Consultas.getConsulta("lstModulosPerfil"));
		query.setParameter("cdPerfil", cdPerfil);
		query.unwrap(NativeQuery.class)
		.addScalar("txModulo", StringType.INSTANCE)
		.addScalar("nbModulo", StringType.INSTANCE)
		.addScalar("cdModulo", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(ModuloDTO.class));

		lstModulos = (List<ModuloDTO>)query.getResultList();

		return lstModulos;
	}
}
