package com.santander.app.back.srv;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.CasosPendientesSiaDAO;
import com.santander.app.back.util.Response;
import com.santander.app.back.util.Pagination;

public class CasosPendientesSiaServiceImpl implements CasosPendientesSiaService {
	@Autowired private CasosPendientesSiaDAO casosPendientesSiaDAO;

	@Override
	public Response<Object> lstCasos(BigDecimal cdUsuario, Integer limit, Integer offset, String name, String order, String q) {
		try {
			Pagination pagination = new Pagination();
			pagination.setRows(casosPendientesSiaDAO.lstCasos(cdUsuario, limit, offset, name, order, q));
			pagination.setTotal(casosPendientesSiaDAO.totalLstCasos(cdUsuario, q));
			
			return new Response<Object>(pagination, Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
