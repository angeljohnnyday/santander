package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.ClienteReportadoDTO;

@Component
public class DatosGeneralesClienteReportadoSiaDAO {
	@PersistenceContext private EntityManager em;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public ClienteReportadoDTO getDatosGeneralesByClienteReportado(String cdCliente, BigDecimal cdCaso) throws Exception {
		ClienteReportadoDTO clienteReportadoDTO = new ClienteReportadoDTO();
		List<ClienteReportadoDTO> resultado = new ArrayList<ClienteReportadoDTO>();
		
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getDatosGeneralesByClienteReportado"));
		query.setParameter("cdCliente", cdCliente);
		query.setParameter("cdCaso", cdCaso);
		query.unwrap(NativeQuery.class)
		.addScalar("nuCliente", StringType.INSTANCE)
		.addScalar("nbCliente")
		.addScalar("apPaterno")
		.addScalar("apMaterno")
		.addScalar("nuTelParticular")
		.addScalar("nuTelOficina")
		.addScalar("fhNacimiento")
		.addScalar("fhAntiguedad", TimestampType.INSTANCE)
		.addScalar("nuRFC")
		.addScalar("nbDomicilio")
		.addScalar("nbNacionalidad",StringType.INSTANCE)
		.addScalar("nbCiudadPoblacion")
		.addScalar("nbEntidadFederativa")
		.addScalar("fhRepotpPersonarteBuzon")
		.addScalar("nbActividadBanxico")
		.addScalar("nbActividadBanxicoCed2")
		.addScalar("tipoPersona")
		.addScalar("cdSectorD")
		.addScalar("nbSegmentoCte",StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(ClienteReportadoDTO.class));
		
		resultado = (List<ClienteReportadoDTO>)query.getResultList();
		
		if( !resultado.isEmpty() ){
			clienteReportadoDTO = resultado.get(0);	
		}
		
		return clienteReportadoDTO;
	}
}
