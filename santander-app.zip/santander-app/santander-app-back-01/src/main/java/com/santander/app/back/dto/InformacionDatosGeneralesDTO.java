package com.santander.app.back.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class InformacionDatosGeneralesDTO {
	private String nuFolio;
	private String nbConsultor;
	private String nuFolios;
	private String cdTipo;
	private String nuCasos;
	private String nuFolioBase;
	private String cdSistema;
	private String nuCuentaReportada;
	private BigDecimal imReportado;
	private Date fhOperacion;
	private Date fhDeteccion;
	private Date fhReporteBuzon;
	private Date fhAsignacion;
	private String cdSesion;
	
	private String cdDivisa;
	private String cdPrioridad;
	private String importeDivisa;
	private String cdPrioridadCed2;
	private BigDecimal imReportadoNuevo;
	private String importeDivisaCed2;
	
	private String cdInusual;
	private String opinionPrevia;
	private String decisionFinal;
	private String nuFolioAlerta;
	
	private Date fhReconsideracion;
	private String nbMultibanca;
	private String cdSesionIn;
}
