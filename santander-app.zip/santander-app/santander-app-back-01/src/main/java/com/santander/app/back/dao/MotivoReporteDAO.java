package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.MotivoReporteDTO;

@Component
public class MotivoReporteDAO {
	@PersistenceContext EntityManager em;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public MotivoReporteDTO getMotivoReporte(BigDecimal cdCasoSica) throws Exception{
		MotivoReporteDTO motivoReporteDTO = new MotivoReporteDTO();
		List<MotivoReporteDTO> resultado = null;
		
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getMotivoReporte"));
		query.setParameter("cdCasoSica", cdCasoSica);
		query.unwrap(NativeQuery.class)
		.addScalar("txMotivoReporte")
		.setResultTransformer(Transformers.aliasToBean(MotivoReporteDTO.class));
		resultado = (List<MotivoReporteDTO>)query.getResultList();
		 
		if ( !resultado.isEmpty()){
			motivoReporteDTO = resultado.get(0);
		}
		
		return motivoReporteDTO;
	}
}
