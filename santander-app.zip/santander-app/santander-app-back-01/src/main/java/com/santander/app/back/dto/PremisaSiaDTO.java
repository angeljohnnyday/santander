package com.santander.app.back.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class PremisaSiaDTO {
	private BigDecimal cdPremisa;
	private String nbNombre;
	private String nbDescripcion;
	private String txQuery;
	private Date fhAlta;
	private Date fhModif;
	private String stActivo;
	private String txQueryExt;
	private String stVerse;
	private String cdSegmento;
	private BigDecimal nuDiasCte;
	private BigDecimal nuDiasCta;
	private String nbContexto;
	private String nbOficialPld;
	private String nbBanca;
	private String nbJuridico;
	private String stOpinion;
	private String cdDecisionFinal;
	private String stCompartido;
}
