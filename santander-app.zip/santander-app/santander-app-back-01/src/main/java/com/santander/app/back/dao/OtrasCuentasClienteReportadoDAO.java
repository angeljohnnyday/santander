package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.santander.app.back.dto.CuentasClienteReportadoDTO;
import com.santander.app.back.util.Money;

import oracle.jdbc.OracleTypes;

@Component
public class OtrasCuentasClienteReportadoDAO {
	@PersistenceContext EntityManager em;
	@Autowired JdbcTemplate jdbcTemplate;
	
	@Transactional
	public List<CuentasClienteReportadoDTO> lstOtrasCuentasClienteReportado(BigDecimal cdCaso, String cdCliente ) throws Exception {
		List<CuentasClienteReportadoDTO> lstCuentasClienteReportadoDTO = new ArrayList<CuentasClienteReportadoDTO>();
		
		Connection con = jdbcTemplate.getDataSource().getConnection();
		CallableStatement cstmt = con.prepareCall("{ CALL PG_MANTENIMIENTO.SP_CON_CTAS(?,?,?,?,?) }");
		cstmt.setQueryTimeout(1800);
		cstmt.setBigDecimal(1, cdCaso);
		cstmt.setString(2, cdCliente);
		cstmt.registerOutParameter(3, OracleTypes.CURSOR);
		cstmt.registerOutParameter(4, OracleTypes.NUMBER);
		cstmt.registerOutParameter(5, OracleTypes.VARCHAR);
		cstmt.execute();
	      
		ResultSet rset = (ResultSet) cstmt.getObject(3);
		BigDecimal variableSalida = (BigDecimal) cstmt.getObject(4);
	      
		if ( !variableSalida.equals( new BigDecimal(-2) ) && !variableSalida.equals( new BigDecimal(-1) ) ){
			
			while (rset.next()){
				CuentasClienteReportadoDTO cuentasClienteReportadoDTO = new CuentasClienteReportadoDTO();
	            
				cuentasClienteReportadoDTO.setFhAperturaCCR(rset.getString("fh_apertura") != null ? rset.getString("fh_apertura") : "");
	            cuentasClienteReportadoDTO.setNuCuentaCCR(rset.getString("nu_cuenta_par") != null ? rset.getString("nu_cuenta_par") : "");
	            
	            String sCdProducto = rset.getString("cd_producto") != null ? rset.getString("cd_producto") : "";
	            String sCdNbProducto = rset.getString("nb_producto") != null ? rset.getString("nb_producto") : "";
	            String sNbProductoCCR = "";
	            if (!sCdProducto.isEmpty() && !sCdNbProducto.isEmpty()) {
	               sNbProductoCCR = sCdProducto + " - " + sCdNbProducto;
	            }
	            else if (sCdProducto.isEmpty() || sCdNbProducto.isEmpty()) {
	               sNbProductoCCR = !sCdProducto.isEmpty() ? sCdProducto : sCdNbProducto;
	            }
	            cuentasClienteReportadoDTO.setNbProductoCCR(sNbProductoCCR);

	            String sCdSubProducto = rset.getString("cd_subproducto") != null ? rset.getString("cd_subproducto") : "";
	            String sNbSubProducto = rset.getString("nb_subproducto") != null ? rset.getString("nb_subproducto") : "";
	            String sNbSubproductoCCR = "";
	            
	            if (!sCdSubProducto.isEmpty() && !sNbSubProducto.isEmpty()) {
	               sNbSubproductoCCR = sCdSubProducto + " - " + sNbSubProducto;
	            }
	            else if (sCdSubProducto.isEmpty() || sNbSubProducto.isEmpty()) {
	               sNbSubproductoCCR = !sCdSubProducto.isEmpty() ? sCdSubProducto : sNbSubProducto;
	            }
	            
	            cuentasClienteReportadoDTO.setNbSubproductoCCR(sNbSubproductoCCR);
	            cuentasClienteReportadoDTO.setNbEstatusCCR(rset.getString("st_cta") != null ? rset.getString("st_cta") : "");
	            cuentasClienteReportadoDTO.setNuCtePartCCR(rset.getString("cd_cliente_par") != null ? rset.getString("cd_cliente_par") : "");
	            cuentasClienteReportadoDTO.setNbParticipesCCR(rset.getString("clte_participe") != null ? rset.getString("clte_participe") : "");
	            cuentasClienteReportadoDTO.setCdSec(rset.getString("sec") != null ? rset.getString("sec") : "");
	            
	            String imSaldo = rset.getString("im_saldo") != null ?  rset.getString("im_saldo") : "";            
	            String imPromedio = rset.getString("im_promedio") != null ?  rset.getString("im_promedio") : "";
	            String fhSaldo = rset.getString("fh_saldo") != null ? rset.getString("fh_saldo") : "";
	            
	            if(!imSaldo.isEmpty()){
	               imSaldo = Money.getMoney(imSaldo); 
	            }            
	            if(!imPromedio.isEmpty()){
	               imPromedio = Money.getMoney(imPromedio); 
	            }
	                        
	            String sImSaldoCCR = "";
	            if (!imSaldo.isEmpty() && !fhSaldo.isEmpty()) {
	               sImSaldoCCR = imSaldo + " al " + fhSaldo;
	            }
	            else if (imSaldo.isEmpty() || fhSaldo.isEmpty()) {
	               sImSaldoCCR = !imSaldo.isEmpty() ? imSaldo : fhSaldo;
	            }
	            cuentasClienteReportadoDTO.setImSaldoCCR( sImSaldoCCR );            
	            cuentasClienteReportadoDTO.setImSaldoPromCCR( imPromedio );            
	            cuentasClienteReportadoDTO.setNbComentariosCCR( rset.getString("nb_comentario") != null ? rset.getString("nb_comentario") : "");            
	            
	            String sCdIntervencion = rset.getString("cd_intervencion") != null ?  rset.getString("cd_intervencion") : "";
	            String sNuSecuencia = rset.getString("nu_secuencia") != null ?  rset.getString("nu_secuencia") : "";
	            String sTitular = rset.getString("titular") != null ?  rset.getString("titular") : "";
	            
	            String sNbTitularCCR = "";
	            String sCdIntervencionNuSecuencia = sCdIntervencion + sNuSecuencia;
	            if (!sCdIntervencionNuSecuencia.isEmpty() && !sTitular.isEmpty()) {
	               sNbTitularCCR = sCdIntervencionNuSecuencia + " - " + sTitular;
	            }
	            else if (sCdIntervencionNuSecuencia.isEmpty() || sNuSecuencia.isEmpty()) {
	               sNbTitularCCR = !sCdIntervencionNuSecuencia.isEmpty() ? sCdIntervencionNuSecuencia : sTitular ;
	            }
	            
	            cuentasClienteReportadoDTO.setNbTitularCCR( sNbTitularCCR);
	            cuentasClienteReportadoDTO.setNbBancaCCR( rset.getString("nb_Banca") != null ? rset.getString("nb_Banca") : "");
	            cuentasClienteReportadoDTO.setNbDetParticipesCCR( rset.getString("clte_participe") != null ? rset.getString("clte_participe") : "");
	            cuentasClienteReportadoDTO.setNbParticipesCCR( rset.getString("cd_rel_ctecta") != null ? rset.getString("cd_rel_ctecta") : "");
	            cuentasClienteReportadoDTO.setTpCargaCCR( rset.getString("tp_carga") != null ? rset.getString("tp_carga") : "");
	            
	            if (rset.getString("tp_carga") != null && !rset.getString("tp_carga").equals("")) {
	               if (rset.getString("tp_carga").equals("M")) {
	                  cuentasClienteReportadoDTO.setTpCargaCCR("MANUAL");
	               }
	               else {
	                  cuentasClienteReportadoDTO.setTpCargaCCR("AUTOMATICA");
	               }
	            }
	            lstCuentasClienteReportadoDTO.add(cuentasClienteReportadoDTO);
	         }
	      }
	      
	      rset.close();
	      cstmt.close();
	      con.close();
	      
	      return lstCuentasClienteReportadoDTO;
	   }
}
