package com.santander.app.back.repo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.santander.app.back.dominio.Tsca281Premisa;

@Repository
public interface Tsca281Repo extends JpaRepository<Tsca281Premisa, BigDecimal> {
	
}
