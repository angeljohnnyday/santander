package com.santander.app.front.controller;

import java.util.HashMap;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.santander.app.front.util.Utilidad;

@Controller
public class IndexSICAController {
	@Autowired Utilidad utilidad;
	
	@GetMapping("/perfilado")
	public String perfilado(Model model) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("baseUrl", utilidad.getUrlBase());
		map.put("baseUrlSica", utilidad.getUrlFrontSica());
		map.put("baseUrlSia", utilidad.getUrlFrontSia());
		map.put("baseUrlRed", utilidad.getUrlFrontRed());
		map.put("baseUrlIndex", utilidad.getUrlIndex());
		
		model.addAttribute("component", map);
		
		return "perfilado";
	}
	
	@GetMapping("/login")
	public String login(Model model) {
		return "login";
	}
	
	@GetMapping("/admon")
	public String index() {
		return "admon";
	}
	
	@GetMapping("/view/{page}")
	public String view(@PathVariable("page") String page) {
		return page +" :: "+ page;
	}
}
