var movimientoDTO = Session.get('movimientoDTO');

function formatterTpMov(value, row, index){
	if(value != null){
		return (value == "H" ? "ABONO" : "CARGO")
	} else {
		return '';
	}
}