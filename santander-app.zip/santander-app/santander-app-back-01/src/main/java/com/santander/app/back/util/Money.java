package com.santander.app.back.util;

import java.text.DecimalFormat;

public class Money {
	private static DecimalFormat formatterMoney = new DecimalFormat("###,###.00");
	
	static public String getMoney(String str) {
		return formatterMoney.format(Double.parseDouble(str));
	}
	
}
