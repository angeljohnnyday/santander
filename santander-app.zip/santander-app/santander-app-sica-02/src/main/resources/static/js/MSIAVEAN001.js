var casoDTO = Session.get('casoDTO');

$(function(){
	getCuadrosTexto();
});

function getCuadrosTexto(){
	Ajax.get(`InformacionAdministrativaService/getCuadrosTexto/${casoDTO.cdCaso}`).done(function(data){
		if(Ajax.statusOK(data, false)){
			cuadrosTexto.nbDescripcionOperacion.val(data.body.nbDescripcionOperacion);
			cuadrosTexto.nbRazonesInusual.val(data.body.nbRazonesInusual);
		}
	});
}

function guarCuadrosTexto(){
	
}