package com.santander.app.back.repo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.santander.app.back.dominio.Tsca236CniCliente;

@Repository
public interface Tsca236Repo extends JpaRepository<Tsca236CniCliente, BigDecimal>{

}
