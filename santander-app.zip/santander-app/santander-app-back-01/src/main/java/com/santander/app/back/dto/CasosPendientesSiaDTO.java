package com.santander.app.back.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class CasosPendientesSiaDTO {
	private String nuCaso;
	private BigDecimal cdCaso;
	private String cdPrioridad;
	private String nbPrioridad;
	private String cdAppOrigen;
	private String nbAppOrigen;
	private String nuCuenta;
	private String cdCliente;
	private String nuActa;
	private String nbActa;
	private String nbCliente;
	private String nuFolioAlerta;
	private String cdSistema;
	private String nbSistema;
	private Date fhReporteDel;
	private Date fhReporteAl;
	private Date fhRepAut;
	private String cdCasoDel;
	private String cdCasoAl;
	private String cdEstatus;
	private String nbConsultor;
	private String tpCaso;
	private String nuDiasReportar;
	private Date fhAsignacionDel;
	private Date fhAsignacionAl;
	private String cdCasoSicaDel;
	private String cdCasoSicaAl;
	private String cdCasoSica;
	private String imMontoDel;
	private String imMontoAl;
	private String imMonto;
	private String tpAsignacion;
	private Date fhAsignacion;
	private BigDecimal cdStCaso;
	private Date fhAlerta;
	private String stActualizar;
}
