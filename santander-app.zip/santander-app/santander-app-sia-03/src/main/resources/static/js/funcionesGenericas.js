function formatterDate(value, row, index) {
	var date = "";
	
	if( value != null && value != '' && value != undefined && value != 'null'){
		$("#date-picker").datepicker('setDate', new Date(value));
		var date = $("#date-picker").val();
		$("#date-picker").val(null);
	}
	
	return date;
}

function formatterMoney(value, row, index) {
	var money = "0";
	
	if( value != null && value != '' && value != 'null'){
		$('#mask-money').maskMoney('mask', value);
		money = $('#mask-money').val();
		$('#mask-money').val(null);
	}
	
	return money;
}

function formatterNumber(value, row, index) {
	var number = "0";
	
	if( value != null && value != '' && value != 'null'){
		$('#mask-number').maskMoney('mask', value);
		number = $('#mask-number').val();
		$('#mask-number').val(null);
	}
	
	return number;
}

function formatterTotal() {
	return 'Total:';
}

function formatterSumaOperacion(data, field) {
	var field = this.field;
	var suma = 0;
	data.forEach((row)=>{
		if(row[field] != null){
			suma += row[field];
		}
	});
	return suma;
}

function formatterSumaMonto(data, field) {
	var field = this.field;
	var suma = 0;
	data.forEach((row)=>{
		if(row[field] != null){
			suma += row[field];
		}
	});
	
	if(suma != 0) suma = parseFloat(suma.toFixed(2));
	
	return formatterMoney(suma);
}

function formatterSumaPorcentaje(data, field) {

	var field = this.field;
	var suma = 0;
	data.forEach((row)=>{
		if(row[field] != null){
			suma += row[field];
		}
	});
	
	if(suma != 0) suma = Math.round(suma.toFixed(2));
	
	return `${suma}%`;
}

function formatterPorcentaje(value, row, index) {
	value = formatterMoney(value);
	return `${value}%`;
}

function formatterSumaPromedio(data, field) {
	var field = this.field;
	var suma = 0;
	
	data.forEach((row)=>{
		if(row[field] != null){
			suma += row[field];
		}
	});
	
	if(suma != 0) suma = parseFloat(suma.toFixed(2));
	
	return formatterMoney(suma);
}

function formatterPromedio(data, field) {
	var field = this.field;
	var suma = 0;
	var total = 0;
	
	data.forEach((row)=>{
		if(row[field] != null && row[field] != 0){
			total ++;
			suma += row[field];
		}
	});

	var promedio = (suma / total);
	if(promedio != 0) promedio = parseFloat(promedio.toFixed(2));
	
	return formatterMoney(promedio);
}

function formatShowingRows(pageFrom, pageTo, totalRows) {
	return `Mostrando ${pageFrom} al ${pageTo} de ${totalRows} registros`;
}

function  formatRecordsPerPage(pageNumber) {
	return `${pageNumber} registros por p\u00e1gina`;
}
function  formatLoadingMessage() {
	return 'Cargando, espere por favor...';
}

function  formatSearch() {
	return 'Buscar';
}

function  formatNoMatches() {
	return 'No se encontr&oacute; informaci&oacute;n';
}

const getValue = (el) => {
	var value = null;
	switch(el.type){
	case 'text':
		value = el.value;
		break;
	case 'radio':
		
		break;
	case 'checbox':
		value = (el.checked ? 1 : 0);
		break;
	case 'textarea':
		value = el.value;
		break;
	case 'select-one':
		if(el.value != '-1' && el.value != '') value = el.value;
		break;
	}
	
	return value;
}

const setValue = (el, value) => {
	switch(el.type){
	case 'text':
		el.value = (value == null ? '' : value);
		break;
	case 'radio':
		
		break;
	case 'checbox':
		value = (el.checked ? 1 : 0);
		break;
	case 'textarea':
		el.value = (value == null ? '' : value);
		break;
	case 'select-one':
		el.setAttribute('data-value', value == null ? '-1' : value);
		el.value = (value == null ? '-1' : value);
		break;
	}
}

const serialize = (object) => {
	 var text = encodeURI(JSON.stringify(object));
	 return`?q=${text}`;
}

const llenarFormulario = (form, data) => {
	var form = document.querySelector(`[data-form=${form}]`);
	if(form != null){
		var lstData = Object.keys(data);
		lstData.forEach(name => {
			var el = form.querySelector(`[name=${name}]`);
			if(el != null) {
				if(el.dataset.formatter != null && el.dataset.formatter != ''){
					var fn = eval(el.dataset.formatter);
					setValue(el, fn(data[name]));
				} else {
					setValue(el, data[name]);
				}
			}
		})
	}
}

function setParameters(f){
	var args = Array.prototype.splice.call(arguments, 1);
    f.apply(null, args);
}