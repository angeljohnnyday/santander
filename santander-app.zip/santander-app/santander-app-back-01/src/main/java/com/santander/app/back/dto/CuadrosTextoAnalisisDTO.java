package com.santander.app.back.dto;

import lombok.Data;

@Data
public class CuadrosTextoAnalisisDTO {
	private String nbDescripcionOperacion;
	private String nbRazonesInusual;
	private String nbComentariosGenerales217;
}
