package com.santander.app.back.srv;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.DelitoDAO;
import com.santander.app.back.dto.DelitoDTO;
import com.santander.app.back.util.Pagination;
import com.santander.app.back.util.Response;

public class DelitoServiceImpl implements DelitoService {
	@Autowired private DelitoDAO delitoDAO;

	@Override
	public Response<Object> lstDelitos(Integer limit, Integer offset, String search, String name, String order) {
		try {
			Pagination pagination = new Pagination();
			pagination.setRows(delitoDAO.lstDelitos(limit, offset, search, name, order));
			pagination.setTotal(delitoDAO.totalLstDelitos());
			return new Response<>(pagination, Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getDelito(BigDecimal cdDelito) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Response<Object> guardarDelito(DelitoDTO delitoDTO) {
		try {
			delitoDAO.guardarDelito(delitoDTO);
			return new Response<>(Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> guardarDelito(BigDecimal cdDelito, DelitoDTO delitoDTO) {
		try {
			delitoDAO.guardarDelito(cdDelito, delitoDTO);
			return new Response<>(Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> cambiarStatus(List<DelitoDTO> lstDelitoDTO) {
		try {
			delitoDAO.cambiarStatus(lstDelitoDTO);
			return new Response<>(Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> eliminarDelitos(List<DelitoDTO> lstDelitoDTO) {
		try {
			delitoDAO.eliminarDelitos(lstDelitoDTO);
			return new Response<>(Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
