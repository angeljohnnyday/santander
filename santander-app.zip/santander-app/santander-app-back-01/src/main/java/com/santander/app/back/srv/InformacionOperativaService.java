package com.santander.app.back.srv;

import java.math.BigDecimal;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.santander.app.back.util.Response;

@Path("/InformacionOperativaService")
public interface InformacionOperativaService {
	
	@GET
	@Path("/getCuadroConceptoTotal/{cdCasoSica}/{nuCuenta}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> getCuadroConceptoTotal(
		@PathParam("cdCasoSica") BigDecimal cdCasoSica,
		@PathParam("nuCuenta") String nuCuenta
	);
	
	@GET
	@Path("/lstMecanicaOperacional/{cdCasoSica}/{nuCuenta}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstMecanicaOperacional(
		@PathParam("cdCasoSica") BigDecimal cdCasoSica,
		@PathParam("nuCuenta") String nuCuenta,
		@QueryParam("limit") Integer limit,
		@QueryParam("offset") Integer offset,
		@QueryParam("search") String search,
		@QueryParam("name") String name,
		@QueryParam("order") String order
	);
	
	@GET
	@Path("/lstMovimientosSia/{cdCasoSica}/{nuCuenta}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstMovimientosSia(
		@PathParam("cdCasoSica") BigDecimal cdCasoSica, 
		@PathParam("nuCuenta") String nuCuenta,
		@QueryParam("limit") Integer limit,
		@QueryParam("offset") Integer offset,
		@QueryParam("search") String search,
		@QueryParam("name") String name,
		@QueryParam("order") String order
	);
	
	@GET
	@Path("/getMontoTotales/{cdCasoSica}/{nuCuenta}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> getMontoTotales(
		@PathParam("cdCasoSica") BigDecimal cdCasoSica, 
		@PathParam("nuCuenta") String nuCuenta
	);
	
	@GET
	@Path("/lstMovMuestra/{tpMovimiento}/{cdCaso}/{cdCasoSia}/{nuCuenta}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstMuestra(
		@PathParam("tpMovimiento") String tpMovimiento,
		@PathParam("cdCaso") BigDecimal cdCaso,
		@PathParam("cdCasoSia") BigDecimal cdCasoSia, 
		@PathParam("nuCuenta") String nuCuenta,
		@QueryParam("limit") Integer limit,
		@QueryParam("offset") Integer offset,
		@QueryParam("search") String search,
		@QueryParam("name") String name,
		@QueryParam("order") String order
	);
}