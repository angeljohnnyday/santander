package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dominio.Tsca236CniCliente;
import com.santander.app.back.dto.InformacionPldDTO;
import com.santander.app.back.repo.Tsca236Repo;

@Component
public class InformacionPldDAO {
	@PersistenceContext private EntityManager em;
	@Autowired private Tsca236Repo tsca236Repo;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public InformacionPldDTO getInformacionPLDCedula( BigDecimal cdCasoSia ) throws Exception{
		
		InformacionPldDTO informacionPldDTO = new InformacionPldDTO();
		List<InformacionPldDTO> resultado = new ArrayList<InformacionPldDTO>();
		 
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getInformacionPLDCedula"));
		query.setParameter("cdCasoSia" ,cdCasoSia);
		query.unwrap(NativeQuery.class)
		.addScalar("nbNacionalidad",StringType.INSTANCE)
		.addScalar("nbActividadNegocio",StringType.INSTANCE)
		.addScalar("tpOperacion",StringType.INSTANCE)
		.addScalar("nbTipoligia",StringType.INSTANCE)
		.addScalar("tpPersona",StringType.INSTANCE)
		.addScalar("nbInstrumentoMonetario",StringType.INSTANCE)
		.addScalar("nbOrdenPago",StringType.INSTANCE)
		.addScalar("nbOrigen",StringType.INSTANCE)
		.addScalar("nbDelito",StringType.INSTANCE)	 
		.setResultTransformer(Transformers.aliasToBean(InformacionPldDTO.class));
		resultado = (List<InformacionPldDTO>) query.getResultList();
		
		if( !resultado.isEmpty() ){
			informacionPldDTO = resultado.get(0);	
		}
		
		return informacionPldDTO;
	}
	
	public Tsca236CniCliente getInformacionPLD( BigDecimal cdCasoSia ) throws Exception{
		if(tsca236Repo.existsById(cdCasoSia)) return tsca236Repo.findById(cdCasoSia).get();
		
		return null;
	}
}
