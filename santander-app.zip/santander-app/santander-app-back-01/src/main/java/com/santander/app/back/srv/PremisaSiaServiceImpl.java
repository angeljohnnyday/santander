package com.santander.app.back.srv;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.PremisaSiaDAO;
import com.santander.app.back.dto.PremisaSiaDTO;
import com.santander.app.back.util.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PremisaSiaServiceImpl implements PremisaSiaService {
	@Autowired private PremisaSiaDAO premisaSiaDAO;

	@Override
	public Response<Object> lstPremisasByStCompartido(String stCompartido) {
		try {
			return new Response<>(premisaSiaDAO.lstPremisasByStCompartido(stCompartido), Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstDecisionPremisa() {
		try {
			return new Response<>(premisaSiaDAO.lstDecisionPremisa(), Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstAccionPremisa() {
		try {
			return new Response<>(premisaSiaDAO.lstAccionPremisa(),Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> guardarPremisa(PremisaSiaDTO premisaSiaDTO) {
		try {
			premisaSiaDAO.guardarPremisa(premisaSiaDTO);
			return new Response<>(Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> guardarPremisa(BigDecimal cdPremisa, PremisaSiaDTO premisaSiaDTO) {
		try {
			premisaSiaDAO.guardarPremisa(cdPremisa, premisaSiaDTO);
			return new Response<>(Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> eliminarPremisa(BigDecimal cdPremisa) {
		try {
			premisaSiaDAO.eliminarPremisa(cdPremisa);
			return new Response<>(Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
