var TP_OFICINA_G = "G";
var TP_OFICINA_R = "R";

var module01_1 = new Module({
	el: 'MSIAVEAN001_1',
	form:{
		oficinaGestiona:{
			data:{
				nuOficina: '',
				nbOficina: '',
				cdRiesgo: '',
				nbMercado: '',
				cdDivision: '',
				nbFuncionario: '',
			}
		},
		informacionPLD:{
			data:{
				nbNacionalidad: '-1',
				tpPersona: '-1',
				nbActividadNegocio: '-1',
				nbOrdenPago: '-1',
				tpOperacion: '-1',
				nbInstrumentoMonetario: '-1',
				nbTipoligia: '-1',
				nbOrigen: '-1',
				cdDelito: '-1'
			}
		}
	},
	data:{
		txMotivoReporte: ''
	},
	methods: {
		getComboPrioridad($this){
			CatalogoSia.cdCatalogo(14, data => {
				if(Mensaje.cargar(data, false)){
					$this.select.cdPrioridad.setCombo(data.body);
				}
			})
		},
		getComboDivisas($this){
			CatalogoSia.buscar('lstCatalogoDivisa', data => {
				if(Mensaje.cargar(data, false)){
					$this.select.cdDivisa.setCombo(data.body);
				}
			})
		},
		getComboBanxico($this){
			CatalogoSia.buscar('lstActividadBanxicoSia', data => {
				if(Mensaje.cargar(data, false)){
					$this.select.nbActividadBanxico.setCombo(data.body);
				}
			});
		},
		getComboNacionalidad($this){
			CatalogoSia.buscar('lstNacionalidad', data => {
				if(Mensaje.cargar(data, false)){
					$this.select.nbNacionalidad.setCombo(data.body);
				}
			});
		},
		getComboTpPersonaPLD($this){
			CatalogoSia.buscar('lstPersonasPLD', data => {
				if(Mensaje.cargar(data, false)){
					$this.select.tpPersona.setCombo(data.body);
				}
			});
		},
		getComboActividadNegocio($this){
			CatalogoSia.cdCatalogo(19, data => {
				if(Mensaje.cargar(data, false)){
					$this.select.nbActividadNegocio.setCombo(data.body);
				}
			});
		},
		getComboOrdenPago($this){
			CatalogoSia.cdCatalogo(17, data => {
				if(Mensaje.cargar(data, false)){
					$this.select.nbOrdenPago.setCombo(data.body);
				}
			});
		},
		getComboOperacionMonetaria($this){
			CatalogoSia.buscar('lstOperacionMonetaria', data => {
				if(Mensaje.cargar(data, false)){
					$this.select.tpOperacion.setCombo(data.body);
				}
			});
		},
		getComboInstrumentoMonetario($this){
			CatalogoSia.buscar('lstInstrumentoMonetario', data => {
				if(Mensaje.cargar(data, false)){
					$this.select.nbInstrumentoMonetario.setCombo(data.body);
				}
			});
		},
		getComboTipologias($this){
			CatalogoSia.cdCatalogo(24, data => {
				if(Mensaje.cargar(data, false)){
					$this.select.nbTipoligia.setCombo(data.body);
				}
			});
		},
		getComboOrigen($this){
			CatalogoSia.cdCatalogo(18, data => {
				if(Mensaje.cargar(data, false)){
					$this.select.nbOrigen.setCombo(data.body);
				}
			});
		},
		getComboDelito($this){
			CatalogoSia.buscar('lstDelito', data => {
				if(Mensaje.cargar(data, false)){
					$this.select.cdDelito.setCombo(data.body);
				}
			});
		},
		getDatosGenerales(){
			Ajax.get(`InformacionAdministrativaService/getDatosGenerales/${casoDTO.cdCasoSica}/${casoDTO.nuFolioAlerta}`, data => {
				if(Mensaje.cargar(data, false)){
					llenarFormulario('datosGenerales', data.body);
				}
			});
		},
		getOficinaGestoraReporta($this, tpOficina){
			Ajax.get(`InformacionAdministrativaService/getOficinaGestoraReporta/${casoDTO.cdCasoSica}/${tpOficina}`, data => {
				if(Mensaje.cargar(data, false)){
					if(tpOficina == 'G')
						llenarFormulario('oficinaGestiona', data.body);
					else
						llenarFormulario('oficinaReporta', data.body);
				}
			})
		},
		getDatosGeneralesByClienteReportado(){
			Ajax.get(`InformacionAdministrativaService/getDatosGenerales/clienteReportado/${casoDTO.cdCliente}/${casoDTO.cdCasoSica}`, data => {
				if(Mensaje.cargar(data, false)){
					llenarFormulario('clienteReportado', data.body);
				}
			})
		},
		getMotivoReporte(){
			Ajax.get(`InformacionAdministrativaService/getMotivoReporte/${casoDTO.cdCasoSica}`, data => {
				if(Mensaje.cargar(data, false)){
					txMotivoReporte = data.body;
				}
			});
		},
		getInformacionPLD($this){
			Ajax.get(`InformacionAdministrativaService/getInformacionPLD/${casoDTO.cdCaso}`, data => {
				if(Mensaje.cargar(data, false)){
					if(data.body != null){
						var dto = data.body;
						$this.form.informacionPLD.nbNacionalidad = dto.cdNacionalidad,
						$this.form.informacionPLD.tpPersona = dto.tpPersona,
						$this.form.informacionPLD.nbActividadNegocio = dto.cdActividad,
						$this.form.informacionPLD.nbOrdenPago = dto.cdOrdenPago,
						$this.form.informacionPLD.tpOperacion = dto.tpOperacion,
						$this.form.informacionPLD.nbInstrumentoMonetario = dto.cdInstrumento.trim(),
						$this.form.informacionPLD.nbTipoligia = dto.cdTipologia,
						$this.form.informacionPLD.nbOrigen = dto.cdOrigenAlerta,
						$this.form.informacionPLD.cdDelito = dto.cdDelito
					}
				}
			});
		},
		getComentariosGenerales(){
			Ajax.get(`InformacionAdministrativaService/getComentariosGenerales/${casoDTO.cdCaso}`, data => {
				if(Mensaje.cargar(data, false)){
					llenarFormulario('comentariosGenerales', data.body);
				}
			})
		}
	},
	select:{
		cdPrioridad:{
			value: 'cdDetCatalogo',
			text: 'nbRazon'
		},
		cdDivisa: {
			value: 'cdValor',
			text: 'nbValor'
		},
		nbActividadBanxico: {
			value: 'cdValor',
			text: 'nbValor'
		},
//		INFOMRACION PLD
		nbNacionalidad: {
			value: 'cdValor',
			text: 'nbValor'
		},
		tpPersona: {
			value: 'cdValor',
			text: 'nbValor'
		},
		nbActividadNegocio: {
			value: 'cdDetCatalogo',
			text: 'nbValor'
		},
		nbOrdenPago: {
			value: 'cdDetCatalogo',
			text: 'nbValor'
		},
		tpOperacion: {
			value: 'cdValor',
			text: 'nbValor'
		},
		nbInstrumentoMonetario:{
			value: 'cdValor',
			text: 'nbValor'
		},
		nbTipoligia:{
			value: 'cdDetCatalogo',
			text: 'nbValor'
		},
		nbOrigen:{
			value: 'cdDetCatalogo',
			text: 'nbValor'
		},
		cdDelito:{
			value: 'cdValor',
			text: 'nbValor',
			title: 'nbValor'
		}
	},
	ready($this){
		$this.methods.getComboPrioridad();
		$this.methods.getComboDivisas();
		$this.methods.getComboBanxico();
		$this.methods.getComboNacionalidad();
		$this.methods.getComboTpPersonaPLD();
		$this.methods.getComboActividadNegocio();
		$this.methods.getComboOrdenPago();
		$this.methods.getComboOperacionMonetaria();
		$this.methods.getComboInstrumentoMonetario();
		$this.methods.getComboTipologias();
		$this.methods.getComboOrigen();
		$this.methods.getComboDelito();
		
		$this.methods.getDatosGenerales();
		$this.methods.getOficinaGestoraReporta(TP_OFICINA_G);
		$this.methods.getOficinaGestoraReporta(TP_OFICINA_R);
		$this.methods.getDatosGeneralesByClienteReportado();
		$this.methods.getMotivoReporte();
		$this.methods.getInformacionPLD();
		$this.methods.getComentariosGenerales();
	}
});

var table = new Table({
	server:{
		productosClienteReportado: {
			option: {
				url: `${Session.get('baseUrl')}/InformacionAdministrativaService/lstOtrosProductosClienteReportado/${casoDTO.cdCasoSica}/${casoDTO.cdCliente}`,
				pageSize: 5,
				pageList: [5, 25, 50]
			}
		},
		cuentasClienteReportado: {
			option: {
				url: `${Session.get('baseUrl')}/InformacionAdministrativaService/lstOtrasCuentasClienteReportado/${casoDTO.cdCasoSica}/${casoDTO.cdCliente}`,
				pageSize: 5,
				pageList: [5, 25, 50]
			}
		}
	}
});