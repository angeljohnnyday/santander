package com.santander.app.back.srv;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.MecanicaOperacionalSiaDAO;
import com.santander.app.back.dao.MovimientosSiaDAO;
import com.santander.app.back.dto.MovimientosSiaDTO;
import com.santander.app.back.util.Response;
import com.santander.app.back.util.Pagination;

public class InformacionOperativaServiceImpl implements InformacionOperativaService {
	@Autowired MecanicaOperacionalSiaDAO mecanicaOperacionalSiaDAO;
	@Autowired private MovimientosSiaDAO movimientosSiaDAO;
	
	@Override
	public Response<Object> getCuadroConceptoTotal(BigDecimal cdCasoSica, String nuCuenta) {
		try {
			return new Response<>(mecanicaOperacionalSiaDAO.getCuadroConceptoTotal(cdCasoSica, nuCuenta), Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstMecanicaOperacional(BigDecimal cdCasoSica, String nuCuenta, Integer limit, Integer offset, String search, String name, String order) {
		try {
			Pagination pagination = new Pagination();
			pagination.setRows(mecanicaOperacionalSiaDAO.lstMecanicaOperacional(cdCasoSica, nuCuenta, limit, offset, search, name, order));
			pagination.setTotal(mecanicaOperacionalSiaDAO.totalLstMecanicaOperacional(cdCasoSica, nuCuenta));
			return new Response<>(pagination, Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstMovimientosSia(BigDecimal cdCasoSica, String nuCuenta, Integer limit, Integer offset, String search, String name, String order) {
		try {
			Pagination pagination = new Pagination();
			pagination.setRows(movimientosSiaDAO.lstMovimientosSia(cdCasoSica, nuCuenta, limit, offset, search, name, order));
			pagination.setTotal(movimientosSiaDAO.totalLstMovimientosSia(cdCasoSica, nuCuenta, search));
			return new Response<>(pagination, Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> getMontoTotales(BigDecimal cdCasoSica, String nuCuenta) {
		try {
			MovimientosSiaDTO montosTotalCargosDTO = null;
			MovimientosSiaDTO montosTotalAbonosDTO = null;
			MovimientosSiaDTO montosTotalDTO = new MovimientosSiaDTO();
			
			montosTotalCargosDTO = movimientosSiaDAO.getTotalCargosSia(cdCasoSica, nuCuenta);
			montosTotalDTO.setImCargosTotal(montosTotalCargosDTO.getImCargosTotal());
			montosTotalDTO.setNumCargosTotal(montosTotalCargosDTO.getNumCargosTotal());
			
			montosTotalAbonosDTO = movimientosSiaDAO.getTotalAbonosSia(cdCasoSica, nuCuenta);
			montosTotalDTO.setImAbonosTotal(montosTotalAbonosDTO.getImAbonosTotal());
			montosTotalDTO.setNumAbonosTotal(montosTotalAbonosDTO.getNumAbonosTotal());
			
			return new Response<>(montosTotalDTO, Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstMuestra(String tpMovimiento, BigDecimal cdCaso, BigDecimal cdCasoSia, String nuCuenta,
			Integer limit, Integer offset, String search, String name, String order) {
		try {
			Pagination pagination = new Pagination();
			pagination.setRows(movimientosSiaDAO.lstMovMuestra(tpMovimiento, cdCaso, cdCasoSia, nuCuenta, limit, offset, search, name, order));
			pagination.setTotal(movimientosSiaDAO.totalLstMovMuestra(tpMovimiento, cdCaso, cdCasoSia, nuCuenta));
			return new Response<>(pagination, Mensaje.getText("OK"), HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
