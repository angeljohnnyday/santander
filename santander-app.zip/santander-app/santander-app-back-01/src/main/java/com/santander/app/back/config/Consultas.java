package com.santander.app.back.config;

import java.util.Map;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@Configuration
public class Consultas {
	private final static String QUERY = "QUERY";
	private static ClassPathXmlApplicationContext queriesConsultas;
	private static ClassPathXmlApplicationContext queriesConsultasSia;
	private final static String nbConsultas = "Consultas.xml";
	private final static String nbConsultasSia = "ConsultasSia.xml";
	
	public Consultas() {
		queriesConsultas = new ClassPathXmlApplicationContext(nbConsultas);
		queriesConsultasSia = new ClassPathXmlApplicationContext(nbConsultasSia);
	}
	
	@SuppressWarnings("unchecked")
	public static String getConsulta(String nbConsulta) throws Exception {
      	Map<String, String> queryMap = null;
		String consulta = null;
		
		if(queriesConsultas == null) {
			queriesConsultas = new ClassPathXmlApplicationContext(nbConsultas);
		}
		
      	if (queriesConsultas != null && nbConsulta != null) {
      		queryMap = (Map<String, String>) queriesConsultas.getBean(nbConsulta);
      		consulta = queryMap.get(QUERY).trim();
      	}
      	
    	return consulta;
    }
	
	@SuppressWarnings("unchecked")
	public static String getConsultaSia(String nbConsulta) throws Exception {
      	Map<String, String> queryMap = null;
		String consulta = null;
		
		if(queriesConsultasSia == null) {
			queriesConsultasSia = new ClassPathXmlApplicationContext(nbConsultasSia);
		}
		
      	if (queriesConsultasSia != null && nbConsulta != null) {
      		queryMap = (Map<String, String>) queriesConsultasSia.getBean(nbConsulta);
      		consulta = queryMap.get(QUERY).trim();
      	}
      	
    	return consulta;
    }
}
