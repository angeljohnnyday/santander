package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.CatalogoSiaDTO;

@Component
public class CatalogoSiaDAO {
	@PersistenceContext private EntityManager em;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstSesion(String fhAnio) throws Exception{
		List<CatalogoSiaDTO> lstSesion = null;

		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstSesion"));
		query.setParameter("fhAnio", fhAnio);
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		lstSesion = (List<CatalogoSiaDTO>)query.getResultList();

		return lstSesion;
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstCatalogo(String cdCatalogo) throws Exception{
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstCatalogoByCdCatalogo"));
		query.setParameter("cdCatalogo", cdCatalogo);
		query.unwrap(NativeQuery.class)
		.addScalar("cdDetCatalogo", StringType.INSTANCE)
		.addScalar("cdCatalogo", StringType.INSTANCE)
		.addScalar("nbRazon", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.addScalar("cdDetCatPad", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>)query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstCatalogo(String cdCatalogo, String cdDetcatpad) throws Exception{
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstCatalogoByCdCatalogoCdDetcatpad"));
		query.setParameter("cdCatalogo", cdCatalogo);
		query.setParameter("cdDetcatpad", cdDetcatpad);
		query.unwrap(NativeQuery.class)
		.addScalar("cdDetCatalogo", StringType.INSTANCE)
		.addScalar("cdCatalogo", StringType.INSTANCE)
		.addScalar("nbRazon", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.addScalar("cdDetCatPad", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>)query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstCatalogoSistema() throws Exception{
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstCatalogoSistema"));
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>)query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstSesionActaByCdUsuarioNuAnio(BigDecimal cdUsuario, String fhAnio) throws Exception{
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstSesionActaByCdUsuarioNuAnio"));
		query.setParameter("cdUsuario", cdUsuario);
		query.setParameter("fhAnio", fhAnio);
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>)query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstCatalogoDivisa() throws Exception{
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstCatalogoDivisa"));
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>)query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstActividadBanxicoSia() throws Exception{
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstActividadBanxicoSia"));
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>)query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstCuentasRelacionadas(BigDecimal cdCasoSica) throws Exception{
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstCuentasRelacionadas"));
		query.setParameter("cdCasoSica", cdCasoSica);
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>)query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstNacionalidad() throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstNacionalidad"));
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>) query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstPersonasPLD() throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstPersonasPLD"));
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>) query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstOperacionMonetaria() throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstOperacionMonetaria"));
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>) query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstInstrumentoMonetario() throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstInstrumentoMonetario"));
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>) query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstDelito() throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstDelito"));
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>) query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<CatalogoSiaDTO> lstUsuarios(String cdPerfilA, String stSistema) throws Exception {
		Query query = em.createNativeQuery(Consultas.getConsultaSia("lstUsuariosByPerfilAndCdSistema"));
		query.setParameter("cdPerfilA", cdPerfilA);
		query.setParameter("stSistema", stSistema);
		query.unwrap(NativeQuery.class)
		.addScalar("cdValor", StringType.INSTANCE)
		.addScalar("nbValor", StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(CatalogoSiaDTO.class));

		return (List<CatalogoSiaDTO>) query.getResultList();
	}
}
