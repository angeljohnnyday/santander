package com.santander.app.back.srv;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.santander.app.back.config.Mensaje;
import com.santander.app.back.dao.CatalogoSiaDAO;
import com.santander.app.back.util.Response;

public class CatalogoSiaServiceImpl implements CatalogoSiaService {
	@Autowired private CatalogoSiaDAO catalogoSiaDAO;

	@Override
	public Response<Object> lstSesion(String fhAnio) {
		try {
			return new Response<>(catalogoSiaDAO.lstSesion(fhAnio), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstCatalogo(String cdCatalogo) {
		try {
			return new Response<>(catalogoSiaDAO.lstCatalogo(cdCatalogo), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstCatalogo(String cdCatalogo, String cdDetcatpad) {
		try {
			return new Response<>(catalogoSiaDAO.lstCatalogo(cdCatalogo, cdDetcatpad), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstCatalogoSistema() {
		try {
			return new Response<>(catalogoSiaDAO.lstCatalogoSistema(), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstSessionActa(BigDecimal cdUsuario, String fhAnio) {
		try {
			return new Response<>(catalogoSiaDAO.lstSesionActaByCdUsuarioNuAnio(cdUsuario, fhAnio), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstCatalogoDivisa() {
		try {
			return new Response<>(catalogoSiaDAO.lstCatalogoDivisa(), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstActividadBanxicoSia() {
		try {
			return new Response<>(catalogoSiaDAO.lstActividadBanxicoSia(), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstCuentasRelacionadas(BigDecimal cdCasoSica) {
		try {
			return new Response<>(catalogoSiaDAO.lstCuentasRelacionadas(cdCasoSica), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstNacionalidad() {
		try {
			return new Response<>(catalogoSiaDAO.lstNacionalidad(), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@Override
	public Response<Object> lstPersonasPLD() {
		try {
			return new Response<>(catalogoSiaDAO.lstPersonasPLD(), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstOperacionMonetaria() {
		try {
			return new Response<>(catalogoSiaDAO.lstOperacionMonetaria(), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstInstrumentoMonetario() {
		try {
			return new Response<>(catalogoSiaDAO.lstInstrumentoMonetario(), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstDelito() {
		try {
			return new Response<>(catalogoSiaDAO.lstDelito(), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public Response<Object> lstUsuarios(String cdPerfilA, String stSistema) {
		try {
			return new Response<>(catalogoSiaDAO.lstUsuarios(cdPerfilA, stSistema), Mensaje.getText("SUCCESS") ,HttpStatus.OK);
		} catch (Exception e) {
			return new Response<>(Mensaje.getText("ERROR"), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
