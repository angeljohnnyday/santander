package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.InformacionOficinaReportaGestionaDTO;

@Component
public class OficinaGestoraReportaDAO {
	@PersistenceContext private EntityManager em;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public InformacionOficinaReportaGestionaDTO getOficinaGestoraReporta(BigDecimal cdCaso, String tpOficina) throws Exception{
		InformacionOficinaReportaGestionaDTO informacionOficinaReportaGestionaDTO = new InformacionOficinaReportaGestionaDTO();
		List<InformacionOficinaReportaGestionaDTO> resultado = new ArrayList<InformacionOficinaReportaGestionaDTO>();
		 
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getOficinaGestoraReporta"));
		query.setParameter("cdCaso", cdCaso);
		query.setParameter("tpOficina", tpOficina);
		query.unwrap(NativeQuery.class)
		.addScalar("nuOficina",StringType.INSTANCE)
		.addScalar("nbOficina",StringType.INSTANCE)
		.addScalar("cdRiesgo",StringType.INSTANCE)
		.addScalar("nbMercado",StringType.INSTANCE)
		.addScalar("cdDivision",StringType.INSTANCE)
		.addScalar("nbFuncionario",StringType.INSTANCE)
		.addScalar("nbBanca",StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(InformacionOficinaReportaGestionaDTO.class));
		
		resultado = (List<InformacionOficinaReportaGestionaDTO>)query.getResultList();
		
		if( !resultado.isEmpty() ){
			informacionOficinaReportaGestionaDTO = resultado.get(0);	
		}
		
		return informacionOficinaReportaGestionaDTO;
	}
}
