package com.santander.app.back.dto;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class ConsensoSiaDTO {
	private BigDecimal cdConsenso;
	private BigDecimal cdCaso;
	private BigDecimal cdCasoSia;
	private String cdCliente;
	private String cdAlerta;
	private String cdSistema;
	private String nuCuenta;
	private String cdDesicionFinal;
	private String cdSesion;
	private BigDecimal nuFolioAlerta;
	private Date fhLibConsenso;
	private String stConsenso;
	private Date fhConsenso;
	private String nbOpinionInusual;
	private String nbOpinion;
	private String nbUsuario;
	private String nbGerencia;
	private String nbDivision;
	
	private String nbSegmentoCte;
	private String nbCliente;
	private String fhAntiguedad;
	private String tpPersona;
	private String cdTipologia;
	private String tpRiesgo;
	private String nbMulti;
	private String opiniones;
	private String acciones;
}
