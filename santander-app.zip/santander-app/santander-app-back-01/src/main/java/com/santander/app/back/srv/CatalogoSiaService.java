package com.santander.app.back.srv;

import java.math.BigDecimal;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.santander.app.back.util.Response;

@Path("/CatalogoSiaService")
public interface CatalogoSiaService {
	@GET
	@Path("/lstSesion/{fhAnio}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstSesion(
		@PathParam("fhAnio") String fhAnio
	);
	
	@GET
	@Path("/lstCatalogo/cdCatalogo/{cdCatalogo}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstCatalogo(
		@PathParam("cdCatalogo") String cdCatalogo
	);
	
	@GET
	@Path("/lstCatalogo/cdCatalogo/{cdCatalogo}/cdDetcatpad/{cdDetcatpad}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstCatalogo(
		@PathParam("cdCatalogo") String cdCatalogo,
		@PathParam("cdDetcatpad") String cdDetcatpad
	);
	
	@GET
	@Path("/lstCatalogoSistema")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstCatalogoSistema();
	
	@GET
	@Path("/lstSessionActa/cdUsuario/{cdUsuario}/fhAnio/{fhAnio}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstSessionActa(
		@PathParam("cdUsuario") BigDecimal cdUsuario,
		@PathParam("fhAnio") String fhAnio
	);
	
	@GET
	@Path("/lstCatalogoDivisa")
	@Produces(MediaType.APPLICATION_JSON)
	public Response<Object> lstCatalogoDivisa();
	
	@GET
	@Path("/lstActividadBanxicoSia")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstActividadBanxicoSia();
	
	@GET
	@Path("/lstCuentasRelacionadas/{cdCasoSica}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstCuentasRelacionadas(
		@PathParam("cdCasoSica") BigDecimal cdCasoSica
	);
	
	@GET
	@Path("/lstNacionalidad")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstNacionalidad();
	
	@GET
	@Path("/lstPersonasPLD")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstPersonasPLD();
	
	@GET
	@Path("/lstOperacionMonetaria")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstOperacionMonetaria();
	
	@GET
	@Path("/lstInstrumentoMonetario")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstInstrumentoMonetario();
	
	@GET
	@Path("/lstDelito")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstDelito();
	
	@GET
	@Path("/lstUsuarios/cdPerfilA/{cdPerfilA}/stSistema/{stSistema}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response<Object> lstUsuarios(
		@PathParam("cdPerfilA") String cdPerfilA,
		@PathParam("stSistema") String stSistema
	);
}
