const casoDTO = Session.get('casoDTO');
const PERFIL_COORDINADO = '5';

$(function(){
	
	$(".empleado").css('display', Session.perfil() == PERFIL_COORDINADO ? 'inline-block' : 'none');
	
	Ajax.get(`ConsultaCasosSiaService/getVistaRapida/${casoDTO.cdCasoSica}/${casoDTO.cdSistema}/${casoDTO.nuFolioAlerta}/${casoDTO.nuCuenta}/0`).done(function(data){
		if(Mensaje.cargar(data, false)){
			llenarFormulario('formVistaRapida', data.body);
		}
	});
});