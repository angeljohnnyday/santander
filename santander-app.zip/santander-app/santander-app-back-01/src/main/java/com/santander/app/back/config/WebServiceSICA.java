package com.santander.app.back.config;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.springframework.context.annotation.Configuration;

import com.santander.app.back.srv.PerfiladoServiceImpl;

@Configuration
@ApplicationPath("/services/rest")
public class WebServiceSICA extends Application {
	@Override
    public Set<Object> getSingletons() {
        final Set<Object> singletons = new HashSet<>();
        singletons.add(new PerfiladoServiceImpl());
        return singletons;
    }
}
