package com.santander.app.back.repo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.santander.app.back.dominio.Tsca301Delito;

@Repository
public interface Tsca301Repo extends JpaRepository<Tsca301Delito, BigDecimal> {

}
