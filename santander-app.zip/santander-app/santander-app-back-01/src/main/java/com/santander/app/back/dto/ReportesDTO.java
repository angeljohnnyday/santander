package com.santander.app.back.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ReportesDTO {
	private String nbReporte;
	private String nbTipo;
	private String nbUsuario;
	private BigDecimal cdUsuario;
	private BigDecimal cdReporte;
	private BigDecimal cdTipoReporte;
	private BigDecimal tpReporte;
}
