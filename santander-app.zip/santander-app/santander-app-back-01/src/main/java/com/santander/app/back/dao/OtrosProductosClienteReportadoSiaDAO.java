package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.santander.app.back.dto.OtrosProductosClienteReportadoTarCreDTO;
import com.santander.app.back.util.Money;

import oracle.jdbc.OracleTypes;

@Component
public class OtrosProductosClienteReportadoSiaDAO {
	@PersistenceContext EntityManager em;
	@Autowired JdbcTemplate jdbcTemplate;
	
	@Transactional
	public List<OtrosProductosClienteReportadoTarCreDTO> lstOtrosProductosClienteReportado(BigDecimal cdCaso, String cdCliente) throws Exception {
		List<OtrosProductosClienteReportadoTarCreDTO> lstOtrosProductosClienteReportado = new ArrayList<OtrosProductosClienteReportadoTarCreDTO>();
		
		Connection con = jdbcTemplate.getDataSource().getConnection();
		CallableStatement cstmt = con.prepareCall("{ CALL PG_MANTENIMIENTO.SP_CON_PROD(?,?,?,?,?) }");
		cstmt.setQueryTimeout(1800);
		cstmt.setBigDecimal(1, cdCaso);
		cstmt.setString(2, cdCliente);
		cstmt.registerOutParameter(3, OracleTypes.CURSOR);
		cstmt.registerOutParameter(4, OracleTypes.NUMBER);
		cstmt.registerOutParameter(5, OracleTypes.VARCHAR);
		cstmt.execute();
		
		ResultSet rset = (ResultSet)cstmt.getObject(3);
		BigDecimal variableSalida = (BigDecimal) cstmt.getObject(4);
		
		if ( !variableSalida.equals( new BigDecimal(-2) ) && !variableSalida.equals( new BigDecimal(-1) ) ) {
			while (rset.next()){
				OtrosProductosClienteReportadoTarCreDTO otrosProductosClienteReportadoTarCreDTO = new OtrosProductosClienteReportadoTarCreDTO();
					
				otrosProductosClienteReportadoTarCreDTO.setFhAperturaOPCR( rset.getString("fh_apertura") != null ?  rset.getString("fh_apertura") : "");
				otrosProductosClienteReportadoTarCreDTO.setNuCuentaOPCR( rset.getString("nu_cuenta_par") != null ?  rset.getString("nu_cuenta_par") : "");				
				
				String sCdProducto = rset.getString("cd_producto") != null ? rset.getString("cd_producto"): ""; 
				String sCdNbProducto = rset.getString("nb_producto") != null ? rset.getString("nb_producto"): "";				
				String sNbProductoOPCR = "";
				if (!sCdProducto.isEmpty() && !sCdNbProducto.isEmpty()) {
					sNbProductoOPCR = sCdProducto + " - " + sCdNbProducto;
				}
				else if (sCdProducto.isEmpty() || sCdNbProducto.isEmpty()) {
					sNbProductoOPCR = !sCdProducto.isEmpty() ? sCdProducto : sCdNbProducto ;
				}
				
				otrosProductosClienteReportadoTarCreDTO.setNbProductoOPCR(sNbProductoOPCR);
				
				String sCdSubProducto = rset.getString("cd_subproducto") != null ? rset.getString("cd_subproducto"): ""; 
				String sNbSubProducto = rset.getString("nb_subproducto") != null ? rset.getString("nb_subproducto"): "";            
				String sNbSubproductoOPCR = "";
				if (!sCdSubProducto.isEmpty() && !sNbSubProducto.isEmpty()) {
					sNbSubproductoOPCR = sCdSubProducto + " - " + sNbSubProducto;
				}
				else if (sCdSubProducto.isEmpty() || sNbSubProducto.isEmpty()) {
					sNbSubproductoOPCR = !sCdSubProducto.isEmpty() ? sCdSubProducto : sNbSubProducto ;
				}            
				
				otrosProductosClienteReportadoTarCreDTO.setNbSubproductoOPCR(sNbSubproductoOPCR);
				otrosProductosClienteReportadoTarCreDTO.setNbEstatusOPCR( rset.getString("st_cta") != null ?  rset.getString("st_cta") : "");
				otrosProductosClienteReportadoTarCreDTO.setNuCtePartOPCR(  rset.getString("cd_cliente_par") != null ?  rset.getString("cd_cliente_par") : "" );
				otrosProductosClienteReportadoTarCreDTO.setNbDetParticipesOPCR(rset.getString("clte_participe")!= null ?  rset.getString("clte_participe") : "");
				otrosProductosClienteReportadoTarCreDTO.setCdSec( rset.getString("sec")!= null ?  rset.getString("sec") : "" );
				
				String imSaldo = rset.getString("im_saldo") != null ?  rset.getString("im_saldo") : "";
			
				if(!imSaldo.equals("")){
					imSaldo = Money.getMoney(imSaldo);	
				}
		
				String fhSaldo = rset.getString("fh_saldo") != null ? rset.getString("fh_saldo") : "";
				String sImProductoOPCR = "";
				
				if (!imSaldo.isEmpty() && !fhSaldo.isEmpty()) {
					sImProductoOPCR = imSaldo + " al " + fhSaldo;
				}
				else if (imSaldo.isEmpty() || fhSaldo.isEmpty()) {
					sImProductoOPCR = !imSaldo.isEmpty() ? imSaldo : fhSaldo;
				}
							
				otrosProductosClienteReportadoTarCreDTO.setImProductoOPCR( sImProductoOPCR );
				otrosProductosClienteReportadoTarCreDTO.setImProPromOPCR( rset.getBigDecimal("im_promedio") != null ?  rset.getBigDecimal("im_promedio") : BigDecimal.ZERO);
				otrosProductosClienteReportadoTarCreDTO.setNbComentariosOPCR( rset.getString("nb_comentario")!= null ?  rset.getString("nb_comentario") : "");				
				
				String sCdIntervencion = rset.getString("cd_intervencion") != null ?  rset.getString("cd_intervencion") : "";
				String sNuSecuencia = rset.getString("nu_secuencia") != null ?  rset.getString("nu_secuencia") : "";
				String sTitular = rset.getString("titular") != null ?  rset.getString("titular") : "";
				String sNbTitularOPCR = "";
				String sCdIntervencionNuSecuencia = sCdIntervencion+sNuSecuencia;
				
				if (!sCdIntervencionNuSecuencia.isEmpty() && !sTitular.isEmpty()) {
					sNbTitularOPCR = sCdIntervencionNuSecuencia + " - " + sTitular;
				}
				else if (sCdIntervencionNuSecuencia.isEmpty() || sNuSecuencia.isEmpty()) {
					sNbTitularOPCR = !sCdIntervencionNuSecuencia.isEmpty() ? sCdIntervencionNuSecuencia : sTitular ;
				}
				
				otrosProductosClienteReportadoTarCreDTO.setNbTitularOPCR( sNbTitularOPCR );
				otrosProductosClienteReportadoTarCreDTO.setNbBancaOPCR( rset.getString("nb_Banca") != null ?  rset.getString("nb_Banca") : "");
				otrosProductosClienteReportadoTarCreDTO.setNbParticipesOPCR( rset.getString("cd_rel_ctecta")  != null ?  rset.getString("cd_rel_ctecta") : "");
			 	otrosProductosClienteReportadoTarCreDTO.setTpCargaOPCR( rset.getString("tp_carga")  != null ?  rset.getString("tp_carga") : "");
				
			 	if (rset.getString("tp_carga") != null && !rset.getString("tp_carga").equals("")) {
			 		if (rset.getString("tp_carga").equals("M")) {
			 			otrosProductosClienteReportadoTarCreDTO.setTpCargaOPCR("MANUAL");
			 		}
			 		else {
			 			otrosProductosClienteReportadoTarCreDTO.setTpCargaOPCR("AUTOMATICA");
			 		}
			 	}
				
			 	lstOtrosProductosClienteReportado.add(otrosProductosClienteReportadoTarCreDTO);
			}
		}
		
		rset.close();
		cstmt.close();
		con.close();
		
		return lstOtrosProductosClienteReportado;
	}
}
