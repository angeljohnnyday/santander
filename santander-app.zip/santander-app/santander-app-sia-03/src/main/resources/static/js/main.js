$(function(){
	new DatePicker({
		data:['datePicker']
	});
	
	new Money({
		data:['maskMoney', {
			name: 'maskNumber',
			option: {precision: 0}
		}]
	});
});

$(document).on('click', '[data-page]', event => {
	var $el = event.target;
	Screen.page($el);
})

$(document).on({
	ajaxStart(){
		$("body").addClass("loading");
	},
	ajaxStop(event, request, settings){
		$("body").removeClass("loading");
	},
	ajaxError(event, jqxhr, settings, thrownError){
		Mensaje.cargar({
			message: 'Estimado usuario, ocurrió un error en el sistema por favor intente mas tarde.',
			statusCodeValue: 500,
			errorException: null
		});
	}
});

document.addEventListener('readystatechange', (event) => {
	if(document.readyState === 'complete')  {
		var body = document.querySelector('body');
		body.style.visibility = 'visible';
	}
});

document.addEventListener("DOMContentLoaded", () => {
//	VALIDATE LOGIN
	frame.validateSession();
	frame.configMenu();
	frame.panel();
});

const frame = {
	validateSession(){
		var usuarioDTO = Session.getUser();
		if(usuarioDTO == null){
			Screen.login();
		}
	},
	validatePage(){
		var lstElement = document.querySelectorAll('#nav-menu #navbar-content a.d-none');
	    for(menu of lstElement){
	    	 var pathname = menu.getAttribute('href');
	         if(new RegExp(pathname, 'g').test(window.location.href)){
	         	Screen.login();
	         }
	    }
	},
	configMenu(){
		var lstElement = document.querySelectorAll('*[data-menu]');
		lstElement.forEach(el => {
			var name = el.dataset.menu;
			var length = Session.lstModulos().filter(moduloDTO => moduloDTO.nbModulo == name).length;
			if(length == 0){
				el.style.display = 'none';
			}
		});
		
		var btnPerfil = document.querySelector('button[data-st-perfil]');
		if(btnPerfil != null){
			btnPerfil.style = Session.getUser().cdPerfil2 == null ? 'd-none' : '';
			
			var userInfo = document.querySelector('div[data-user-info]');
			var usuarioDTO = Session.getUser();
			var nbUsuario = (`${usuarioDTO.nbPersona} ${usuarioDTO.nbPaterno} ${usuarioDTO.nbMaterno != null ? usuarioDTO.nbMaterno : ''}`).trim();
			userInfo.innerHTML = `${usuarioDTO.nbCveRed} - ${nbUsuario} - ${usuarioDTO.nbPerfil1}`;
		}
		
	},
	panel(){
		var $el = document.querySelector('[data-page-init]');
		if($el != null) Screen.page($el);
	}
}