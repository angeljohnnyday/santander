package com.santander.app.back.dto;

import lombok.Data;

@Data
public class InformacionOficinaReportaGestionaDTO {
	private String nuOficina;
	private String nbOficina;
	private String cdRiesgo;
	private String nbMercado;
	private String cdDivision;
	private String nbFuncionario;
	private String nbBanca;
}
