var casoDTO = Session.get('casoDTO');
const PERFIL_COORDINADO = '5';
$(function(){
	formVistaRapida.readonlyAll();
	getVistaRapida();
})

function getVistaRapida(){
	Ajax.get(`ConsultaCasosSiaService/getVistaRapida/${casoDTO.cdCasoSica}/${casoDTO.cdSistema}/${casoDTO.nuFolioAlerta}/${casoDTO.nuCuenta}/0`).done(function(data){
		if(Ajax.statusOK(data, false)){
			formVistaRapida.setData(data.body);
		}
	});
}