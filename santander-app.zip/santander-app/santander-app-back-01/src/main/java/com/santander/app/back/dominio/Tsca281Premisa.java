package com.santander.app.back.dominio;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@Table(name =  "TSCA281_PREMISA", schema = "GORAPR")
public class Tsca281Premisa {
	@Id
	@NotNull
	@SequenceGenerator(name = "SQ_TSCA281", sequenceName = "SQ_TSCA281", schema = "GORAPR", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_TSCA281")
	@Column(name = "CD_PREMISA")
	private BigDecimal cdPremisa;

	@Column(name = "NB_NOMBRE")
	@NotNull
	private String nbNombre;

	@Column(name = "NB_DESCRIPCION")
	private String nbDescripcion;

	@Column(name = "TX_QUERY")
	@NotNull
	private String txQuery;

	@Column(name = "FH_ALTA")
	private Date fhAlta;

	@Column(name = "FH_MODIF")
	private Date fhModif;

	@Column(name = "ST_ACTIVO")
	private String stActivo;
	
	@Column(name = "TX_QUERY_EXT")
	private String txQueryExt;
	
	@Column(name = "ST_VERSE")
	private String stVerse;
	
	@Column(name = "CD_SEGMENTO")
	private String cdSegmento;
	
	@Column(name = "NU_DIAS_CLIENTE")
	private BigDecimal nuDiasCte;
	
	@Column(name = "NU_DIAS_CUENTA")
	private BigDecimal nuDiasCta;
	
	@Column(name = "NB_CONTEXTO")
	private String nbContexto;
	
	@Column(name = "NB_OFICIAL_PLD")
	private String nbOficialPld;
	
	@Column(name = "NB_BANCA")
	private String nbBanca;
	
	@Column(name = "NB_JURIDICO")
	private String nbJuridico;
	
	@Column(name = "ST_OPINION")
	private String stOpinion;
	
	@Column(name = "CD_DECISION_FINAL")
	private String cdDecisionFinal;
	
	@Column(name = "ST_COMPARTIDO")
	private String stCompartido;
}
