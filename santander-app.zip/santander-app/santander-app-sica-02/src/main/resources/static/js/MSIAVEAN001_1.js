var TP_OFICINA_G = "G";
var TP_OFICINA_R = "R";

$(function(){
	getDatosGenerales();
	getOficinaGestoraReporta(TP_OFICINA_G);
	getOficinaGestoraReporta(TP_OFICINA_R);
	getDatosGeneralesByClienteReportado();
	lstOtrosProductosClienteReportado();
	lstOtrasCuentasClienteReportado();
	getMotivoReporte();
	getComentariosGenerales();
	getInformacionPLD();

	getComboFormDatosGenerales();
	getComboFormClienteReportado();
	getComboNacionalidad();
	getComboTpPersonaPLD();
	getComboActividadNegocio();
	getComboOrdenPago();
	getComboOperacionMonetaria();
	getComboInstrumentoMonetario();
	getComboTipologias();
	getComboOrigen();
	getComboDelito();
});

function getComboFormDatosGenerales(){
	CatalogoSia.cdCatalogo(14, formDatosGenerales.cdPrioridad);
	CatalogoSia.buscar('lstCatalogoDivisa', formDatosGenerales.cdDivisa, {
		value: 'cdValor',
		text: 'nbValor',
	});
}

function getComboFormClienteReportado(){
	CatalogoSia.buscar('lstActividadBanxicoSia', formClienteReportado.nbActividadBanxico, {
		value: 'cdValor',
		text: 'nbValor',
	});
}

function getDatosGenerales() {
	Ajax.get(`InformacionAdministrativaService/getDatosGenerales/${casoDTO.cdCasoSica}/${casoDTO.nuFolioAlerta}`).done(function(data){
		if(Ajax.statusOK(data, false)){
			formDatosGenerales.setData(data.body);
		}
	})
};

function getOficinaGestoraReporta(tpOficina){
	Ajax.get(`InformacionAdministrativaService/getOficinaGestoraReporta/${casoDTO.cdCasoSica}/${tpOficina}`).done(function(data){
		if(Ajax.statusOK(data, false)){
			if(tpOficina == 'G')
				formOficinaGestiona.setData(data.body);
			else
				formOficinaReporta.setData(data.body)
		}
	});
}

function lstOtrosProductosClienteReportado(){
	tableOtrosProductos.setUrl(`InformacionAdministrativaService/lstOtrosProductosClienteReportado/${casoDTO.cdCasoSica}/${casoDTO.cdCliente}`);
	tableOtrosProductos.setTable({
		pageSize: 5,
		pageList: [5, 25, 50]
	});
}

function lstOtrasCuentasClienteReportado(){
	tableOtrasCuentas.setUrl(`InformacionAdministrativaService/lstOtrasCuentasClienteReportado/${casoDTO.cdCasoSica}/${casoDTO.cdCliente}`);
	tableOtrasCuentas.setTable({
		pageSize: 5,
		pageList: [5, 25, 50]
	});
}

function getDatosGeneralesByClienteReportado(){
	Ajax.get(`InformacionAdministrativaService/getDatosGenerales/clienteReportado/${casoDTO.cdCliente}/${casoDTO.cdCasoSica}`).done(function(data){
		if(Ajax.statusOK(data, false)){
			formClienteReportado.setData(data.body);
		}
	});
}

function getComentariosGenerales(){
	Ajax.get(`InformacionAdministrativaService/getComentariosGenerales/${casoDTO.cdCaso}`).done(function(data){
		if(Ajax.statusOK(data, false)){
			formComentariosGenerales.setData(data.body);
		}
	})
}

function getMotivoReporte(){
	Ajax.get(`InformacionAdministrativaService/getMotivoReporte/${casoDTO.cdCasoSica}`).done(function(data){
		if(Ajax.statusOK(data, false)){
			txMotivoReporte.val(data.body);
		}
	})
}

function getComboNacionalidad(){
	CatalogoSia.buscar('lstNacionalidad', formInformacionPLD.nbNacionalidad, {
		value: 'cdValor',
		text: 'nbValor',
	});
}

function getComboTpPersonaPLD(){
	CatalogoSia.buscar('lstPersonasPLD', formInformacionPLD.tpPersona, {
		value: 'cdValor',
		text: 'nbValor',
	});
}

function getComboActividadNegocio(){
	CatalogoSia.cdCatalogo(19, formInformacionPLD.nbActividadNegocio);
}

function getComboOrdenPago(){
	CatalogoSia.cdCatalogo(17, formInformacionPLD.nbOrdenPago);
}

function getComboOperacionMonetaria(){
	CatalogoSia.buscar('lstOperacionMonetaria', formInformacionPLD.tpOperacion, {
		value: 'cdValor',
		text: 'nbValor',
	});
}

function getComboInstrumentoMonetario(){
	CatalogoSia.buscar('lstInstrumentoMonetario', formInformacionPLD.nbInstrumentoMonetario, {
		value: 'cdValor',
		text: 'nbValor',
	});
}

function getComboTipologias(){
	CatalogoSia.cdCatalogo(24, formInformacionPLD.nbTipoligia);
}

function getComboOrigen(){
	CatalogoSia.cdCatalogo(18, formInformacionPLD.nbOrigen);
}

function getComboDelito(){
	CatalogoSia.buscar('lstDelito', formInformacionPLD.cdDelito, {
		value: 'cdValor',
		text: 'nbValor',
		title: 'nbValor'
	});
}

function getInformacionPLD(){
	Ajax.get(`InformacionAdministrativaService/getInformacionPLD/${casoDTO.cdCaso}`).done(function(data){
		if(Ajax.statusOK(data, false)){
			if(data.body != null){
				formInformacionPLD.setData({
					nbNacionalidad: data.body.cdNacionalidad,
					tpPersona: data.body.tpPersona,
					nbActividadNegocio: data.body.cdActividad,
					nbOrdenPago: data.body.cdOrdenPago,
					tpOperacion: data.body.tpOperacion,
					nbInstrumentoMonetario: data.body.cdInstrumento.trim(),
					nbTipoligia: data.body.cdTipologia,
					nbOrigen: data.body.cdOrigenAlerta,
					cdDelito: data.body.cdDelito
				});
			}
		}
	})
}