package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.CuadrosTextoAnalisisDTO;

@Component
public class CuadrosTextoAnalisisDAO {
	@PersistenceContext private EntityManager em;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public CuadrosTextoAnalisisDTO getCuadrosTexto(BigDecimal cdCasoSia) throws Exception{
		CuadrosTextoAnalisisDTO cuadrosTextoAnalisisDTO = new CuadrosTextoAnalisisDTO();
		List<CuadrosTextoAnalisisDTO> resultado = null;
		
		Query query = em.createNativeQuery(Consultas.getConsultaSia("getCuadrosTexto"));
		query.setParameter("cdCasoSia", cdCasoSia);

		query.unwrap(NativeQuery.class)
		.addScalar("nbDescripcionOperacion")
		.addScalar("nbRazonesInusual")
		.addScalar("nbComentariosGenerales217")
		.setResultTransformer(Transformers.aliasToBean(CuadrosTextoAnalisisDTO.class));
		
		resultado = (List<CuadrosTextoAnalisisDTO>)query.getResultList();
		 
		if ( !resultado.isEmpty()){
			cuadrosTextoAnalisisDTO = resultado.get(0);
		}
		
		return cuadrosTextoAnalisisDTO;
	}
}
