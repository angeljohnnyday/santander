var actionEvents = {
	'click .editReporte' : function(e, value, row, index) {
		modalReportes(row.tpReporte);

		nbReporte.val(row.nbReporte);
		tpReporte.val(row.tpReporte);
		
		Ajax.get(`ReportesService/getDetalleReporteNoAsignado/cdReporte/${row.cdReporte}/tpReporte/${row.tpReporte}`).done(function(data){
			if(Ajax.statusOK(data, false)){
				campoReporte.pushCombo({
					data: data.body,
					value: 'cdColumna',
					text: 'nbColumna',
				});
			}
		})
		
		Ajax.get(`ReportesService/getDetalleReporteAsignado/cdReporte/${row.cdReporte}/tpReporte/${row.tpReporte}`).done(function(data){
			if(Ajax.statusOK(data, false)){
				campoReporteSelected.pushCombo({
					data: data.body,
					value: 'cdColumna',
					text: 'nbColumna',
				});
			}
		});
	},
	'click .deleteReporte' : function(e, value, row, index) {
		Alert.confirm(`¿Eliminar reporte: ${row.nbReporte}?`, function(){
			
		})
	}
}

$(function(){
	tableReportes.setTable({
		url: `${Session.get('baseUrl')}/ReportesService/lstReportesTable`
	});
	
	tpReporte.change(function(){
		campoReporte.setComboServer(`ReportesService/lstDetalleTpReporte/${tpReporte.val() == null ? '-1' : tpReporte.val()}`, {
			value: 'cdValor',
			text: 'nbValor'
		});
		
		campoReporteSelected.removeAllOption();
	});
});

function formatterReportes(value, row, index){
	return [
		'<a href="javascript:void(0)" class="editReporte"><i class="fas fa-pen text-info"></i></a>',
		'<a href="javascript:void(0)" class="deleteReporte"><i class="far fa-window-close text-danger"></i></a>'
	].join('');
}

function lstTpReporte(){
	tpReporte.val(null);
	tpReporte.setComboServer(`ReportesService/lstTpReporte`, {
		value: 'cdValor',
		text: 'nbValor'
	})
}

function moveDetalleReporte(){
	var data = campoReporte.getSelectedOption();
	if(data.length != 0){
		campoReporteSelected.pushCombo({
			data: data,
			value: 'value',
			text: 'text',
		})
	}
	campoReporte.removeSelectedOption();
}

function moveAllDetalleReporte(){
	var data = campoReporte.getAllOption();
	if(data.length != 0){
		campoReporteSelected.pushCombo({
			data: data,
			value: 'value',
			text: 'text',
		})
	}
	campoReporte.removeAllOption();
}

function returnDetalleReporte(){
	var data = campoReporteSelected.getSelectedOption();
	if(data.length != 0){
		campoReporte.pushCombo({
			data: data,
			value: 'value',
			text: 'text',
		})
	}
	campoReporteSelected.removeSelectedOption();
}

function returnAllDetalleReporte(){
	var data = campoReporteSelected.getAllOption();
	if(data.length != 0){
		campoReporte.pushCombo({
			data: data,
			value: 'value',
			text: 'text',
		})
	}
	campoReporteSelected.removeAllOption();
}

function modalReportes(){
	nbReporte.val(null);
	lstTpReporte();
	campoReporte.removeAllOption();
	campoReporteSelected.removeAllOption();
	$("#modalReporte").modal();
}