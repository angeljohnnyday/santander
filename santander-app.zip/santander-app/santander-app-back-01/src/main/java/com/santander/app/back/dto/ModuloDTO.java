package com.santander.app.back.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModuloDTO {
	private String cdModulo;
	private String nbModulo;
	private String txModulo;
}
