package com.santander.app.back.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.ConsensoSiaDTO;
import com.santander.app.back.util.QueryUtil;

@Component
public class ConsensoSiaDAO {
	@PersistenceContext private EntityManager em;
	@Autowired private QueryUtil queryUtil;
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<ConsensoSiaDTO> lstArmadoConsenso(String cdSesion, String nuCasos, Integer limit, Integer offset, String search, String name, String order) throws Exception {
		List<ConsensoSiaDTO> lstArmadoConsenso = new ArrayList<ConsensoSiaDTO>();
		
		String consulta = Consultas.getConsultaSia("lstArmadoConsenso");
		consulta = this.armadoConsensoCond(consulta, cdSesion, nuCasos);
		
		consulta += queryUtil.orderBy(name, "cdCasoSia", order, "ASC");
		
		Query query = em.createNativeQuery(consulta);
		query.unwrap(NativeQuery.class)
		.addScalar("cdCaso")
		.addScalar("cdCasoSia")
		.addScalar("cdCliente")
		.addScalar("cdAlerta", StringType.INSTANCE)
		.addScalar("cdSistema",StringType.INSTANCE)
		.addScalar("nuCuenta", StringType.INSTANCE)
		.addScalar("cdDesicionFinal",StringType.INSTANCE)
		.addScalar("cdSesion", StringType.INSTANCE)
		.addScalar("nuFolioAlerta", BigDecimalType.INSTANCE)
		 .setResultTransformer(Transformers.aliasToBean(ConsensoSiaDTO.class));
		query = queryUtil.maxSize(query, offset, limit);
		
		lstArmadoConsenso = (List<ConsensoSiaDTO>) query.getResultList();
		
		return lstArmadoConsenso;
	}
	
	public int lstArmadoConsensoCount(String cdSesion, String nuCasos) throws Exception {
		String consulta = Consultas.getConsultaSia("lstArmadoConsenso");
		consulta = this.armadoConsensoCond(consulta, cdSesion, nuCasos);
		return queryUtil.Count(em, consulta);
	}
	
	private String armadoConsensoCond(String consulta, String cdSesion, String nuCasos) {
		boolean condicion = false;
		
		if (queryUtil.value(cdSesion)) {
			condicion = true;
			consulta += " WHERE cdSesion = '"+  cdSesion +"'";
		}
		 
		if(queryUtil.value(nuCasos)){
			consulta += queryUtil.Where(condicion) + "cdCasoSia IN ("+ nuCasos +")";
		}
		
		return consulta;
	}
}
