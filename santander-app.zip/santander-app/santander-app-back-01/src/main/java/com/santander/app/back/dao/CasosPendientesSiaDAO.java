package com.santander.app.back.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.logging.log4j.util.Strings;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.santander.app.back.config.Consultas;
import com.santander.app.back.dto.CasosPendientesSiaDTO;
import com.santander.app.back.util.QueryUtil;
import com.santander.app.back.util.Util;

@Component
public class CasosPendientesSiaDAO {
	@PersistenceContext private EntityManager em;
	@Autowired QueryUtil queryUtil;
	
	@SuppressWarnings({"unchecked", "deprecation" })
	public List<CasosPendientesSiaDTO> lstCasos(BigDecimal cdUsuario, Integer limit, Integer offset, String name, String order, String q) throws Exception {
		
		String consulta = Consultas.getConsultaSia("lstCasosByCdUsuario");
		consulta = this.configConsultaCasosPendientes(consulta, q);
		
		consulta += queryUtil.orderBy(name, "cdCaso", order, "ASC");
		
		Query query = em.createNativeQuery(consulta);
		query.setParameter("cdUsuario", cdUsuario);
		
		query.unwrap(NativeQuery.class)
		.addScalar("cdCaso")
		.addScalar("cdCasoSica", StringType.INSTANCE)
		.addScalar("nuFolioAlerta")
		.addScalar("nuActa")
		.addScalar("nbActa")
		.addScalar("fhAlerta", TimestampType.INSTANCE)
		.addScalar("cdSistema")
		.addScalar("nbSistema")
		.addScalar("cdCliente")
        .addScalar("nbCliente")
        .addScalar("nuCuenta")
        .addScalar("cdEstatus")
        .addScalar("nbConsultor")
        .addScalar("nbPrioridad")
        .addScalar("tpAsignacion")
        .addScalar("fhAsignacion", TimestampType.INSTANCE)
        .addScalar("tpCaso")
        .addScalar("nuDiasReportar", StringType.INSTANCE)
        .addScalar("cdStCaso")
        .addScalar("stActualizar")
		.setResultTransformer(Transformers.aliasToBean(CasosPendientesSiaDTO.class));
		
//		query.setFirstResult(offset);
//		query.setMaxResults(limit);

		return (List<CasosPendientesSiaDTO>)query.getResultList();
	}
	
	public int totalLstCasos(BigDecimal cdUsuario, String q) throws Exception {
		String consulta = "SELECT COUNT (1) FROM (" + Consultas.getConsultaSia("lstCasosByCdUsuario") + ")";
		
		consulta = this.configConsultaCasosPendientes(consulta, q);
		
		Query query = em.createNativeQuery(consulta);
		query.setParameter("cdUsuario", cdUsuario);
		
		return ((Number) query.getSingleResult()).intValue();
	}
	
	private String configConsultaCasosPendientes(String consulta, String q) {
		boolean stParam = false;
		CasosPendientesSiaDTO paramDTO = null;
		
		if( q != null && !Strings.isEmpty(q)) {
			paramDTO = (CasosPendientesSiaDTO) Util.getDTO(new CasosPendientesSiaDTO(), q);
			
			if(paramDTO != null) {
				stParam = true;
			}
		}
		
		if(stParam) {
			boolean isFiltro = false;
			
			if(paramDTO.getCdCaso() != null){
				consulta += "WHERE cdCaso IN( "+paramDTO.getCdCaso()+ " )" ;
				isFiltro = true;
			} 
			
			if(paramDTO.getCdPrioridad() != null){
				consulta +=  queryUtil.Where(isFiltro) + "cdPrioridad = '"+paramDTO.getCdPrioridad()+"' ";
				isFiltro = true;  
			}
			
			if(paramDTO.getCdSistema() != null){
				consulta += queryUtil.Where(isFiltro) + "cdSistema = '"+paramDTO.getCdSistema()+"' ";
				isFiltro = true;
			}
			
			if(paramDTO.getNuCuenta() != null){
				consulta += queryUtil.Where(isFiltro) + "(SUBSTR(nuCuenta,11,20) = '"+ paramDTO.getNuCuenta()+"' " + " OR nuCuenta = '" + paramDTO.getNuCuenta() +"' )";
				isFiltro = true;		 
			}
			
			if(paramDTO.getCdCliente() != null){
				consulta += queryUtil.Where(isFiltro) + "cdCliente = '"+paramDTO.getCdCliente().toUpperCase()+"' ";
				isFiltro = true;
			}
			 
			if(paramDTO.getNuActa() != null){
				consulta += queryUtil.Where(isFiltro) + "nbActa = '"+paramDTO.getNuActa().toUpperCase()+"' ";
				isFiltro = true;
			 }
			 
			if(paramDTO.getNbCliente() != null){
				consulta += queryUtil.Where(isFiltro) + "nbCliente LIKE '%"+ paramDTO.getNbCliente().toUpperCase()+"%' ";
				isFiltro = true;
			}
			 
			if(paramDTO.getFhReporteDel()!= null || paramDTO.getFhReporteAl()!= null){
				if(paramDTO.getFhReporteDel() != null && paramDTO.getFhReporteAl() != null){
					consulta += queryUtil.Where(isFiltro) + "fhRepAut BETWEEN " + "TO_DATE('"  + Util.format(paramDTO.getFhReporteDel()) +"','DD/MM/YYYY') " + " AND  TO_DATE ('"  + Util.format(paramDTO.getFhReporteAl()) +"','DD/MM/YYYY') ";
				}else{
					if(paramDTO.getFhReporteDel() != null){
						consulta += queryUtil.Where(isFiltro) + "fhRepAut = TO_DATE ('"  + Util.format(paramDTO.getFhReporteDel()) +"','DD/MM/YYYY') ";
					}
					
					if(paramDTO.getFhReporteAl() != null){
						consulta += queryUtil.Where(isFiltro) + "fhRepAut = TO_DATE ('"  + Util.format(paramDTO.getFhReporteAl()) +"','DD/MM/YYYY') ";
					}
				}
				isFiltro = true;
			}
			
			if(paramDTO.getFhAsignacionDel()!= null || paramDTO.getFhAsignacionAl()!= null){
				if(paramDTO.getFhAsignacionDel() != null && paramDTO.getFhAsignacionAl() != null){
					consulta += queryUtil.Where(isFiltro) + "fhAsignacion BETWEEN " + "TO_DATE('"  + Util.format(paramDTO.getFhAsignacionDel()) +"','DD/MM/YYYY') " + " AND  TO_DATE ('"  + Util.format(paramDTO.getFhAsignacionAl()) +"','DD/MM/YYYY') ";
				}else{
					if(paramDTO.getFhAsignacionDel() != null){
						consulta += queryUtil.Where(isFiltro) + "fhAsignacion = TO_DATE ('"  + Util.format(paramDTO.getFhAsignacionDel()) +"','DD/MM/YYYY') ";
					}
					
					if(paramDTO.getFhAsignacionAl() != null){
						consulta += queryUtil.Where(isFiltro) + "fhAsignacion = TO_DATE ('"  + Util.format(paramDTO.getFhAsignacionAl()) +"','DD/MM/YYYY') ";
					}
				}
				isFiltro = true;
			}
			 
			if(paramDTO.getCdCasoDel()!= null || paramDTO.getCdCasoAl()!= null){
				if(paramDTO.getCdCasoDel() != null  && paramDTO.getCdCasoAl() != null){
					consulta += queryUtil.Where(isFiltro) + "cdCaso BETWEEN " + paramDTO.getCdCasoDel() + " AND "  + paramDTO.getCdCasoAl();
				}else{
					if(paramDTO.getCdCasoDel() != null){
						consulta += queryUtil.Where(isFiltro) + "cdCaso = "  + paramDTO.getCdCasoDel();
					}
					
					if(paramDTO.getCdCasoAl() != null){
						consulta += queryUtil.Where(isFiltro) + "cdCaso = "  + paramDTO.getCdCasoAl();
					}
				}
				isFiltro = true; 
			}
			
			if(paramDTO.getCdCasoSicaDel()!= null || paramDTO.getCdCasoSicaAl()!= null){
				if(paramDTO.getCdCasoSicaDel() != null && paramDTO.getCdCasoSicaAl() != null){
					consulta += queryUtil.Where(isFiltro) + "CasoSica BETWEEN " + paramDTO.getCdCasoSicaDel() + " AND "  + paramDTO.getCdCasoSicaAl();
				}else{
					if(paramDTO.getCdCasoSicaDel() != null){
						consulta += queryUtil.Where(isFiltro) + "cdCasoSica = "  + paramDTO.getCdCasoSicaDel();
					}
					
					if(paramDTO.getCdCasoSicaAl() != null){
						consulta += queryUtil.Where(isFiltro) + "cdCasoSica = "  + paramDTO.getCdCasoSicaAl();
					}
				}
				isFiltro = true; 
			}
			 
			if(paramDTO.getImMontoDel()!= null || paramDTO.getImMontoAl()!= null ){
				if(paramDTO.getImMontoDel() != null && paramDTO.getImMontoAl() != null){
					consulta += queryUtil.Where(isFiltro) + "imMonto BETWEEN " + paramDTO.getImMontoDel() + " AND "  + paramDTO.getImMontoAl();
				}else{
					if(paramDTO.getImMontoDel() != null){
						consulta += queryUtil.Where(isFiltro) + "imMonto = "  + paramDTO.getImMontoDel();
					}
					if(paramDTO.getImMontoAl() != null){
						consulta += queryUtil.Where(isFiltro) + "imMonto = "  + paramDTO.getImMontoAl();
					}
				}
			}
		}
		
		return consulta;
	}
}
