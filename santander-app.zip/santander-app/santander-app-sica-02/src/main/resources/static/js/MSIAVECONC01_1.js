var lstBtnArmado = ['#btn-enviar-consenso'];

$(function(){
	console.info('MSIAVECONC01_1');
	tableArmado.setTable({
		lstBtn: lstBtnArmado
	});
	
	fhAnio.changeYear(lstSesionByAnio);
});

//=================== CHANGE BTN CALENDAR YEAR ===================
function lstSesionByAnio(fhAnio) {
	CatalogoSia.buscar(`lstSesion/${fhAnio}`, formParam.cdSesion, {value: 'cdValor',text: 'nbValor'});
}

// =================== BTN BUSCAR ARMADO DE CONSENSO ===================
function buscarArmado(){
	tableArmado.convertServer();
	tableArmado.setTable({
		url: getUrlParam(),
		checkboxHeader: true,
		lstBtn: lstBtnArmado
	});
}

function getUrlParam(){
	var casoDTO = formParam.getData();
	var string = `?cdSesion=${casoDTO.cdSesion != null ? casoDTO.cdSesion : ''}&nuCasos=${casoDTO.nuCasos != null ? casoDTO.nuCasos : ''}`;
	
	return `${Session.get('baseUrl')}/ConsensoSiaService/lstArmadoConsenso${string}`;
}

//=================== BTN BORRAR FORM ARMADO ===================
function resetFormTable(){
	formParam.reset();
	if(tableArmado.type == 'server') tableArmado.convertData();
	tableArmado.setTable({
		lstBtn: lstBtnArmado
	});
}

//=================== BTN ENVIAR CONSENSO ===================
function enviarConsenso(){
	var lstCasos = tableArmado.getSelections();
	console.info(lstCasos);
}