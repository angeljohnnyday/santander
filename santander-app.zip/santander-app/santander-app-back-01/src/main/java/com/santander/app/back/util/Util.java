package com.santander.app.back.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Util {
	
	public static <T> T obtenerCampos(T objectoDTO, String name, Object object) {
		Field[] fields = objectoDTO.getClass().getDeclaredFields();
		for (Field field : fields) {
			
			if (!Modifier.isPublic(field.getModifiers())) {
				field.setAccessible(true);
			}
			
			try {
				if(field.getName().equals(name)) {
					field.set(objectoDTO, object);
					log.info("name: "+ object);
					log.info(object.getClass().getName());
				}
				
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		
		return objectoDTO;
	}
	
	public static Object getDTO(Object objectDTO, String json) {
		try {
			return new ObjectMapper().readValue(json, objectDTO.getClass());
		} catch (Exception e) {
			log.error("error: "+ e.getMessage());
			return null;
		}
	}
	
	public static String format(Date date) {
		if(date == null) return null;
		
		SimpleDateFormat dateFormate = new SimpleDateFormat("dd/MM/yyyy", new Locale("es", "ES"));
		return dateFormate.format(date);
	}
	
	public static String format(String formato, Date date) {
		if(date == null || formato == null) return null;
		
		SimpleDateFormat dateFormate = new SimpleDateFormat(formato, new Locale("es", "ES"));
		return dateFormate.format(date);
	}
	
}
