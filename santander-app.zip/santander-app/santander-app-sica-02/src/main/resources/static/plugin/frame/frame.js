//document.addEventListener('readystatechange', (event) => {
//    console.info(`readystate: ${document.readyState}\n`);
//});

customElements.define('user-info', class extends HTMLElement {
	constructor(){
		super();
				
		var shadow = this.attachShadow({mode: 'open'});
			
		var usuarioDTO = Session.getUser();
		var nbUsuario = (`${usuarioDTO.nbPersona} ${usuarioDTO.nbPaterno} ${usuarioDTO.nbMaterno != null ? usuarioDTO.nbMaterno : ''}`).trim();
		
		var span = document.createElement('span');
		span.innerHTML = `${usuarioDTO.nbCveRed} - ${nbUsuario} - ${usuarioDTO.nbPerfil1}`;
				
		shadow.appendChild(span);
	}
});

window.addEventListener("DOMContentLoaded", () => {
	Object.defineProperty(document, 'form', {
	    value: function(element){
			if(typeof element === 'string'){
				element = document.querySelector(`*[data-form=${element}]`);
			}
			var name = element.dataset.form;
			
			window[name] = new Form(element);
	    }
	});
	
	Object.defineProperty(document, 'tableData', {
	    value: function(element){
			if(typeof element === 'string'){
				element = document.querySelector(`table[data-table=${element}]`);
			}
			
			var name = element.dataset.table;
			if(name == null || name.trim() == '') throw 'data-table value is NULL';
			
			window[name] = new TableData(element);
	    }
	});
	
	Object.defineProperty(document, 'tableServer', {
	    value: function(element){
			if(typeof element === 'string'){
				element = document.querySelector(`table[table-server=${element}]`);
			}
			
			var name = element.dataset.tableServer;
			if(name == null || name.trim() == '') throw 'data-table-server value is NULL';
			
			window[name] = new TableServer(element);
	    }
	});
	
	Object.defineProperty(document, 'model', {
	    value: function(element){
			if(typeof element === 'string'){
				element = document.querySelector(`*[data-model=${element}]`);
			}
			
			var name = element.dataset.model;
			window[name] = new Model(element);
	    }
	});
	
	Object.defineProperty(document, 'datePicker', {
	    value: function(element){
			if(typeof element === 'string'){
				element = document.querySelector(`*[data-date-picker=${element}]`);
			}
			
			var name = element.dataset.datePicker;
			
			window[name] = new DatePicker(element, name);
			var datePickerAnio = element.attributes['data-date-picker-year'];
			window[name].init();
			if(datePickerAnio != null){
				window[name].yearInit();
			}
	    }
	});
	
	Object.defineProperty(document, 'money', {
	    value: function(element){
			if(typeof element === 'string'){
				element = document.querySelector(`*[data-money=${element}]`);
			}
			
			var name = element.dataset.money;
			
			window[name] = new Money(element, name);
			window[name].init();
	    }
	});
	
	Object.defineProperty(document, 'script', {
	    value: function(element){
	    	
	    	if(typeof element === 'string'){
				element = document.querySelector(`*[data-script=${element}]`);
			}
	    	
	    	var script = element.dataset.script;
			var name = `script_${script}`;
			var src = `js/${script}.js`;

			window[name] = new Script(src);
			if(element.attributes[`data-script-init`] != null) window[name].init();
			element.addEventListener('click', function(){
				if(window[name].status == 0){
					window[name].init();
				} else {
					window[name].reload();
				}
			})
	    }
	});
	
	loadInit(false, null);
});

const loadInit = function (bool, target){
	if(!bool) target = document;
	
	
//	SEARCH ELEMENTS MODEL
	var lstForm = target.querySelectorAll('[data-form]');
	lstForm.forEach(element => {
		document.form(element);
	});
	
//	SEARCH ELEMENTS TABLE
	var lstTableData = target.querySelectorAll('table[data-table]');
	lstTableData.forEach(element => {
		document.tableData(element);
	});
	
//	SEARCH ELEMENTS TABLE SERVER
	var lstTableServer = target.querySelectorAll('table[data-table-server]');
	lstTableServer.forEach(element => {
		document.tableServer(element);
	});
	
//	SEARCH ELEMENTS FIELD	
	var lstModel = target.querySelectorAll('[data-model]');
	lstModel.forEach(element => {
		document.model(element);
	});
	
//	SEARCH ELEMENTS DATE PICKER
	var lstDatePicker = target.querySelectorAll('[data-date-picker]');
	lstDatePicker.forEach(element => {
		document.datePicker(element);
	});
	
//	SEARCH ELEMENTS MONEY
	var lstMoney = target.querySelectorAll('[data-money]');
	lstMoney.forEach(element => {
		document.money(element);
	});
//	==================== FIN CREACION OBJETOS ====================
	
//	SEARCH DATA CLASS
	var lstDataClass = target.querySelectorAll('[data-class]');
	lstDataClass.forEach(element => {
		var fn = element.getAttribute('data-class');
		var className = eval(fn);
		if(className != null && className.trim("")) element.classList.add(className);
	});
	
//	SEARCH DATA TEXT
	var lstDataText = target.querySelectorAll('[data-text]');
	lstDataText.forEach(element => {
		var fn = element.getAttribute('data-text');
		var text = eval(fn);
		element.innerHTML = text == null ? '' : text;
	});
	
//	SEARCH DATA SHOW
	var lstDataText = target.querySelectorAll('[data-show]');
	lstDataText.forEach(element => {
		var string = element.getAttribute('data-show');
		var code = eval(string);
		
		if(typeof code === 'object') {
			element.style.display = (code.element.style.display);
		} else {
			element.style.display = code ? 'inline-block' : 'none';
		}
	});
	
//	SEARCH DATA SHOW
	var lstDataText = target.querySelectorAll('[data-value]');
	lstDataText.forEach(element => {
		var fn = element.getAttribute('data-value');
		var value = eval(fn);
		
		element.value = value;
	});
	
//	SEARCH DATA PAGE 
	var lstTabPage = target.querySelectorAll('[data-page]');
	lstTabPage.forEach(element => {
		var page = element.dataset.page;
		var target = document.querySelector(element.getAttribute('href'));
		
		var callback = function(data, status){
			if(status == 'success'){
				$(target).html(data);
				loadInit(true, target);
			} else {
				Ajax.statusOK({
					statusCodeValue: 500,
					message: 'Pagina no localizada'
				}, true);
			}
		}
		
//		element.classList.remove('active');
//		target.classList.remove('active');
		element.addEventListener('click', (event)=> {
			Ajax.get(page, `${Session.get('baseUrlFront')}/view/`).done(callback);
		});
		
		if(element.hasAttribute('data-page-init')){
			element.classList.add('active');
			target.classList.add('active');
			Ajax.get(page, `${Session.get('baseUrlFront')}/view/`).done(callback);
		}
	});
	
}

const mutation = function (target){
	const mutation = new MutationObserver((mutationList) => {
		for(var mutation of mutationList){
			console.log(mutation.target);
		}
	});
	mutation.observe(target, { childList: true, attributes: false, subtree: false });
//	mutation.disconnect();
}