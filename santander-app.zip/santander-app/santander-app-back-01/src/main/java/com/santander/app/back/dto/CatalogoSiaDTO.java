package com.santander.app.back.dto;

import lombok.Data;

@Data
public class CatalogoSiaDTO {
	private String cdDetCatalogo;
	private String cdValor;
	private String nbValor;
	private String cdCatalogo;
	private String nbRazon;
	private String cdDetCatPad;
}