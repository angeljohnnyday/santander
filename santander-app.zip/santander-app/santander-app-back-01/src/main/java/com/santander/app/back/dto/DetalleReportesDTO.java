package com.santander.app.back.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class DetalleReportesDTO {
	private String nbColumna;
	private BigDecimal cdColumna;
	private String nbOrden;
}
