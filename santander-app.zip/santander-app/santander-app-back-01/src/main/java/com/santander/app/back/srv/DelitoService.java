package com.santander.app.back.srv;

import java.math.BigDecimal;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.santander.app.back.dto.DelitoDTO;
import com.santander.app.back.util.Response;

@Path("/DelitoService")
public interface DelitoService {

	@GET
	@Path("/lstDelitos")
	@Produces( MediaType.APPLICATION_JSON )
	public Response<Object> lstDelitos(
		@QueryParam("limit") Integer limit,
		@QueryParam("offset") Integer offset,
		@QueryParam("search") String search,
		@QueryParam("name") String name,
		@QueryParam("order") String order
	);
	
	@GET
	@Path("/getDelito/{cdDelito}")
	@Produces( MediaType.APPLICATION_JSON )
	public Response<Object> getDelito(
		@PathParam("cdDelito") BigDecimal cdDelito
	);
	
	@POST
	@Path("/guardarDelito")
	@Produces( MediaType.APPLICATION_JSON )
	@Consumes( MediaType.APPLICATION_JSON )
	public Response<Object> guardarDelito(DelitoDTO delitoDTO);
	
	@POST
	@Path("/guardarDelito/{cdDelito}")
	@Produces( MediaType.APPLICATION_JSON )
	@Consumes( MediaType.APPLICATION_JSON )
	public Response<Object> guardarDelito(
		@PathParam("cdDelito") BigDecimal cdDelito,
		DelitoDTO delitoDTO
	);
	
	@POST
	@Path("/cambiarStatus")
	@Produces( MediaType.APPLICATION_JSON )
	@Consumes( MediaType.APPLICATION_JSON )
	public Response<Object> cambiarStatus(List<DelitoDTO> lstDelitoDTO);
	
	@POST	
	@Path("/eliminarDelitos")
	@Produces( MediaType.APPLICATION_JSON )
	@Consumes( MediaType.APPLICATION_JSON )
	public Response<Object> eliminarDelitos(List<DelitoDTO> lstDelitoDTO);
}
