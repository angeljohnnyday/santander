package com.santander.app.back.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class MovimientosSiaDTO {
	private String nuNumero;
	private BigDecimal cdCaso;
	private BigDecimal cdCasoSIA;
	private String nuCuenta;
	private String nbTpCuenta;
	private Date fhApertura;
	
	private String cdOficina;
	private String nbOficina;
	private String nbConcepto;
	private String nbTipoMovimiento;
	private Date fhMovimiento;
	private BigDecimal imMonto;
	private String cdDivisa;
	private BigDecimal imEfectivo;
	private String nbDescripcion;
	private String nbTerminal;
	private String nbHoraOpe;
	private String cdCentro;
	private String cdMontoReportado;
	
	private BigDecimal numAbonosTotal;
	private BigDecimal imAbonosTotal;
	
	private BigDecimal numCargosTotal;
	private BigDecimal imCargosTotal;
	
	private Date fhPeriodoIni;
	private Date fhPeridoFin;

	private BigDecimal numCargosAbonosTotal;
	private BigDecimal imCargosAbonosTotal;
	private String stResumen;
	private String cdBanco;
	private String nbCompuesto;
	private String stClienteMues;
	private String cdClienteMues1;
	private String cdClienteMues2;
	private String cdClienteMues3;
	private List<DetalleMovDetalleDTO> lstDetalleMovDetalleDTO;
	
	// Campos Nuevos Mejora SIA
	private String nuCtaContraParteMov;
	private String nuClienteMov;
	private String nbClienteMov;
	private String nbApePaternoMov;
	private String nbApeMaternoMov;
	private String tpPersonaMov;
	private String nbConceptoMov;

	private String nuChequeMov;
	private String imOperacionMov;
	private String nbProductoMov;
	private String cdCasosSiaMov;
	private String stCuentaMov;
	private String cdRfcMov;
	private String nbActividadMov;
	private String nbInterMov;
	private String cdCentroContMov;
	private String cdTerminalMov;
	private String nbHmMov;
	private String cdCentroMov;
	
	// Campos Nuevos Mejora
	private String cdClienteMues;
	private String nbClienteMues;
	private String nbApePaternoMues;
	private String nbApeMaternoMues;
	private String nbTpPersonaMues;
	private String cdCuentaMues;
	private String cdRefInternaMues;
	
	private String nuChequeMues;
	private String imOperacionMues;
	private String nbProductoMues;
	private String cdCasosSiaMues;
	private String stCuentaMues;
	private String cdRfcMues;
	private String nbActividadMues;
	private String nbInterMues;
	private String cdCentroContMues;
	private String cdTerminalMues;
	private String nbHmMues;
	private String cdCentroMues;
	
	private String fhIniOperMues;
	private String fhFinOperMues;
	private String imMinMues;
	private String imMaxMues;
	private String nbDesgloseMues;
	private String fhRepAutMues;
	private String nbActInternetMues;
	private String nbDetDiaMues;
	private String nbDetSucMues;
	private String stInusualMues;
	private String fhIniOperMuesDEL;
	private String fhFinOperMuesAL;
	private Date fhStMuestra;
	
	// Acciones del Supervisor mejora
	
	private String nbAccionMues;
	private String cdUsuarioMues;
	private Date fhAltaMues;
	private String cdPerfilMues;
	
	// Cuentas Relacionadas Mejora
	private String nuCuentaRepMues;
	private String tpPersonaRepMues;
	private String nbNombreRepMues;
	private String nbApPaternoMues;
	private String nbApMaternoMues;
	
	// Cuentas Vinculadas Mejora
	private String nuCuentaOrigenVinMues;
	private String nuClienteOrigenVinMues;
	private String nbTitularVincMues;
	private String nbDivisaVinMues;
	private String tpCuentaMues;
	private String nbCaracterMues;
	private String nuOperaMuesDet;
	
	private String agrupa;
	
	private String nuMovto;
	private String cdCtaReport;
	private String tpMovimiento;
	
	private String sesion;
	private String dictamenFinal;
	private String imMontoMues;
	private String repInmediato;
}
